#!/bin/bash

##################
# Arguments
#  $1: start year    <yyyy>
#  $2: Number of years 
#  $3: Variable: uM and Z
#  Climatology_DM: Calculate 5-year running-mean climatology and
#                  all-year climatology of
#                  geopotential height at 500 hPa (Z) and
#                  zonal mass flux (uM), with a daily resolution.
#
# Inputdata of uM produced by uMdm.sh
#
# Scripts: uM.py
#
# Rune Grand Graversen: rune.graversen@uit.no
###################

BE=$1
EN=$(($1+$2-1))

module load CDO/2.2.2-gompi-2023a

var=$3

if [ $var != "uM" ] \
       && [ $var != "Z" ]; then
  echo "input \$3 must be either uM, or Z"
  exit 1
fi

if [ "$2" -lt "5" ]; then
  echo "input \$2 must in the interval [5;45]"
  exit 2
fi

##########################
# Settings
# dirWork: temporary saving of data; dirHome: script directory;
# dirIn: input directory
# dirOut: output directory
#dirWork=<work_dir>
#dirHome=<script_dir>
dirWork=/nird/datalake/NS9063K/Rune/Work
dirHome=/nird/home/runegg/cdo/WeathPers
#dirIn=/nird/datalake/NS9063K/LongBackup/WeathPers24/uEdm
InNC=true
if [ $var == "uM" ]; then
  dirIn=<input_dir>
#  dirIn=/nird/datalake/NS9063K/LongBackup/WeathPers24/uMdm
fi
if [ $var == "Z" ]; then
  dirIn=<input_dir>
#  dirIn=/nird/datalake/NS9063K/LongBackup/era5/Pres/analysis/daily/Z
  InNC=false
  MO=("01" "02" "03" "04" "05" "06" "07" "08" "09" "10" "11" "12")
fi
dirOut=<output_dir> 
#dirOut=$dirIn/NC
############################

varcl=${var}cl

cd $dirWork

################
# Download data, change formate to NetCDF
echo 'downloading'
for ((i=$BE; i<=$EN; i++)); do
  echo '      ' $i  
  if [ -f $var.$i.nc ]; then
    rm -f $var.$i.nc
  fi
  if $InNC; then
    cp -f $dirIn/$var.$i.nc $var.$i.nc
  else
    if [ $var == "Z" ]; then
      for m in ${MO[@]}; do
        cp -f $dirIn/$var.$i.$m.grb $var.$i.$m.grb
        cdo -s -R -f nc -t ecmwf copy \
            $var.$i.$m.grb $var.temp.$i.$m.nc
        rm -f $var.$i.$m.grb
        cdo -s -O sellonlatbox,-180,179.5,20,90 -sellevel,50000 \
	    $var.temp.$i.$m.nc $var.temp1.$i.$m.nc
        rm -f $var.temp.$i.$m.nc
	cdo -s -O --reduce_dim -copy $var.temp1.$i.$m.nc $var.temp2.$i.$m.nc
	rm -f $var.temp1.$i.$m.nc
	cdo -s -O chname,Z,Z500 $var.temp2.$i.$m.nc $var.temp3.$i.$m.nc
        rm -f $var.temp2.$i.$m.nc
	cdo -s -O -L setcalendar,proleptic_gregorian \
            -setreftime,1979-01-01,00:00:00,hours \
            -settaxis,$i-$m-01,00:00:00,1day \
            $var.temp3.$i.$m.nc $var.temp4.$i.$m.nc
        rm -f $var.temp3.$i.$m.nc

        # Remove leap day                                                    
        if [ $m = "02" ] && [ $(expr $i % 4) = "0" ]; then
          cdo -s -O delete,month=2,day=29 $var.temp4.$i.$m.nc \
            $var.$i.$m.nc
        else
          cp -f $var.temp4.$i.$m.nc $var.$i.$m.nc
        fi
        rm -f $var.temp4.$i.$m.nc
      done
      cdo -s -O mergetime $var.$i.*.nc $var.$i.nc
      rm -f $var.$i.*.nc
    fi
  fi
done

fived=0.2
########
#Calculate five-year running climatology
#Note:
#Serialise the I/O processes with "-L"
########
echo 'calculating climatology'
for ((i=$BE; i<=$EN; i++)); do
    echo '       ' $i
    if [ -f $varcl.$i.nc ]; then
      rm -f $varcl.$i.nc
    fi
    if (($i == $BE)); then
      cdo -s -L mulc,$fived -add $var.$i.nc -add $var.$i.nc -add \
	      $var.$(($i+1)).nc -add $var.$(($i+1)).nc \
	      $var.$(($i+2)).nc $varcl.$i.nc
    elif (($i == $BE+1)); then
      cdo -s -L mulc,$fived -add $var.$i.nc -add $var.$(($i-1)).nc -add \
	      $var.$(($i-1)).nc -add $var.$(($i+1)).nc \
	      $var.$(($i+2)).nc $varcl.$i.nc
    elif (($i==$EN-1)); then
      cdo -s -L mulc,$fived -add $var.$i.nc -add $var.$(($i-1)).nc -add \
              $var.$(($i-2)).nc -add $var.$(($i+1)).nc \
	      $var.$(($i+1)).nc $varcl.$i.nc
    elif (($i==$EN)); then
      cdo -s -L mulc,$fived -add $var.$i.nc -add $var.$i.nc -add \
	      $var.$(($i-1)).nc -add $var.$(($i-1)).nc \
	      $var.$(($i-2)).nc $varcl.$i.nc
    else
      cdo -s -L mulc,$fived -add $var.$i.nc -add $var.$(($i-1)).nc -add \
	      $var.$(($i-2)).nc -add $var.$(($i+1)).nc \
	      $var.$(($i+2)).nc $varcl.$i.nc
    fi
done

#########################
# Save data
for ((i=$BE; i<=$EN; i++)); do
  cp -f $varcl.$i.nc $dirOut/.
  cp -f $var.$i.nc $dirOut/.
  rm -f $varcl.$i.nc
  rm -f $var.$i.nc
done
#cp -f $var.Clim.$BE-$EN.nc $dirOut/.
#rm -f $var.Clim.$BE-$EN.nc

echo ' ... end'

exit 0
