#!/bin/bash

##################
# Arguments
#  $1: start year    <yyyy>
#  $2: Number of years 
#  $3: Variable: SAT, T, Z, uM,
#
#  Climatology_MM: Calculate 5-year running-mean climatology and
#                  all-year climatology of
#                  SAT, geopotential height at 500 hPa (Z) and
#                  zonal mass flux (uM), with a monthly resolution.
#
# Inputdata of uM produced by uMmm.sh
#
# Scripts: uM.py
#
# Rune Grand Graversen: rune.graversen@uit.no
###################

BE=$1
EN=$(($1+$2-1))

module load CDO/2.2.2-gompi-2023a

var=$3

##########################
# Settings
# dirWork: temporary saving of data; dirHome: script directory;
# dirIn: input directory
# dirOut: output directory
dirWork=<work_dir>
dirHome=<script_dir>
#dirWork=/nird/datalake/NS9063K/Rune/Work
#dirHome=/nird/home/runegg/cdo/WeathPers
filet=grb
if [ "$var" == 'SAT' ]; then
  dirIn=<input_dir>
  dirOut=<output_dir>  
#  dirIn=/nird/datalake/NS9063K/LongBackup/era5/surface/analysis/monthly/SAT
#  dirOut=/nird/datalake/NS9063K/LongBackup/era5/surface/analysis/monthly/SAT/NC
  varcl=SATcl
elif [ "$var" == 'T' ]; then
  dirIn=<input_dir>
  dirOut=<output_dir>  
$#  dirIn=/nird/datalake/NS9063K/LongBackup/era5/Pres/analysis/monthly/T/2.5x2.5
 # dirOut=/nird/datalake/NS9063K/LongBackup/era5/Pres/analysis/monthly/T/2.5x2.5/NC/test
  varcl=Tcl
elif [ "$var" == 'Z' ]; then
  dirIn=<input_dir>
  dirOut=<output_dir>  
#  dirIn=/nird/datalake/NS9063K/LongBackup/era5/Pres/analysis/monthly/Z
#  dirOut=/nird/datalake/NS9063K/LongBackup/era5/Pres/analysis/monthly/Z/NC
  varcl=Zcl
elif [ "$var" == 'uM' ]; then
  dirIn=<input_dir>
  dirOut=<output_dir>
#  dirIn=/nird/datalake/NS9063K/LongBackup/WeathPers24/uMmm
#  dirOut=/nird/datalake/NS9063K/LongBackup/WeathPers24/uMmm/NC
  varcl=uMcl
  filet=nc
else
    echo $3 must be set to "SAT", "T", "Z", or "uM"
    exit 2
fi
if [ "$2" -lt "5" ]; then
  echo "input \$2 must in the interval [5;45]"
  exit 3
fi

cd $dirWork

################
# Download data, change formate to NetCDF
for ((i=$BE; i<=$EN; i++)); do
  if [ -f $var.$i.$filet ]; then
    rm -f $var.$i.$filet
  fi
  cp -vf $dirIn/$var.$i.$filet .
  if [ "$filet" == 'grb' ]; then
    cdo -s -f nc -t ecmwf copy $var.$i.grb \
	temp.$i.nc
  else
    cp -f $var.$i.$filet temp.$i.nc  
  fi
 
  # Changing chalendar which is read by Python as ..
  cdo -s -L setcalendar,standard \
     -setreftime,1979-01-01,00:00:00,hours \
     -settaxis,$i-01-01,00:00:00,1month \
     temp.${i}.nc $var.${i}.nc
  rm -f temp.$i.nc
  if [ -f  $var.$i.grb ]; then
    rm -f $var.$i.$filet
  fi
done

fived=0.2
########
#Calculate five-year running climatology
#Note:
#Serialise the I/O processes with "-L"
########
for ((i=$BE; i<=$EN; i++)); do
    if [ -f $varcl.$i.nc ]; then
      rm -f $varcl.$i.nc
    fi
    if (($i == $BE)); then
      cdo -L mulc,$fived -add $var.$i.nc -add $var.$i.nc -add \
	      $var.$(($i+1)).nc -add $var.$(($i+1)).nc \
	      $var.$(($i+2)).nc $varcl.$i.nc
    elif (($i == $BE+1)); then
      cdo -L mulc,$fived -add $var.$i.nc -add $var.$(($i-1)).nc -add \
	      $var.$(($i-1)).nc -add $var.$(($i+1)).nc \
	      $var.$(($i+2)).nc $varcl.$i.nc
    elif (($i==$EN-1)); then
      cdo -L mulc,$fived -add $var.$i.nc -add $var.$(($i-1)).nc -add \
              $var.$(($i-2)).nc -add $var.$(($i+1)).nc \
	      $var.$(($i+1)).nc $varcl.$i.nc
    elif (($i==$EN)); then
      cdo -L mulc,$fived -add $var.$i.nc -add $var.$i.nc -add \
	      $var.$(($i-1)).nc -add $var.$(($i-1)).nc \
	      $var.$(($i-2)).nc $varcl.$i.nc
    else
      cdo -L mulc,$fived -add $var.$i.nc -add $var.$(($i-1)).nc -add \
	      $var.$(($i-2)).nc -add $var.$(($i+1)).nc \
	      $var.$(($i+2)).nc $varcl.$i.nc
    fi
done

##########################
# Calculate climatology over all years
if [ -f $var.Clim.nc ]; then
    rm -f $var.Clim.nc
fi
cdo -L ymonmean -cat "$var.*.nc" $var.Clim1.nc 
ncks -C -O -x -v time_bnds $var.Clim1.nc $var.Clim2.nc
rm -f $var.Clim1.nc

# Remove atrribute time: time_bnd with Python
python3 $dirHome/uM.py $var.Clim2.nc $var.Clim.nc
rm -f uM.Clim2.nc

#########################
# Save data
for ((i=$BE; i<=$EN; i++)); do
  cp -f $varcl.$i.nc $dirOut/.
  cp -f $var.$i.nc $dirOut/.
  rm -f $varcl.$i.nc
  rm -f $var.$i.nc
done
cp -f $var.Clim.nc $dirOut/.
rm -f $var.Clim.nc

echo ' ... end'

exit 0
