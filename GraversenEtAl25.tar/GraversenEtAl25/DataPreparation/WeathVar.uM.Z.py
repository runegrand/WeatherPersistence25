# -*- coding: utf-8 -*-
# WeathVar.uM.Z.py
#
# Calculate anomalies of uM and Z
# uM-uM_clim and Z-Z_clim
# and save in latitude bands.
# uM/Z_clim is a 5-year smoothed running climatology
# The climatology is calculated by Climatology_DM.sh.
# The climatology is smoothed here.
#
# Rune Grand Graversen: rune.graversen@uit.no
####################

import xarray as xr
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cftime
import sys
import numpy as np
import xrft
import os

#########################
# Settings
RunA=36    # days of running-mean smoothing the climatology
           # [36 is used in Graversen et al., Comm. Earth Env, 2025]

var='Z'   # uM or Z

# Path: input data files; PathW: output data files
if (var=='uM'):
  Path=<uM_input_dir>
  PathW=<uMoutput_dir>
  #Path='/nird/datalake/NS9063K/LongBackup/WeathPers24/uMdm/NC/'
  #PathW='/nird/datalake/NS9063K/Rune/WorkWeathVar/uM/'
  LatBeg=70
  LatEnd=40
elif (var=='Z'):
  Path=<Z_input_dir>
  PathW=<Z_output_dir>
  #Path='/nird/datalake/NS9063K/LongBackup/era5/Pres/analysis/daily/Z/NC/'
  #PathW='/nird/datalake/NS9063K/Rune/WorkWeathVar/Z/'
  LatBeg=90
  LatEnd=20
else:
  sys.exit('"var" must be either uM or Z !!')

Yearstart=1979   # Start year
Nyears=45        # Number of years
LatStep=10       # Latitude bands
                 # [10 and 2 were used in
                 #  Graversen et al., Comm. Earth Env, 2025]
########################

#Yearstart=1979
#Nyears=45

#LatStep=2

LatLoop = np.arange(LatBeg,LatEnd,-LatStep)

lat=xr.open_dataset(Path+var+'.'+str(Yearstart)+'.nc').lat
dlat=np.abs(lat[0].data-lat[1].data)

if (RunA!=36):
  nmRM='RM'+str(RunA)
else:
  nmRM=''
              
Ys = np.arange(Yearstart,Yearstart+Nyears,1)

for Lati in LatLoop:
  print("Calculating for latitude: "+str(Lati))
  latb=Lati
  late=Lati-LatStep+dlat
  if ((late-dlat)==LatEnd):
    late=LatEnd
  ilatb=np.where(np.abs(lat-latb)<dlat/2)[0][0]
  ilate=np.where(np.abs(lat-late)<dlat/2)[0][0]
  
  pathvE=[]
  pathvEcl=[]
  for y in Ys:
    pathvE.append(Path+var+'.'+str(y)+'.nc')
    pathvEcl.append(Path+var+'cl.'+str(y)+'.nc')

  dsvE=xr.open_mfdataset(pathvE,concat_dim='time',combine='nested').\
           isel(lat=slice(ilatb,ilate+1)).compute() 
  if (RunA!=0):
    # Running mean of climatology
    dsvEcl=xr.open_mfdataset(pathvEcl,concat_dim='time',combine='nested').\
           isel(lat=slice(ilatb,ilate+1)).compute().\
           rolling(time=RunA,center=True).mean()
  else:
    sys.exit('RunA must not be zero!!')

  # Anomaly
  dsvEan = (dsvE-dsvEcl)

  path_save=PathW+var+'an'+nmRM+'_Lat'+str(late)+'to'+str(latb)+'.nc'
  os.system('rm -f '+path_save)
  dsvEan.to_netcdf(path_save)
 
 
