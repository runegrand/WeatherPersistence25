#!/bin/sh

###############
# SAT_SpatialRunMEan.sh
#
# Calculating spatial 5-year running-mean daily climatology of SAT
# from six-hour data. Save dayly SAT and SAT climatology.
#
# Input data is six hourly SAT (ERA5).
#
# Input parameters:
#  -y: Start year            <yyyy>
#  -N: Number of years <N>
#
# Rune Grand Graversen: rune.graversen@uit.no
###############

while getopts y:N: option ; do
    case $option in
        y) YEAR=${OPTARG}   ;;
        N) Nyears=${OPTARG}   ;;
    esac
done
module load CDO/2.2.2-gompi-2023a

EndYEAR=`expr ${YEAR} + ${Nyears} - 1`

########################
# Settings
# Path_in: input data files; Path_out: output data files;
# Path_work: temporary saving of data; Path_tool: tool scripts
# Note: tools path setting also necessary in SpaceRunMean.py
Path_in=<input_dir>
Path_out=<output_dir>
Path_work=<work_dir>
Path_tool=<tools_dir>
#Path_in=/nird/datalake/NS9063K/LongBackup/era5/surface/analysis/daily/SAT
#Path_out=${Path_in}/SpaceRunMean
#Path_work=/nird/datalake/NS9063K/Rune/Work
#Path_tool=/nird/home/runegg/Python/WeathPers24/GitHub
##########################

month=(01 02 03 04 05 06 07 08 09 10 11 12)

for i in `seq ${YEAR} ${EndYEAR}`; do
    echo "doing.." ${i}
    for m in ${month[*]}; do
	cp -f ${Path_in}/SAT.${i}.${m}.grb ${Path_work}/.
	cdo -s -f nc -t ecmwf copy ${Path_work}/SAT.${i}.${m}.grb \
	    ${Path_work}/temp.${i}.${m}.nc
	
	# Changing chalendar which is read by Python as ..
        cdo -s -L setcalendar,standard \
	      -setreftime,1979-01-01,00:00:00,hours \
	      -settaxis,${i}-${m}-01,00:00:00,24hours \
	      ${Path_work}/temp.${i}.${m}.nc ${Path_work}/temp1.${i}.${m}.nc
        rm -f ${Path_work}/temp.$i.$m.nc
	
        # Remove leap day
        if [ $m = "02" ] && [ $(expr $i % 4) = "0" ]; then
          cdo -s delete,month=2,day=29 ${Path_work}/temp1.$i.$m.nc ${Path_work}/SAT.$i.$m.nc
          rm -f ${Path_work}/temp1.$i.$m.nc
        else
          cp -f ${Path_work}/temp1.$i.$m.nc ${Path_work}/SAT.$i.$m.nc
	  rm -f ${Path_work}/temp1.$i.$m.nc
        fi   
    done

    # Calculating spatial running mean
    echo python3 SpaceRunMean.py ${i}
    python3  ${Path_tool}/SpaceRunMean.py ${i} ${Path_work}
    
    cp -f ${Path_work}/SATrm.${i}.nc ${Path_out}/SATrm.${i}.nc
    rm -f ${Path_work}/SATrm.${i}.nc
    rm -f ${Path_work}/temp.${i}.nc
    rm -f ${Path_work}/SAT.${i}.*.*
done

echo ".. DONE SAT_SpaceRunMean.sh !!"

exit 0
