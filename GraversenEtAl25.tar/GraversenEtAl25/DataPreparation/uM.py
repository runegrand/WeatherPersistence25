# -*- coding: utf-8 -*-
# uM.py
#
# sys.argv[1]: File name in
# sys.argv[2]: Filename out
#
# Rune Grand Graversen: rune.graversen@uit.no
#########################

import xarray as xr
import math
import numpy as np
import sys

FileNMin=sys.argv[1]
FileNMout=sys.argv[2]

dirWork='/nird/datalake/NS9063K/Rune/Work/'

uMf=dirWork+FileNMin
uM= xr.open_dataset(uMf)

del uM["time"].attrs['bounds']

uM.to_netcdf(dirWork+FileNMout)
