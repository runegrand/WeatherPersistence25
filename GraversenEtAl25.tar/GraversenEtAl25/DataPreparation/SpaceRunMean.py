# -*- coding: utf-8 -*-
# SpaceRunMean.py
#
# Calculate spatial running mean
# over "Nlatrm" in latitude direction
# and an equal distance in the longitude direcion.
#
# Input variables: 
# sys.argv[1]: YEAR
# sys.argv[2]: path work
#
# Rune Grand Graversen: rune.graversen@uit.no
####################

import xarray as xr
import matplotlib.pyplot as plt
import cftime
import sys
import numpy as np
import os
import sys

#########################
# Setting tool script dir
# directory to tools script (tools.py and tools_plot.py)
toolPath=<tools_script_dir>
#toolPath='/cluster/home/runegg/python/WeathPers25/GitHub/'
#########################
try:
    sys.path.index(toolPath)
except ValueError:
    sys.path.append(toolPath)
from tools_prep import filter_run_mean_time_lat_lon

y = sys.argv[1]
Path_work = sys.argv[2]

monthnm=['01','02','03','04','05','06','07','08','09','10','11','12']

pathSAT=[]
for m in monthnm:
  pathSAT.append(Path_work+'/SAT.'+str(y)+'.'+m+'.nc')

dsSAT=xr.open_mfdataset(pathSAT,concat_dim='time',combine='nested')

Nlatrm = 5
dsSATrm = filter_run_mean_time_lat_lon(dsSAT["T2M"],Nlatrm).astype(np.float32)

os.system('rm -f '+Path_work+'/SATrm.'+str(y)+".nc")
dsSATrm.to_netcdf(Path_work+'/SATrm.'+str(y)+".nc")
x=xr.open_dataset(Path_work+'/SATrm.'+str(y)+".nc")

print(".. done Python "+str(y))
