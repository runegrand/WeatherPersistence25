# -*- coding: utf-8 -*-
# WeathVar.py
#
# Calculate anomalies of temperature
# T-T_clim
# and save in latitude bands.
# T_clim is a 5-year smoothed running climatology
# The climatology is calculated by SAT_climatology.sh.
# The climatology is  smoothed here.
#
# Rune Grand Graversen: rune.graversen@uit.no
####################

import xarray as xr
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cftime
import sys
import numpy as np
import xrft
import os

#########################
# Settings
RunA=36  # days of running-mean smoothing the climatology
         # [36 is used in Graversen et al., Comm. Earth Env, 2025]

# Path: input data files; PathW: output data files
Path=<input_dir>
PathW=<output_dir>
#Path='/nird/datalake/NS9063K/LongBackup/era5/surface/analysis/daily/SAT/SpaceRunMean/'
#PathW='/nird/datalake/NS9063K/Rune/WeathPers25/work/SATvar/'

Yearstart=1979   # Start year
Nyears=45        # Number of years
LatStep=10       # Latitude bands
                 # [10 and 2 were used in
                 #  Graversen et al., Comm. Earth Env, 2025]
LatEnd=20        # Calculate north of LatEnd
#########################

LatLoop = np.arange(90,LatEnd,-LatStep)

lat=xr.open_dataset(Path+'/SATrm.'+str(Yearstart)+'.nc').lat
dlat=np.abs(lat[0].data-lat[1].data)

if (RunA!=36):
  nmRM='RM'+str(RunA)
else:
  nmRM=''
              
Ys = np.arange(Yearstart,Yearstart+Nyears,1)

for Lati in LatLoop:
  print("Calculating for latitude: "+str(Lati))
  latb=Lati
  late=Lati-LatStep+dlat
  if ((late-dlat)==LatEnd):
    late=LatEnd
  ilatb=np.where(np.abs(lat-latb)<dlat/2)[0][0]
  ilate=np.where(np.abs(lat-late)<dlat/2)[0][0]
  
  pathSATrm=[]
  pathSATrmcl=[]
  for y in Ys:
    pathSATrm.append(Path+'/SATrm.'+str(y)+'.nc')
    pathSATrmcl.append(Path+'/SATrmcl.'+str(y)+'.nc')

  dsSAT=xr.open_mfdataset(pathSATrm,concat_dim='time',combine='nested').\
           isel(lat=slice(ilatb,ilate+1)).compute() 
  if (RunA!=0):
    # Running mean of climatology
    print('RM of: '+str(RunA))
    dsSATcl=xr.open_mfdataset(pathSATrmcl,concat_dim='time',combine='nested').\
           isel(lat=slice(ilatb,ilate+1)).compute().\
           rolling(time=RunA,center=True).mean()
  else:
    print('RM else: '+str(RunA))
    dsSATcl=xr.open_mfdataset(pathSATrmcl,concat_dim='time',combine='nested').\
           isel(lat=slice(ilatb,ilate+1)).compute()

  # Anomaly 
  dsSATan = (dsSAT-dsSATcl)

  path_save=PathW+'SATan'+nmRM+'_Lat'+str(late)+'to'+str(latb)+'.nc'
  os.system('rm -f '+path_save)
  dsSATan.to_netcdf(path_save)
 
 
