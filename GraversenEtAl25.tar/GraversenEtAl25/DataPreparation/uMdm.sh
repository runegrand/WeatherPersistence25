#!/usr/bin/bash

########
# Arguments
# $1: Start year
# $2: Amount of years
#
# uMdm.sh:  Calculate daily-averaged and vertically integrated mass flux
#           ERA mass flux is corrected with Uerr from transport calculation
#           using surface pressure for vertical integral
# Input: -- Vertical integrals of zonal mass flux provided directly from
#           ERA5. Here six-hourly data are used.
#        -- Surface pressure from ERA5
#        -- Zonal wind correction is described in Graversen, J. Clim., 2006
#           This is a wind correction to the ERA5 winds, so that
#           the local atmospheric mass fulfill the continuity equation.
#           These data or scripts for calculating them can be obtained
#           from Rune Graversen.
#
# Scripts: uM.py
#
# Rune Grand Graversen: rune.graversen@uit.no
########

module load CDO/2.2.2-gompi-2023a

Download=true

##########################
# Settings
# dirWork: temporary saving of data; dirHome: script directory;
# dirU: zonal mass flux and zonal wind correction input data;
# dirSP: Surface pressure input data; dirSave: output directory
dirWork=<work_dir>
dirHome=<script_dir>
dirU=<input_MassFlux_dir>
dirSP=<input_SurfPres_dir>
dirSave=<output_dir>
#dirWork=/nird/datalake/NS9063K/Rune/Work
#dirHome=/nird/home/runegg/cdo/WeathPers
#dirU=/nird/datalake/NS9063K/LongBackup/era5/surface/transport/res_0.5x0.5/U
#dirSP=/nird/datalake/NS9063K/LongBackup/era5/surface/analysis/6_hourly/SP/0.5x0.5
#dirSave=/nird/datalake/NS9063K/LongBackup/WeathPers24/uMdm
###########################

cd $dirWork

BE=$1
EN=$(($1+$2-1))
MO=("01" "02" "03" "04" "05" "06" "07" "08" "09" "10" "11" "12")

g=9.80665
ginv=0.10197 # 1/g

if $Download; then
  for ((i=$BE; i<=$EN; i++)); do
    for m in ${MO[@]}; do
      echo $i $m 	  
      if [ ! -f U.$i.$m.nc ]; then
	cp -f $dirU/U.$i.$m.grb U.temp.$i.$m.grb
	cdo -s -R -f nc -t ecmwf --reduce_dim copy \
	                 U.temp.$i.$m.grb U.$i.$m.nc
	rm -f U.temp.$i.$m.grb
      fi
      if [ ! -f Uerr.$i.$m.nc ]; then
        cp -f $dirU/Uerr/Uerr.$i.$m.nc Uerr.temp.$i.$m.nc
	# Change grid name "generic" -> "lonlat" 
        cdo -s griddes Uerr.temp.$i.$m.nc > grid.txt
	sed -i "s/generic/lonlat/g" grid.txt
        cdo -s setgrid,grid.txt Uerr.temp.$i.$m.nc Uerr.temp1.$i.$m.nc
	rm -f Uerr.temp.$i.$m.nc grid.txt

	cdo -s -L setcalendar,proleptic_gregorian \
	    -setreftime,1979-01-01,00:00:00,hours \
	    -settaxis,$i-$m-01,00:00:00,6hours \
	    Uerr.temp1.$i.$m.nc Uerr.$i.$m.nc; rm -f Uerr.temp1.$i.$m.nc
      fi
      if [ ! -f SP.$i.$m.nc ]; then
        cp -f $dirSP/SP.$i.$m.grb SP.temp.$i.$m.grb
	cdo -s -R -f nc -t ecmwf copy SP.temp.$i.$m.grb SP.$i.$m.nc
	rm -f SP.temp.$i.$m.grb
      fi

      # Applying wind correction
      cdo -s -O sub U.$i.$m.nc -mul Uerr.$i.$m.nc -mulc,${ginv} \
	  SP.$i.$m.nc uM.temp.$i.$m.nc
      rm -f U.$i.$m.nc  Uerr.$i.$m.nc SP.$i.$m.nc

      cdo -s -O chname,var65,uM uM.temp.$i.$m.nc uM.temp1.$i.$m.nc
      rm -f uM.temp.$i.$m.nc

      cdo -s -O -L daymean -sellonlatbox,-180,179.5,30,80 \
	  uM.temp1.$i.$m.nc uM.temp.$i.$m.dm.nc
      rm -f uM.temp1.$i.$m.nc
      ncks -C -O -x -v time_bnds uM.temp.$i.$m.dm.nc uM.temp1.$i.$m.dm.nc
      rm -f uM.temp.$i.$m.dm.nc

      # Remove atrribute time: time_bnd with Python
      python3 $dirHome/uM.py uM.temp1.$i.$m.dm.nc uM.temp2.$i.$m.dm.nc
      rm -f uM.temp1.$i.$m.dm.nc
      cdo -s -O -L setcalendar,proleptic_gregorian \
            -setreftime,1979-01-01,00:00:00,hours \
            -settaxis,$i-$m-01,00:00:00,1day \
            uM.temp2.$i.$m.dm.nc uM.temp3.$i.$m.dm.nc
      rm -f uM.temp2.$i.$m.dm.nc

      # Remove leap day                                              
      if [ $m = "02" ] && [ $(expr $i % 4) = "0" ]; then
        cdo -s -O delete,month=2,day=29 uM.temp3.$i.$m.dm.nc \
            uM.$i.$m.dm.nc
      else
        cp -f uM.temp3.$i.$m.dm.nc uM.$i.$m.dm.nc
      fi
      rm -f uM.temp3.$i.$m.dm.nc
    done
    cdo -s -O mergetime uM.$i.*.dm.nc uM.$i.nc
    rm -f uM.$i.*.dm.nc
    cp -f uM.$i.nc $dirSave/.; rm -f uM.$i.nc
  done
fi

echo "..end!"

exit 0

