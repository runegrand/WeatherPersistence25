#!/bin/bash

#############################
# SAT_Climatology.sh
#
# Calculate 5-year running-mean daily climatology
# based on yearly files of daily data
# (for exmaple files produced by SAT_SpatialRunMean).
# Output yearly climatology files.
#
# Input variables
#  $1: start year    <yyyy>
#  $2: Number of years 
#
# Rune Grand Graversen: rune.graversen@uit.no
#############################
BE=$1
EN=$(($1+$2-1))
echo $EN

module load CDO/2.2.2-gompi-2023a

########################
# Settings
# dirIn: input and output data files; dirWork: temporary saving of data 
dirIn=<input_output_dir>
dirWork=<work_dir>
#dirIn=/nird/datalake/NS9063K/LongBackup/era5/surface/analysis/daily/SAT/SpaceRunMean
#dirWork=/nird/datalake/NS9063K/Rune/Work
#######################
cd $dirWork

if [ "$2" -lt "5" ]; then
  echo "input \$2 must in the interval [5;45]"
  exit 2
fi

################
# Download data
for ((i=$BE; i<=$EN; i++)); do
  if [ -f SATrm.$i.nc ]; then
    rm -f SATrm.$i.nc
  fi
  cp -vf $dirIn/SATrm.$i.nc .
done
#if [ ! -f SATrm.$BE-$EN.nc ]; then
#  if [ -f SATrm.$BE-$EN.nc ]; then
#    rm -f SATrm.$BE-$EN.nc
#  fi
#fi

fived=0.2
########
#Calculate five-year running climatology
#Note:
#Serialise the I/O processes wit "-L"
########
for ((i=$BE; i<=$EN; i++)); do
    if [ -f SATrmcl.$i.nc ]; then
      rm -f SATrmcl.$i.nc
    fi
    if (($i == $BE)); then
      cdo -L mulc,$fived -add SATrm.$i.nc -add SATrm.$i.nc -add \
	      SATrm.$(($i+1)).nc -add SATrm.$(($i+1)).nc \
	      SATrm.$(($i+2)).nc SATrmcl.$i.nc
    elif (($i == $BE+1)); then
      cdo -L mulc,$fived -add SATrm.$i.nc -add SATrm.$(($i-1)).nc -add \
	      SATrm.$(($i-1)).nc -add SATrm.$(($i+1)).nc \
	      SATrm.$(($i+2)).nc SATrmcl.$i.nc
    elif (($i==$EN-1)); then
      cdo -L mulc,$fived -add SATrm.$i.nc -add SATrm.$(($i-1)).nc -add \
              SATrm.$(($i-2)).nc -add SATrm.$(($i+1)).nc \
	      SATrm.$(($i+1)).nc SATrmcl.$i.nc
    elif (($i==$EN)); then
      cdo -L mulc,$fived -add SATrm.$i.nc -add SATrm.$i.nc -add \
	      SATrm.$(($i-1)).nc -add SATrm.$(($i-1)).nc \
	      SATrm.$(($i-2)).nc SATrmcl.$i.nc
    else
      cdo -L mulc,$fived -add SATrm.$i.nc -add SATrm.$(($i-1)).nc -add \
	      SATrm.$(($i-2)).nc -add SATrm.$(($i+1)).nc \
	      SATrm.$(($i+2)).nc SATrmcl.$i.nc
    fi
done

#########################
# Save data
for ((i=$BE; i<=$EN; i++)); do
  cp -fv SATrmcl.$i.nc $dirIn/.
  rm -f SATrmcl.$i.nc
  rm -f SATrm.$i.nc
done

echo ' ... end'
exit 0


