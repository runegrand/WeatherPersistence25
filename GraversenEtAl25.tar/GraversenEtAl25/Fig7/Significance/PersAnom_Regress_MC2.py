1# -*- coding: utf-8 -*-
#
# PersAnom_Regress_MC2.py
#
# Statistical significance of regressions of
# temperatuer persistence, uM , dZ500
# using MC FFT aprroach (randomly intercanging phases)
####################

import xarray as xr
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cftime
import sys
import numpy as np
np.round_ = np.round
import xrft
import os

#########################
# Setting tool script dir
# directory to tools script (tools.py and tools_plot.py)
toolPath=<tools_script_dir>
#toolPath='/cluster/home/runegg/python/WeathPers25/'
try:
    sys.path.index(toolPath) 
except ValueError:
    sys.path.append(toolPath)
from tools import xfft_T

NMC=5000
useAN='l'  #l: left, m: middle, r: right
lenRM=1    # Running mean for uM, Z500, SAT, and ET

PathE=
PathE='/cluster/projects/nn9348k/Rune/WeathPers25/work/ExtrArc/'

fileVar=PathE+'FigData/Z.Rolling.Regress.nc' 
ZanDp=xr.open_dataset(fileVar)['Z']

fileVar=PathE+'FigData/uM.Rolling.Regress.nc'
UManDp=xr.open_dataset(fileVar)['uM']

fileVar=PathE+'FigData/SATPersAnomExt.Roll.Regress.1979-2023.nc'
ANp=xr.open_dataset(fileVar)['Anom']

fileVar=PathE+'FigData/UMZcovO.lenRM'+str(lenRM)+'.nc'
UMZcovO=xr.open_dataset(fileVar)['UMZcov']

fileVar=PathE+'FigData/ANZcovO.lenRM'+str(lenRM)+'.nc'
ANZcovO=xr.open_dataset(fileVar)['ANZcov']

UManDpO=UManDp*1.
ANpO=ANp*1.

DayOff=180
UManDps=UManDp[DayOff:-DayOff]
ANps=ANp[DayOff:-DayOff]

stdate=int(1.5*365)
ZanDp=ZanDp/1.E3
Zmean=np.mean(ZanDp[stdate:-stdate])
Zvar=np.var(ZanDp[stdate:-stdate])
Zlen=len(ZanDp[stdate:-stdate])
Za=(ZanDp-Zmean).rolling(time=lenRM,center=True).mean()

Nlen=90
ishift=0
if (useAN=='m'):
  ishift=Nlen/2
elif (useAN=='l'):
  ishift=Nlen

lags=range(-180,180+1)
Nlags=len(lags)

for iMC in range(NMC):
  if (iMC % 100) == 0: print("iMC: "+str(iMC))
#  print("Phase shift")
  UManDpfx=xfft_T(UManDps)
  ANpfx=xfft_T(ANps)

  time=ANpO.time  
  Ntime=np.size(time)
  UManDpf = xr.DataArray(np.zeros([Ntime]), \
      coords=[time], dims=["time"])
  UManDpf[DayOff:-DayOff]=UManDpfx
  ANpf = xr.DataArray(np.zeros([Ntime]), \
      coords=[time], dims=["time"])
  ANpf[DayOff:-DayOff]=ANpfx

##################################
# Check auto-correlation
#lags=range(510)
#x=ANpf.data
#y=ANpff.data
#mean=np.mean(x)
#var=np.var(x)
#xp=x-mean
#corr1=[1. if l==0 else np.sum(xp[l:]*xp[:-l])/len(x)/var for l in lags]
#print(np.array(corr1))
#mean=np.mean(y)
#var=np.var(y)
#xp=y-mean
#corr=[1. if l==0 else np.sum(xp[l:]*xp[:-l])/len(y)/var for l in lags]
#print(np.array(corr))
#fig,ax=plt.subplots()
#ax.plot(lags,corr1)
#ax.plot(lags,corr)
####################################

  UManDp=UManDpf/1.E4
  UMmean=np.mean(UManDp[stdate:-stdate])
  UMvar=np.var(UManDp[stdate:-stdate])
  UMa=(UManDp-UMmean).rolling(time=lenRM,center=True).mean()

  ANmean=np.mean(ANpf[stdate:-stdate])
  ANvar=np.var(ANpf[stdate:-stdate])
  ANa=(ANpf-ANmean)

  UMZcov = xr.DataArray(np.zeros([Nlags]), \
      coords=[lags], dims=["lag"])
  ANZcov = xr.DataArray(np.zeros([Nlags]), \
      coords=[lags], dims=["lag"])

  ilag=0
  for l in lags:
    UMZcov[ilag]=np.sum(Za[stdate:-stdate].data*\
                      UMa[stdate+l:-stdate+l].data)/Zlen/Zvar*Zvar**(1/2)
    ANZcov[ilag]=np.sum(Za[stdate:-stdate].data*\
                      ANa[stdate+l-ishift:-stdate+l-ishift].data)/\
                      Zlen/Zvar*Zvar**(1/2)
    ilag=ilag+1

  # Compare random to origiional
  UMZcovMCn=xr.DataArray(np.zeros([Nlags]),\
      coords=[lags],dims=["lag"])
  UMZcovMCn[:] = 1
  UMZcovMCn = UMZcovMCn.where(np.fabs(UMZcovO) > \
                                  np.fabs(UMZcov), 0)

  ANZcovMCn=xr.DataArray(np.zeros([Nlags]),\
      coords=[lags],dims=["lag"])
  ANZcovMCn[:] = 1
  ANZcovMCn = ANZcovMCn.where(np.fabs(ANZcovO) > \
                                  np.fabs(ANZcov), 0)

#  for i in range(Nlags):
#    print(str(UMZcovO[i].data)+' '+str(UMZcov[i].data)+' '+str(UMZcovMCn[i].data)+' '+str(lags[i]))

  dsUMZcovMCn=UMZcovMCn.to_dataset(name='UMZcovMC')
  dsANZcovMCn=ANZcovMCn.to_dataset(name='ANZcovMC')
  NMC1=1
  dsUMZcovMCn=dsUMZcovMCn.assign(NMC=NMC1)
  dsANZcovMCn=dsANZcovMCn.assign(NMC=NMC1)

  if iMC==0:
    dsUMZcovMC=dsUMZcovMCn.copy()
    dsANZcovMC=dsANZcovMCn.copy()
  else:
    dsUMZcovMC= dsUMZcovMC+dsUMZcovMCn
    dsANZcovMC= dsANZcovMC+dsANZcovMCn
    
fileMC = PathE+'MC/UMExtRollRegress2.lenRM'+str(lenRM)+'.nc'
fileMC_back = PathE+'MC/back/UMExtRollRegress2.lenRM'+str(lenRM)+'.nc'
if not os.path.isfile(fileMC):
  dsUMZcovMCs=dsUMZcovMC.copy()
  print(fileMC+" is missing!!")
else:
  dsUMZcovMCs=xr.open_dataset(fileMC)
  dsUMZcovMCs=dsUMZcovMCs+dsUMZcovMC
  os.system('cp -f '+fileMC+' '+fileMC_back )
os.system('rm -f '+fileMC)
dsUMZcovMCs.to_netcdf(fileMC)

fileMC = PathE+'MC/PersAnomExtRollRegress2.lenRM'+str(lenRM)+'.nc'
fileMC_back = PathE+'MC/back/PersAnomExtRollRegress2.lenRM'+str(lenRM)+'.nc'
if not os.path.isfile(fileMC):
  dsANZcovMCs=dsANZcovMC.copy()
  print(fileMC+" is missing!!")
else:
  dsANZcovMCs=xr.open_dataset(fileMC)
  dsANZcovMCs=dsANZcovMCs+dsANZcovMC
  os.system('cp -f '+fileMC+' '+fileMC_back )
os.system('rm -f '+fileMC)
dsANZcovMCs.to_netcdf(fileMC)

print("Done PersAnom_Regress_MC2 with NMC="+str(NMC))
