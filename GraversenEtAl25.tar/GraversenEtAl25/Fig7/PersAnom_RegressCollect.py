# -*- coding: utf-8 -*-
#
# PersAnom_RegressCollect.py
#
# sys.argv[1]: Start year
# sys.argv[2]: End year
# sys.argv[3]: Length of period over which to calculate temperature anomalies
####################

import xarray as xr
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cftime
import sys
import numpy as np
np.round_ = np.round
import xrft
import os

Styear = int(sys.argv[1])
Endyear = int(sys.argv[2])
Nlen  = int(sys.argv[3])
#Styear = 1979
#Endyear = 1980
#Nlen = 90
Nyears=Endyear-Styear+1

PathE=
PathW=
#PathE='/cluster/projects/nn9348k/Rune/WeathPers25/work/ExtrArc/'
#PathW='/cluster/projects/nn9348k/Rune/WeathPers25/work/work/Regress/'

pathExt=[]
for iy in np.arange(Styear,Endyear+1):
  pathExt.append(PathW+'SATPersAnomExtAll.Roll.Regress.'+str(iy)+'.'+str(Nlen)+'.nc')

dsPersDiff=xr.open_mfdataset(pathExt,concat_dim='time',combine='nested').\
  compute()

fileExt_tot=PathE+'Fig/SATPersAnomExt.Roll.Regress.'+\
                     str(Styear)+'-'+str(Endyear)+'.Nlen'+str(Nlen)+'.nc'

if os.path.isfile(fileExt_tot):
  os.system("rm -f "+fileExt_tot)

dsPersDiff.to_netcdf(fileExt_tot)

for iy in np.arange(Nyears):
  os.system("rm -f "+pathExt[iy])

print(" .. end collect")
