# -*- coding: utf-8 -*-
#
# PersAnom_Regression.py
#
# sys.argv[1] iyear
# sys.argv[2] Nlen
#
# Input data produced by "WeathVar.py"
#          and WarmArctic.py
####################

import xarray as xr
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cftime
import sys
import numpy as np
np.round_ = np.round
import time as TimeRun
import xrft
import os

#########################
# Setting tool script dir
# directory to tools script (tools.py and tools_plot.py)
toolPath=<tools_script_dir>
#toolPath='/cluster/home/runegg/python/WeathPers25/'
try:
    sys.path.index(toolPath) 
except ValueError:
    sys.path.append(toolPath)
from tools import PersAnom, filter_run_mean_time_lat_lon
from tools_plot import Plot2, Plot4

btime=TimeRun.time()

iyear  = int(sys.argv[1])
Nlen  = int(sys.argv[2])
#iyear=2023
#Nlen=90

PathW=
PathE=
PathAW=
#PathW='/cluster/projects/nn9348k/Rune/WeathPers25/work/SATvar/'
#PathE='/cluster/projects/nn9348k/Rune/WeathPers25/work/work/Regress/'
#PathAW='/cluster/projects/nn9348k/Rune/WeathPers25/work/ExtrArc/'

LatEnd=40
LatStep=10
LatStart=70
LatLoop = np.arange(LatStart,LatEnd,-LatStep)

lat=xr.open_dataset(PathW+'/SATrm.1979.nc').lat
dlat=np.abs(lat[0].data-lat[1].data)

fileVarA=PathE+'SATPersAnomExtAll.Roll.Regress.'+str(iyear)+'.'+str(Nlen)+'.nc'

Ndays=365#*(yeare-yearb+1)

anB=0.0
first=True
for Lati in LatLoop:
  print("Calculating for latitude: "+str(Lati))
  latb=Lati
  late=Lati-LatStep+dlat

  pathSAT=PathW+'SATan'+'_Lat'+str(late)+'to'+str(latb)+'.nc'

  SATan=xr.open_dataset(pathSAT)['urm'].compute()

  SATan=SATan.isel(time=(SATan.time.dt.year.isin(np.arange(iyear,iyear+1+1,1))))
  time=SATan.time[0:Ndays]  
  lat=SATan.lat  
  lon=SATan.lon
  Nlat=np.size(lat)
  Nlon=np.size(lon)
  dsLenL = xr.DataArray(np.zeros([Ndays,Nlen,Nlat,Nlon]), \
      coords=[time,np.arange(1,Nlen+1),lat,lon], dims=["time","len","lat","lon"])

  Dran=np.arange(0,Ndays)
  if (iyear==1979): Dran=np.arange(2*Nlen,Ndays)
  if (iyear==2023): Dran=np.arange(0,Ndays-2*Nlen)

  for idate in Dran:
#    print(idate)
    SATanYx=SATan[idate:idate+Nlen,:,:]
    SATanY=SATanYx-SATanYx.mean(dim="time")
    dsLenLp = PersAnom(SATanY,Nlen,anB)
    dsLenLn = PersAnom(-1.*SATanY,Nlen,anB)
    dsLenL[idate,:,:,:]=dsLenLp+dsLenLn
  
  del SATan

  if (first):
    dsLen=dsLenL*1.
  else:
    dsLen=xr.concat([dsLen,dsLenL],dim="lat")       

  first=False

for ilen in np.arange(0,Nlen):
  dsLen[:,ilen,:,:] = dsLen[:,ilen,:,:]*(ilen+1)

latAN=dsLen['lat']
lonAN=dsLen['lon']
lenAN=dsLen['len']
NlatAN=np.size(latAN)
NlonAN=np.size(lonAN)
NlenAN=np.size(lenAN)
latANb=45
latANe=70
lonANb=-180
lonANe=179.5
lenANsplit=3 

coslat=np.cos(np.deg2rad(latAN))

ANp=dsLen.\
      sel(lon=((lonAN>=lonANb) & (lonAN<=lonANe))).\
      sel(lat=((latAN>=latANb) & (latAN<=latANe))).\
      weighted(coslat).mean(('lat','lon')).\
      sel(len=(lenAN>=lenANsplit)).sum(dim='len')

os.system("rm -vf "+fileVarA)
ANp.rename('Anom').to_netcdf(fileVarA)

print(" ")
print("##################")
Ttime=TimeRun.time()-btime
print("Running time "+str(np.floor(Ttime/60))+" min and "+str(np.floor(Ttime % 60))+"\
 sec")
print("##################")
print(" ")
