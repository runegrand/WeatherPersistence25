# -*- coding: utf-8 -*-
## ExtRolling.py
#
# Lag regressions of temperature persistence uM and dZ
# Plot of Fig. 7
# Input data produced by "WeathVar.py"
#     and PersAnom_Regress.sh
#
####################
import xarray as xr
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cftime
import sys
import numpy as np
np.round_ = np.round
import time as TimeRun
import xrft
import os

#########################
# Setting tool script dir
# directory to tools script (tools.py and tools_plot.py)
toolPath=<tools_script_dir>
#toolPath='/cluster/home/runegg/python/WeathPers25/'
try:
    sys.path.index(toolPath)
except ValueError:
    sys.path.append(toolPath)
from tools import PersAnom, filter_run_mean_time_lat_lon
from tools_plot import Plot2, Plot4

btime=TimeRun.time()

MakeVar=False
ETlat=60
useAN='l'  #l: left, m: middle, r: right
lenRM=1    # Running mean for uM, Z500, SAT, and ET

Styear=1979
Endyear=2023

PathW=
PathUM=
PathZ=
pathAN=
PathE=
PathFig=
#PathW='/cluster/projects/nn9348k/Rune/WeathPers25/work/SATvar/'
#PathUM='/cluster/projects/nn9348k/Rune/WeathPers25/work/uM/'
#PathZ='/cluster/projects/nn9348k/Rune/WeathPers25/work/Z/'
#pathAN='/cluster/projects/nn9348k/Rune/WeathPers25/work/ExtrArc/FigData/'
#PathE='/cluster/projects/nn9348k/Rune/WeathPers25/work/ExtrArc/'
#PathFig='/cluster/projects/nn9348k/Rune/WeathPers25/Fig/'

PI=3.1415
dtor = 2*PI/360.
R=3671.e3

lat=xr.open_dataset(PathW+'/SATrm.1979.nc').lat
dlat=np.abs(lat[0].data-lat[1].data)

Nlen=95

Nlag=90 #90  # ilag=[-Nlag,Nlag]

lonb=-180 #-90  #-180 #-90
lone=179.5  #20 #179.5 #20
latb=ETlat

latANb=45#45
latANe=70#75
lonANb=-180 #-90
lonANe=179.5  #20 #130

#######################################
print("Calculating for Z")
fileVar=PathE+'FigData/Z.Rolling.Regress.nc'                                           
LatEnd=40
LatBeg=70
LatStep=10
LatLoop = np.arange(LatBeg,LatEnd,-LatStep)
if MakeVar:
  first=True
  for Lati in LatLoop:
    print("Calculating for latitude: "+str(Lati))
    latb=Lati
    late=Lati-LatStep+dlat
#    if ((late-dlat)==LatEnd):
#      late=LatEnd
      
    pathSAT=PathZ+'Zan'+'_Lat'+str(late)+'to'+str(latb)+'.nc'

    SATan=xr.open_dataset(pathSAT)['Z500'].compute()
    SATanX=SATan.isel(time=(SATan.time.dt.year.isin(np.arange(Styear,Endyear+1,1))))
    SATanX=SATanX-SATanX.mean(dim="time")
    time=SATanX.time

    del SATan

    if (first):
      ZanD=SATanX*1.
    else:
      ZanD=xr.concat([ZanD,SATanX],dim="lat")

    first=False

  ZanD=ZanD.rename('Z')

  latZ=ZanD['lat']
  lonZ=ZanD['lon']
  coslat=np.cos(np.deg2rad(latZ))
  ZanDp=(ZanD.\
    sel(lon=((lonZ>=lonb) & (lonZ<=lone))).\
    sel(lat=((latZ>=latb) & (latZ<=90))).\
    weighted(coslat).mean(("lat","lon"))-
    ZanD.\
    sel(lon=((lonZ>=lonb) & (lonZ<=lone))).\
    sel(lat=((latZ>=20) & (latZ<=latb))).\
    weighted(coslat).mean(("lat","lon")))

  os.system("rm -f "+fileVar)
  ZanDp.to_netcdf(fileVar)
else:
  ZanDp=xr.open_dataset(fileVar)['Z']

#######################################                                  
print("Calculating for uM")
fileVar=PathE+'FigData/uM.Rolling.Regress.nc'
LatEnd=40
LatBeg=70
LatStep=10
LatLoop = np.arange(LatBeg,LatEnd,-LatStep)
if MakeVar:
  first=True
  for Lati in LatLoop:
    print("Calculating for latitude: "+str(Lati))
    latb=Lati
    late=Lati-LatStep+dlat
#    if ((late-dlat)==LatEnd):
#      late=LatEnd

    pathSAT=PathUM+'uMan'+'_Lat'+str(late)+'to'+str(latb)+'.nc'

    SATan=xr.open_dataset(pathSAT)['uM'].compute()
    SATanX=SATan.isel(time=(SATan.time.dt.year.isin(np.arange(Styear,Endyear+1,1))))
    SATanX=SATanX-SATanX.mean(dim="time")
    time=SATanX.time

    del SATan

    if (first):
      uManD=SATanX*1.
    else:
      uManD=xr.concat([uManD,SATanX],dim="lat")

    first=False

  uManD=uManD.rename('uM')

  latuM=uManD['lat']
  lonuM=uManD['lon']
  coslat=np.cos(np.deg2rad(latuM))
  UManDp=uManD.\
      sel(lon=((lonuM>=lonANb) & (lonuM<=lonANe))).\
      sel(lat=((latuM>=latANb) & (latuM<=latANe))).\
      weighted(coslat).mean(('lat','lon'))
  
  os.system("rm -f "+fileVar)
  UManDp.to_netcdf(fileVar)
else:
  UManDp=xr.open_dataset(fileVar)['uM']

###################################
print("Open for Anom")

Nlen=90
fileVar=PathE+'FigData/SATPersAnomExt.Roll.Regress.1979-2023.nc'
ANp=xr.open_dataset(fileVar)['Anom']

# MC
fileANMC=PathE+'MC/PersAnomExtRollRegress2.lenRM'+str(lenRM)+'.nc'
dsANZcovMC=xr.open_dataset(fileANMC)
ANZcovMC=dsANZcovMC['ANZcovMC']/dsANZcovMC['NMC']

fileUMMC = PathE+'MC/UMExtRollRegress2.lenRM'+str(lenRM)+'.nc'
dsUMZcovMC=xr.open_dataset(fileUMMC)
UMZcovMC=dsUMZcovMC['UMZcovMC']/dsUMZcovMC['NMC']

###############################################
print("covariance")
stdate=int(1.5*365)

ZanDp=ZanDp/1.E3
Zmean=np.mean(ZanDp[stdate:-stdate])
Zvar=np.var(ZanDp[stdate:-stdate])
Zlen=len(ZanDp[stdate:-stdate])
Za=(ZanDp-Zmean).rolling(time=lenRM,center=True).mean()

UManDp=UManDp/1.E4
UMmean=np.mean(UManDp[stdate:-stdate])
UMvar=np.var(UManDp[stdate:-stdate])
UMa=(UManDp-UMmean).rolling(time=lenRM,center=True).mean()

ANmean=np.mean(ANp[stdate:-stdate])
ANvar=np.var(ANp[stdate:-stdate])
ANa=(ANp-ANmean)

#Nlen=90
ishift=0
if (useAN=='m'):
  ishift=Nlen/2
elif (useAN=='l'):
  ishift=Nlen

lags=range(-180,180+1)
Nlags=len(lags)

ZZcov = xr.DataArray(np.zeros([Nlags]), \
      coords=[lags], dims=["lag"])
UMZcov = xr.DataArray(np.zeros([Nlags]), \
      coords=[lags], dims=["lag"])
ANZcov = xr.DataArray(np.zeros([Nlags]), \
      coords=[lags], dims=["lag"])

ilag=0
for l in lags:
  ZZcov[ilag]=np.sum(Za[stdate:-stdate].data*Za[stdate+l:-stdate+l].data)/Zlen/Zvar*Zvar**(1/2)
  UMZcov[ilag]=np.sum(Za[stdate:-stdate].data*UMa[stdate+l:-stdate+l].data)/Zlen/Zvar*Zvar**(1/2)
  ANZcov[ilag]=np.sum(Za[stdate:-stdate].data*ANa[stdate+l-ishift:-stdate+l-ishift].data)/\
      Zlen/Zvar*Zvar**(1/2)
  ilag=ilag+1
  
UMZcov=UMZcov.rename('UMZcov')
fileVar=PathE+'FigData/UMZcovO.lenRM'+str(lenRM)+'.nc'
os.system("rm -f "+fileVar)
UMZcov.to_netcdf(fileVar)

ANZcov=ANZcov.rename('ANZcov')
fileVar=PathE+'FigData/ANZcovO.lenRM'+str(lenRM)+'.nc'
os.system("rm -f "+fileVar)
ANZcov.to_netcdf(fileVar)

#######################################
# Plot:GPH gradient -- Zonal mass flux -- Anomales (Fig6regression)
fig, ax1 = plt.subplots(figsize=(9, 6))
colorp='blue'
ax1.set_xlabel('lag [days]',fontsize=14)
ax1.set_ylabel('Zonal mass flux [10$^4$ kg m$^{-1}$ s$^{-1}$]', \
               color=colorp,fontsize=16)
ax1.plot(UMZcov.lag,UMZcov,color=colorp,linewidth=3)
ax1.tick_params(axis='y', labelcolor=colorp, width=2, labelsize=14)
ax1.tick_params(axis='x', width=2, labelsize=12)
ax1.spines['top'].set_linewidth(2)  # Thicker frame
ax1.spines['right'].set_linewidth(2)
ax1.spines['left'].set_linewidth(2)
ax1.spines['bottom'].set_linewidth(2)
colorp='red'
ax2=ax1.twinx()
ax2.set_ylabel('Arctic-midlatitude 500 hPa GPH difference [10$^3$ m]',
               color=colorp,fontsize=16)
ax2.plot(ZZcov.lag,ZZcov,color=colorp,linewidth=3)
ax2.tick_params(axis='y', labelcolor=colorp, width=2, labelsize=14)
colorp='green'
ax3=ax1.twinx()
ax3.spines['right'].set_position(('outward', 80))
ax3.set_frame_on(True)
ax3.patch.set_visible(False)
ax3.yaxis.set_ticks_position('right')
ax3.yaxis.set_label_position('right')
ax3.set_ylabel('Persistence [days]',\
               color=colorp,fontsize=16)
ax3.plot(ANZcov.lag,ANZcov,color=colorp,linewidth=3)
ax3.tick_params(axis='y', labelcolor=colorp, width=2, labelsize=14)
ax3.spines['right'].set_linewidth(2)
ax1.set_xlim(-90, 180)
#ax1.set_ylim(0.2, -0.2*6.)
#ax2.set_ylim(-0.05, 0.05*6.)
ax1.set_ylim(0.27, -0.27*6.)
ax2.set_ylim(-0.07, 0.07*6.)
ax3.set_ylim(-0.05, 0.05*6.)
UMZcovSig=UMZcov.where(UMZcovMC > 0.99, np.nan)
ax1.plot(UMZcov.lag,UMZcovSig,color='blue',linewidth=15,alpha=0.3)
ANZcovSig=ANZcov.where(ANZcovMC > 0.99, np.nan)
ax3.plot(ANZcov.lag,ANZcovSig,color='green',linewidth=15,alpha=0.3)
# Add a horizontal line at y=0 for each axis
ax1.axhline(0, color='black', linewidth=1.5, linestyle='--')
fig.tight_layout()
plt.title('Regression',
          fontsize=18)
FigForm='eps'
#Fignm='Fig6_regression.'+FigForm
Fignm='Fig7.'+FigForm
plt.savefig(PathFig+Fignm,bbox_inches='tight',
              pad_inches=0.02,format=FigForm)
plt.show()
plt.close()

# Write out Fig 7 data for Figshare, Nov 2025
dsF1=xr.DataArray(UMZcov,coords={'lag': UMZcov.lag}, dims=["lag"]).rename('uM')
dsF2=xr.DataArray(ZZcov,coords={'lag': ZZcov.lag}, dims=["lag"]).rename('Z500')
dsF3=xr.DataArray(ANZcov,coords={'lag': ANZcov.lag}, dims=["lag"]).rename('Pers')
dsF1S=xr.DataArray(UMZcovMC,coords={'lag': UMZcovMC.lag}, dims=["lag"]).rename('uM_Sig')
dsF3S=xr.DataArray(ANZcovMC,coords={'lag': ANZcovMC.lag}, dims=["lag"]).rename('Pers_Sig')
dsFig7=xr.merge([dsF1,dsF2,dsF3,dsF1S,dsF3S])
dsFig7.attrs["Units"]='Pers: days; uM: 10^4 kg m-1 s-1: Z500: 10^3 m; Pers/uM_Sig: %'
dsFig7.attrs["Description"]='Regression of Z500 on zonal mass flux, Z500, and persistence as a function of time lag. Pers/uM_Sig indicate confidence level of Pers and uM, respectively. Persistence is number of days within anomalies lasting at least three days, calculated over a 90 day period prior to the lag day. Z500 is the difference in geopotential height between the Arctic and the mid-latitudes.'
FilenmFigData=PathFig+'Fig7data.nc'
os.system("rm -vf "+FilenmFigData)
dsFig7.to_netcdf(FilenmFigData)

print(" ")
print("##################")
Ttime=TimeRun.time()-btime
print("Running time "+str(np.floor(Ttime/60))+" min and "+str(np.floor(Ttime % 60))+" sec")
print("##################")
print(" ")
