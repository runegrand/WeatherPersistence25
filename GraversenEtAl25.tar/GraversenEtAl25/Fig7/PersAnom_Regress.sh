#!/bin/bash
# PersAnom_Regress.sh
#
# Calculate temperature persistence over a 90 day period
# shifted for each day in the data set
#
# Uses:
# -- PersAnom_Regress.py: provides calculations for each lag day, year by year
# -- PersAnom_Regressollect.py: combines all years into a single file
#
# Rune Grand Graversen: rune.graversen@uit.no
##################################

#SBATCH --account=nn9348k
#SBATCH --job-name=Weath_MC
#SBATCH --nodes=1
#SBATCH --time=36:05:00
#SBATCH --mem-per-cpu=8G

Styear=1979
Endyear=2023
Nlen=90

Pro="python3 PersAnom_Regress.py"
ProColl="python3 PersAnom_RegressCollect.py"

# The following must be set:
source /cluster/home/runegg/python/WeathPers25/.Pyth_login
cd /cluster/home/runegg/python/WeathPers25/PersAnom/Rolling/Regress

# The set of parallel runs:
for i in $(seq $Styear 1 $Endyear); do
    srun --ntasks=1 --exact $Pro $i $Nlen &
    echo srun --ntasks=1 --exact $Pro $i $Nlen
    wait
done

$ProColl $Styear $Endyear $Nlen

echo " ... PersAnom_Regress.py done"

exit 0
