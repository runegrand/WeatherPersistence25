# -*- coding: utf-8 -*-
# Warm Arctic.py
# 
# Calculate 3-month Arctic, north of 60 N, warm and cold events where Arctic is
# warmer or colder than pluss one or minus one standard deviation,
# repsectively, relative to the background climatology.
# The events are based on SAT, T at 500 hPa, or Z at 500 hPa; in this study
# Z at 500 hPa is used.
#
# Input data produced by "Climatological_MM.sh"
#
# Rune Grand Graversen: rune.graversen@uit.no
####################

import xarray as xr
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cftime
import sys
import numpy as np
import xrft
import os
import math

###########################
# Setting
# PathSAT: SAT input directory; PathT: T input directory;
# PathZ: Z input directory; PathW: output directory
# 
pathSAT=<SAT_inout_directory>
pathSAT=<T_inout_directory>
pathSAT=<Z_inout_directory>
pathSAT=<output_directory>
#PathSAT='/nird/datalake/NS9063K/LongBackup/era5/surface/analysis/monthly/SAT/2.5x2.5/NC/'
#PathT='/nird/datalake/NS9063K/LongBackup/era5/Pres/analysis/monthly/T/2.5x2.5/NC/'
#PathZ='/nird/datalake/NS9063K/LongBackup/era5/Pres/analysis/monthly/Z/2.5x2.5/NC/'
#PathW='/nird/datalake/NS9063K/Rune/WorkWeathVar/ExtrArc/'
###########################

Yearstart=1979
Nyears=45

LatArctic=60
LatTrop=20
Plev=50000

Ys = np.arange(Yearstart,Yearstart+Nyears,1)

def extremes(time,y,std):
  # Find periods above 1 std or below -1 std
  # at least lasting 3 months
  # The first month in each period is chosen 
  x1 = y.shift(time=-1) 
  x2 = y.shift(time=-2)
  if (std>0):
    it=np.where((y > std) & (x1 > std) & (x2 > std))[0]
  else:
    it=np.where((y < std) & (x1 < std) & (x2 < std))[0]
  itt=np.delete(it,np.where((it-np.roll(it,1))==1))
  timer=time[itt]
  return timer

pathSAT=[]
pathSATcl=[]
pathT=[]
pathTcl=[]
pathZ=[]
pathZcl=[]
for y in Ys:
  pathSAT.append(PathSAT+'/SAT.'+str(y)+'.nc')
  pathSATcl.append(PathSAT+'/SATcl.'+str(y)+'.nc')
  pathT.append(PathT+'/T.'+str(y)+'.nc')
  pathTcl.append(PathT+'/Tcl.'+str(y)+'.nc')
  pathZ.append(PathZ+'/Z.'+str(y)+'.nc')
  pathZcl.append(PathZ+'/Zcl.'+str(y)+'.nc')

dsSAT=xr.open_mfdataset(pathSAT,concat_dim='time',combine='nested')['T2M'].compute()
dsSATcl=xr.open_mfdataset(pathSATcl,concat_dim='time',combine='nested')['T2M'].compute()
dsSATan = (dsSAT-dsSATcl)
dsT=xr.open_mfdataset(pathT,concat_dim='time',combine='nested')['T'].compute()
dsTcl=xr.open_mfdataset(pathTcl,concat_dim='time',combine='nested')['T'].compute()
dsTan = (dsT-dsTcl)
dsZ=xr.open_mfdataset(pathZ,concat_dim='time',combine='nested')['Z'].compute()
dsZcl=xr.open_mfdataset(pathZcl,concat_dim='time',combine='nested')['Z'].compute()
dsZan = (dsZ-dsZcl)

time=dsSAT.time
Ntime=np.size(time)
lat=dsSAT.lat
dlat=np.abs(lat[0].data-lat[1].data)
ilatA=np.where(np.abs(lat-LatArctic)<dlat/2)[0][0]
ilatT=np.where(np.abs(lat-LatTrop)<dlat/2)[0][0]
pres=dsT.plev
ipres=np.where(np.abs(pres-Plev)<100)[0][0]

coslat=np.cos(lat*math.pi/180.)

AWan=(dsSATan*coslat)[:,0:ilatA,:].mean(dim=['lon','lat'])/coslat[0:ilatA].mean()
TWan=(dsSATan*coslat)[:,ilatA:ilatT,:].mean(dim=['lon','lat'])/coslat[ilatA:ilatT].mean()
PAan=(AWan-TWan)
AWTan=(dsTan*coslat)[:,ipres,0:ilatA,:].mean(dim=['lon','lat'])/coslat[0:ilatA].mean()
TWTan=(dsTan*coslat)[:,ipres,ilatA:ilatT,:].mean(dim=['lon','lat'])/coslat[ilatA:ilatT].mean()
AWZan=(dsZan*coslat)[:,ipres,0:ilatA,:].mean(dim=['lon','lat'])/coslat[0:ilatA].mean()
TWZan=(dsZan*coslat)[:,ipres,ilatA:ilatT,:].mean(dim=['lon','lat'])/coslat[ilatA:ilatT].mean()
PATan=(AWTan-TWTan)
PAZan=(AWZan-TWZan)

runmean=3
PAanrm=PAan.rolling(time=runmean,center=True).mean()
PATanrm=PATan.rolling(time=runmean,center=True).mean()
PAZanrm=PAZan.rolling(time=runmean,center=True).mean()

PAanstd=PAanrm.std()
PATanstd=PATanrm.std()
PAZanstd=PAZanrm.std()

timerSATp=extremes(time,PAanrm,PAanstd)
timerSATn=extremes(time,PAanrm,-PAanstd)
timerTp=extremes(time,PATanrm,PATanstd)
timerTn=extremes(time,PATanrm,-PATanstd)
timerZp=extremes(time,PAZanrm,PAZanstd)
timerZn=extremes(time,PAZanrm,-PAZanstd)

timeA=xr.Dataset(data_vars=dict(SATp=timerSATp,SATn=timerSATn,\
                Tp=timerTp,Tn=timerTn,Zp=timerZp,Zn=timerZn))
timeA.to_netcdf(PathW+"test/ArcticExtremes.nc")



