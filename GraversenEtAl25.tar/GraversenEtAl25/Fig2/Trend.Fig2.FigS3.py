# -*- coding: utf-8 -*-
# Trend.Fig2.FigS3.py
#
# Calculate trends of SAT, zonal mass flux (uM) and Z500 (Z)
# The trends are dfferences between two 15 year periods
#
# Inputdata are from:
#
# Rune Grand Graversen: rune.graversen@uit.no
####################

import xarray as xr
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cftime
import sys
import numpy as np
np.round_ = np.round
import xrft
import os

#########################
# Setting tool script dir
# directory to tools script (tools.py and tools_plot.py)
toolPath=<tools_script_dir>
#toolPath='/cluster/home/runegg/python/WeathPers25/GitHub/'
try:
    sys.path.index(toolPath) 
except ValueError:
    sys.path.append(toolPath)
from tools_plot import Plot2_2, Plot1Ext
from tools import filter_run_mean_lat_lon

########################
# Settings
MakeVar=False   # True: calculate trend of Pvar and save
                # False: Use saved files of uM, SAT, and Z.
Pvar = "uM"     # Set to: "uM", "SAT", or "Z".

# PathE is input data directory; PathFig is output directory
PathE=<input_dir>
PathFig=<output_dir>
#PathE='/cluster/projects/nn9348k/Rune/WeathPers25/work/'
#PathFig='/cluster/projects/nn9348k/Rune/WeathPers25/Fig/'

YEARE   = 1980 # Start year of early period
YEARL   = 2008 # Start year of late period
NyearsE = 15   # Number of years in early period
NyearsL = 15   # Number of years in late period

latb=90        # Nothern latitude boundary
late=20        # Southern latitude boundary
#######################

Yearstart=1979
Nyears=45

if (Pvar=="uM"):
  PathP=PathE+'uMmm/NC/'
elif (Pvar=="SAT"):
  PathP=PathE+'SAT/NC/'
elif (Pvar=="Z"):
  PathP=PathE+'Z/NC/'
else:
  print("Pvar must be 'uM', 'SAT', 'Z'")
  sys.exit()

Ys = np.arange(Yearstart,Yearstart+Nyears,1)

lat=xr.open_dataset(PathP+Pvar+'.'+str(Yearstart)+'.nc').lat
dlat=np.abs(lat[0].data-lat[1].data)
ilatb=np.where(np.abs(lat-latb)<dlat/2)[0][0]
ilate=np.where(np.abs(lat-late)<dlat/2)[0][0]

fileVar=PathE+'ExtrArc/FigData/'+Pvar+'Trend.nc'

if MakeVar:
  fileP=[]
  for y in Ys:
    fileP.append(PathP+Pvar+'.'+str(y)+'.nc')
  filePcl=PathP+Pvar+'.Clim.nc'

  dsP=xr.open_mfdataset(fileP,concat_dim='time',combine='nested').\
           isel(lat=slice(ilatb,ilate+1)) 
  dsPcly=xr.open_dataset(filePcl).\
           isel(lat=slice(ilatb,ilate+1)) 
  for y in Ys:
    dsPcly['time']=dsP['time'].isel(time=(dsP.time.dt.year==y))
    if (y==Yearstart):
      dsPcl=dsPcly*1.
    else:
      dsPcl=xr.concat([dsPcl,dsPcly],dim='time')
  
  dsPan = (dsP-dsPcl).compute()
  if (Pvar=='uM'):
    Pan=dsPan['uM']
  elif (Pvar=='SAT'):
    Pan=dsPan['T2M']
  elif (Pvar=='Z'):
    Pan=dsPan['Z']

  time=Pan.time

  # Calculate mean over early and late period
  PanE = Pan.isel(time=(Pan.time.dt.year.
              isin(np.arange(YEARE,YEARE+NyearsE,1)))).mean(dim='time')
  PanL = Pan.isel(time=(Pan.time.dt.year.
              isin(np.arange(YEARL,YEARL+NyearsL,1)))).mean(dim='time')

  # Calculate trend as the difference between the two periods
  PDiff = (PanL-PanE).rename('Trend')

  os.system("rm -vf "+fileVar)
  PDiff.to_netcdf(fileVar)
  sys.exit("Calculate and save trend of: "+Pvar)
else:

  fileVarZ=PathE+'ExtrArc/FigData/ZTrend.nc'
  ZDiff=xr.open_dataset(fileVarZ)['Trend'][0,:,:]/1.E2
  fileVarSAT=PathE+'ExtrArc/FigData/SATTrend.nc'
  SATDiff=xr.open_dataset(fileVarSAT)['Trend']
  fileVaruM=PathE+'ExtrArc/FigData/uMTrend.nc'
  uMDiff=xr.open_dataset(fileVaruM)['Trend']/1.E4

  PathMC=PathE+'/ExtrArc/MC/'
  uMDiffMC=xr.open_dataset(PathMC+Pvar+'.Trend.ID.nc')
  uMDiffMCsc = uMDiffMC/uMDiffMC.NMC

  lat=ZDiff.lat
  latb=30

  FigForm='pdf'
  FigTitle='Change in SAT, Z500, and uM'
  uTitle='SAT and Z500'
  vTitle='uM and Z500'
  CBTitleU='K'
  CBTitleV='10$^4$ kg m$^{-1}$ s$^{-1}$'

  FigFormx='eps'
  Fignm='Fig2.'+FigFormx
  Plot2_2(SATDiff.sel(lat=(lat > latb)),
          uMDiff.sel(lat=(lat > latb)),
          ZDiff.sel(lat=(lat > latb)),
          ZDiff.sel(lat=(lat > latb)),
          5,3,4,1,1,1,100,40,
          uTitle,vTitle,CBTitleU,CBTitleV,FigTitle,
          PathFig,Fignm,FigFormx)
#        None,None,None)

  # Write out Fig 2 data for Figshare, Nov 2025
  dsF1=SATDiff.sel(lat=(lat > latb)).rename('SATTrends')
  dsF2=uMDiff.sel(lat=(lat > latb)).rename('uMTrends')
  dsF3=ZDiff.sel(lat=(lat > latb)).rename('Z500Trends')
  dsFig2=xr.merge([dsF1,dsF2])
  dsFig2=xr.merge([dsFig2,dsF3])
  dsFig2.attrs["Units"]='SATTrends: K; uMTrends: 10^4 kg m-1 s-1; Z500Trends: m'
  dsFig2.attrs["Description"]='Change between 2008-2022 and 1980-1994 of SAT, zonal mass flux uM, and Z500. Z500 is the difference in geopotential height between the Arctic and the mid-latitudes.' 
  FilenmFigData=PathFig+'Fig2data.nc'
  os.system("rm -vf "+FilenmFigData)
  dsFig2.to_netcdf(FilenmFigData)

  FigTitle='' 
  uTitle='Change in uM and its significance'
  CBTitle=CBTitleV
  Fignm='FigS3.'+FigForm
  Plot1Ext(uMDiff.sel(lat=(lat > latb)),
           3,1,40,
           uTitle,CBTitle,FigTitle,
           uMDiffMCsc['Trend'].sel(lat=(lat > latb)),
           [0.9,0.99],
        PathFig,Fignm,FigForm)
#        None,None,None)
