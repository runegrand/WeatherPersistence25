#!/bin/bash
# WeathVar_PersAnomExt_MC.sh
#
# Calculate statistical significance of temperature persistence
# computed by PersAnomArcticExt.Fig5.py. An FFT approach randomly interchanging
# phases of modes in the time dimension is applied.
#
# Calculate temperature persistence over a 90 day period
# Uses:
# -- WeathVar_PersAnomExt_MC.py: provides significance calculations
# -- WeathVar_PersAnomExt_MCcollect.py: combines multible calculations
#    into a single file
#
# Rune Grand Graversen: rune.graversen@uit.no
################################################### 

#SBATCH --account=nn9348k
#SBATCH --job-name=Weath_MCext
#SBATCH --nodes=1
#SBATCH --time=36:05:00
#SBATCH --ntasks=20
#SBATCH --mem-per-cpu=8G

# The following must be set:
source /cluster/home/runegg/python/WeathPers25/.Pyth_login
cd /cluster/home/runegg/python/WeathPers25/PersAnom/Rolling

NMC=100  #120  #70
NbR=6
SNB=5  # Script number 
Meth='FFT'  # 'BS or 'FFT', random method

Pro="python3 WeathVar_PersAnomExt_MC.py"
Pro_collect="python3 WeathVar_PersAnomExt_MCcollect.py"

# The set of parallel runs:
for i in $(seq 1 1 $((NbR))); do
    srun --ntasks=1 --exact $Pro $NMC $SNB $i $Meth &
    echo srun --ntasks=1 --exact $Pro $NMC $SNB $i $Meth
done
wait
$Pro_collect $SNB $NbR $Meth
wait

echo " ... WeathVar_PersAnomExt_MC.py done"

exit 0
