# -*- coding: utf-8 -*-
#
# WeathVar_PersAnomExt_MCcollect.py
#
# sys.argv[1]: SNB Script number
# sys.argv[2] Number of Run
# sys.argv[3]: rMeth, Random method: 'BS' or 'FFT'                                                 
# Period starts YEAR and ends YEAR+Nyears
####################

import xarray as xr
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cftime
import sys
import numpy as np
np.round_ = np.round
import xrft
import os

#NbR=1
#SNB=1
#rMeth='BS'         
SNB=int(sys.argv[1])
NbR=int(sys.argv[2])
rMeth=sys.argv[3]

PathE=
#PathE='/cluster/projects/nn9348k/Rune/WeathPers25/work/ExtrArc/'

fileMC_tot = PathE+'MC/PersAnomExt.'+rMeth+'.nc'
fileMCb_tot = PathE+'MC/back/PersAnomExt.'+rMeth+'.nc' 

if os.path.isfile(fileMC_tot):
  VarDiffMC_tot=xr.open_dataset(fileMC_tot)
  for irun in np.arange(1,NbR+1):
    fileMC = PathE+'MC/run/PersAnomExt.Script'+str(SNB)+'.MCrun'+str(irun)+'.'+rMeth+'.nc'
    VarDiffMC=xr.open_dataset(fileMC)
    VarDiffMC_tot=VarDiffMC_tot+VarDiffMC
    os.system("rm -vf "+fileMC)
else:
  fileMC = PathE+'MC/run/PersAnomExt.Script'+str(SNB)+'.MCrun1.'+rMeth+'.nc'
  VarDiffMC=xr.open_dataset(fileMC)
  VarDiffMC_tot=VarDiffMC
  os.system("rm -vf "+fileMC)
  for irun in np.arange(2,NbR+1):
    print(irun)
    fileMC = PathE+'MC/run/PersAnomExt.Script'+str(SNB)+'.MCrun'+str(irun)+'.'+rMeth+'.nc'
    VarDiffMC=xr.open_dataset(fileMC)
    VarDiffMC_tot=VarDiffMC_tot+VarDiffMC
    os.system("rm -vf "+fileMC)

if os.path.isfile(fileMC_tot):
  os.system("mv -f "+fileMC_tot+" "+fileMCb_tot)

VarDiffMC_tot.to_netcdf(fileMC_tot)

print(" .. end collect")
