# -*- coding: utf-8 -*-
#
# WeathVar_PersAnomExt_MC.py
#
# sys.argv[1]: NMC, number of NC iterations
# sys.argv[2]: SNB Script number
# sys.argv[3] Run Number
# sys.argv[4]: rMeth, Random method: 'BS' or 'FFT'
# Periods (warm and cold Arctic) are produced by
#          WarmArctic.py
# Input data produced by "WeathVar.py"
####################

import xarray as xr
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cftime
import sys
import numpy as np
np.round_ = np.round
import time as TimeRun
import xrft
import os

#########################
# Setting tool script dir
# directory to tools script (tools.py and tools_plot.py)
toolPath=<tools_script_dir>
#toolPath='/cluster/home/runegg/python/WeathPers25/'
try:
    sys.path.index(toolPath) 
except ValueError:
    sys.path.append(toolPath)
from tools import PersAnom, filter_run_mean_time_lat_lon, xfft_TLL, Change_yr
import warnings 
warnings.filterwarnings("ignore", category=RuntimeWarning,
			module="xarray.coding.times")
warnings.filterwarnings("ignore", category=FutureWarning,
    module="xarray.core.accessor_dt")

btime=TimeRun.time()

MakeLS='S' # L: 'Long, S: Short

#NMC=2
#SNB=1
#RunNb=1
#rMeth='FFT'         
NMC=int(sys.argv[1])
SNB=int(sys.argv[2])
RunNb=int(sys.argv[3])
rMeth= sys.argv[4]

PathW=
PathE=
#PathW='/cluster/projects/nn9348k/Rune/WeathPers25/work/SATvar/'
#PathE='/cluster/projects/nn9348k/Rune/WeathPers25/work/ExtrArc/'

Evar = "Z" # "SAT", "T" or "Z"

LatEnd=20
LatStep=2
LatLoop = np.arange(90,LatEnd,-LatStep)

lat=xr.open_dataset(PathW+'/SATrm.1979.nc').lat
dlat=np.abs(lat[0].data-lat[1].data)

Nlen=90
if MakeLS=='S':
  lenb=[1,3,1,5,1,11]
  lene=[2,Nlen,4,Nlen,10,Nlen]
elif MakeLS=='L':  
  lenb=[1,5,8,15,31,95]  
  lene=[4,7,14,30,94,Nlen]  
else:
  sys.exit("MakeLS should by 'L' or 'S'!!")

Nlenb=np.size(lenb)

dates=xr.open_dataset(PathE+'ArcticExtremes.nc')
 
datpO=dates["Zp"]
datnO=dates["Zn"]
else:
  print("Evar must på 'SAT', 'T', or 'Z'")
  sys.exit()
Ndate=datpO.size
  
fileVar=PathE+'Fig/SATPersAnomExt.'+Evar+'.3.nc'
dsPersDiffO=xr.open_dataset(fileVar)

anB=0.0
for iMC in range(NMC):
  print("MC number: "+str(iMC))
  if (rMeth=='FFT'):
    datp=datpO
    datn=datnO
  elif (rMeth=='BS'):
    datpc=Change_yr(datpO,1980,2022)
    datnc=Change_yr(datnO,1980,2022)
    datp = xr.DataArray(datpc,dims=["time"],\
      coords={"time": np.arange(1,Ndate+1)},name="Zp")
    datn = xr.DataArray(datnc,dims=["time"],
      coords={"time": np.arange(1,Ndate+1)},name="Zn")
  else:
    sys.exit('"rMeth" must be either "BS" or "FFT"')

  first=True
  for Lati in LatLoop:
    print("Calculating for latitude: "+str(Lati))
    latb=Lati
    late=Lati-LatStep+dlat
    if ((late-dlat)==LatEnd):
      late=LatEnd

    pathSAT=PathW+'SATan'+'_Lat'+str(late)+'to'+str(latb)+'.nc'

    SATan=xr.open_dataset(pathSAT)['urm'].compute()
    SATan=SATan.isel(time=(SATan.time.dt.year.isin(np.arange(1980,2023,1))))
 
    if (rMeth=='FFT'):
      print("Phase shift")
      SATanr=xfft_TLL(SATan)
      print("Phase shift done")
    elif (rMeth=='BS'):
      SATanr=SATan
    else:
      sys.exit('"rMeth" must be either "BS" or "FFT"')

    del SATan

    time=SATanr.time  
    firstp=0
    firstn=0
    for idate in np.arange(0,Ndate):
      dp=datp[idate]
      dn=datn[idate]
      if not (np.isnat(dp)):
        if (dp.dt.year > 1979) & (dp.dt.year < 2023):
          iExt=np.where(time==dp)[0][0]
          SATanYx=SATanr[iExt:iExt+Nlen,:,:]  
          SATanY=SATanYx-SATanYx.mean(dim="time")
          dsLenLp = PersAnom(SATanY,Nlen,anB)
          dsLenLn = PersAnom(-1.*SATanY,Nlen,anB)
          if (firstp == 0):
            dsLenL=dsLenLp+dsLenLn
          else:
            dsLenL=dsLenL+(dsLenLp+dsLenLn)
          firstp=firstp+1
      if not (np.isnat(dn)):
        if (dn.dt.year > 1979) & (dn.dt.year < 2023):
          iExt=np.where(time==dn)[0][0]
          SATanYx=SATanr[iExt:iExt+Nlen,:,:]  
          SATanY=SATanYx-SATanYx.mean(dim="time")
          dsLenEp = PersAnom(SATanY,Nlen,anB)
          dsLenEn = PersAnom(-1.*SATanY,Nlen,anB)
          if (firstn == 0):
            dsLenE=dsLenEp+dsLenEn
          else:
            dsLenE=dsLenE+(dsLenEp+dsLenEn)
          firstn=firstn+1
     
    dsLenL=dsLenL/firstp
    dsLenE=dsLenE/firstn
    PersDiffL = dsLenL-dsLenE

    del SATanr

    if (first):
      PersDiff=PersDiffL*1.
    else:
      PersDiff=xr.concat([PersDiff,PersDiffL],dim="lat")    

    first=False

  lat=PersDiff.lat  
  lon=PersDiff.lon
  Nlat=np.size(lat)
  Nlon=np.size(lon)
  Lend = xr.DataArray(np.zeros([Nlen,Nlat,Nlon]), \
    coords=[np.arange(1,Nlen+1),lat,lon], dims=["len","lat","lon"])
  Lenb = xr.DataArray(np.zeros([Nlenb,Nlat,Nlon]), \
    coords=[np.arange(1,Nlenb+1),lat,lon], dims=["time","lat","lon"])

  for ilen in np.arange(0,Nlen):
    Lend[ilen,:,:] = PersDiff[ilen,:,:]*(ilen+1)  

  for ilen in np.arange(0,Nlenb):
    Lenb[ilen,:,:] = Lend[lenb[ilen]-1:lene[ilen],:,:].\
        sum(dim="len")*1.

  Lenb=filter_run_mean_time_lat_lon(Lenb,2)

  for ilen in np.arange(0,Nlenb):
    Arr1=Lenb[ilen,:,:].\
        rename('P<'+str(lenb[ilen])+'-'+str(lene[ilen])).\
        drop_vars(names='time')
    if (ilen==0):
      dsPersDiff=Arr1*1.
    else:
      dsPersDiff=xr.merge([dsPersDiff,Arr1])

  # Compare random to origional 
  VarDiffMCn = dsPersDiff*0.+1
  VarDiffMCn = VarDiffMCn.where(np.fabs(dsPersDiffO) > \
                               np.fabs(dsPersDiff), 0)
  
  if iMC==0:
    VarDiffMC=VarDiffMCn*1.
  else:
    VarDiffMC=VarDiffMC+VarDiffMCn

fileMC = PathE+'MC/run/PersAnomExt.Script'+str(SNB)+\
    '.MCrun'+str(RunNb)+'.'+rMeth+'.nc'
os.system('rm -vf '+fileMC)
VarDiffMC=VarDiffMC.assign(NMC=NMC)

VarDiffMC.to_netcdf(fileMC)

print(" ")
print("##################")
Ttime=TimeRun.time()-btime
print("Runing time "+str(np.floor(Ttime/60))+" min and "+str(np.floor(Ttime % 60))+" sec") 
print("##################")
print(" ")

print(".. Done Pers Anom MC: "+str(RunNb)) 

