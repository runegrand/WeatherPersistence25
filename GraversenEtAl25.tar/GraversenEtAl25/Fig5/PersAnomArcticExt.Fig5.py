# -*- coding: utf-8 -*-
# PersAnomArcticExt.Fig5.py
#
# Calculate persistence during 3-month warm and cold Arctic events
# and the composite difference 
#
# Input data produced by "WeathVar.py"
#
# Rune Grand Graversen: rune.graversen@uit.no
####################

import xarray as xr
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cftime
import sys
import numpy as np
np.round_ = np.round
import time as TimeRun
import xrft
import os

#########################
# Setting tool script dir
# directory to tools script (tools.py and tools_plot.py)
toolPath=<tools_script_dir>
#toolPath='/cluster/home/runegg/python/WeathPers25/'
#########################
try:
    sys.path.index(toolPath) 
except ValueError:
    sys.path.append(toolPath)
from tools import PersAnom, filter_run_mean_time_lat_lon, FalseDiscovLatLon
from tools_plot import Plot2, Plot4, Plot2box, Plot1BoxSig, Plot1box

btime=TimeRun.time()

########################
# Settings
MakeVar=True # True: Calculate persistence and save
              # False: use saved fields
anB=0         # Anomaly threshold

# PathW is SAT input data directory;
# PathE is directory of extreme Arctic events; 
# PathFig is output directory
PathW=<input_SAT_dir>
PathE=<input_ArcExt_dir>
PathFig=<out_put_dir>
#PathW='/cluster/projects/nn9348k/Rune/WeathPers25/work/SATvar/'
#PathE='/cluster/projects/nn9348k/Rune/WeathPers25/work/ExtrArc/'
#PathFig='/cluster/projects/nn9348k/Rune/WeathPers25/Fig/'
#######################

Evar = "Z" # "SAT", "T" or "Z"

LatEnd=20
LatStep=10
LatLoop = np.arange(90,LatEnd,-LatStep)

lat=xr.open_dataset(PathW+'/SATrm.1979.nc').lat
dlat=np.abs(lat[0].data-lat[1].data)

Nlen=90
lenb=[1,3,1,5,1,11]
lene=[2,Nlen,4,Nlen,10,Nlen]

Nlenb=np.size(lenb)
dates=xr.open_dataset(PathE+'ArcticExtremes.nc')

datp=dates["Zp"]
datn=dates["Zn"]
Ndate=datp.size

fileVar=PathE+'FigData/SATPersAnomExt.'+Evar+'.nc'
fileVarp=PathE+'FigData/SATPersAnomExt.'+Evar+'.p.nc'
fileVarn=PathE+'FigData/SATPersAnomExt.'+Evar+'.n.nc'
fileVarA=PathE+'FigData/SATPersAnomExt.'+Evar+'.All.nc'

if MakeVar:
  first=True
  for Lati in LatLoop:
    print("Calculating for latitude: "+str(Lati))
    latb=Lati
    late=Lati-LatStep+dlat
    if ((late-dlat)==LatEnd):
      late=LatEnd

    pathSAT=PathW+'SATan'+'_Lat'+str(late)+'to'+str(latb)+'.nc'

    SATan=xr.open_dataset(pathSAT)['urm'].compute()
    time=SATan.time
    
    firstp=0
    firstn=0
    # Calculating composites over warm and cold Arctic events 
    for idate in np.arange(0,Ndate):
      dp=datp[idate]
      dn=datn[idate]
      if not (np.isnat(dp)):
        if (dp.dt.year > 1979) & (dp.dt.year < 2023):
          iExt=np.where(time==dp)[0][0]
          SATanYx=SATan[iExt:iExt+Nlen,:,:]
          SATanY=SATanYx-SATanYx.mean(dim="time")
          dsLenLp = PersAnom(SATanY,Nlen,anB)
          dsLenLn = PersAnom(-1.*SATanY,Nlen,anB)
          if (firstp == 0):
            dsLenL=dsLenLp+dsLenLn
            dsLenLpp=dsLenLp*1. 
            dsLenLnn=dsLenLn*1. 
          else:
            dsLenL=dsLenL+(dsLenLp+dsLenLn)
            dsLenLpp=dsLenLpp+dsLenLp  
            dsLenLnn=dsLenLnn+dsLenLn  
          firstp=firstp+1
      if not (np.isnat(dn)):
        if (dn.dt.year > 1979) & (dn.dt.year < 2023):
          iExt=np.where(time==dn)[0][0]
          SATanYx=SATan[iExt:iExt+Nlen,:,:]
          SATanY=SATanYx-SATanYx.mean(dim="time")
          dsLenEp = PersAnom(SATanY,Nlen,anB)
          dsLenEn = PersAnom(-1.*SATanY,Nlen,anB)
          if (firstn == 0):
            dsLenE=dsLenEp+dsLenEn
            dsLenEpp=dsLenEp*1.
            dsLenEnn=dsLenEn*1.
          else:
            dsLenE=dsLenE+(dsLenEp+dsLenEn)
            dsLenEpp=dsLenEpp+dsLenEp
            dsLenEnn=dsLenEnn+dsLenEn
          firstn=firstn+1

    # Calculate composite difference       
    dsLenL=dsLenL/firstp
    dsLenE=dsLenE/firstn
    PersDiffL = dsLenL-dsLenE

    dsLenLpp=dsLenLpp/firstp
    dsLenEpp=dsLenEpp/firstn
    PersDiffLp = dsLenLpp-dsLenEpp
    dsLenLnn=dsLenLnn/firstp
    dsLenEnn=dsLenEnn/firstn
    PersDiffLn = dsLenLnn-dsLenEnn

    del SATan

    if (first):
      PersDiff=PersDiffL*1.
      PersDiffp=PersDiffLp*1.
      PersDiffn=PersDiffLn*1.
    else:
      PersDiff=xr.concat([PersDiff,PersDiffL],dim="lat")    
      PersDiffp=xr.concat([PersDiffp,PersDiffLp],dim="lat")    
      PersDiffn=xr.concat([PersDiffn,PersDiffLn],dim="lat")    

    first=False

  lat=PersDiff.lat  
  lon=PersDiff.lon
  Nlat=np.size(lat)
  Nlon=np.size(lon)
  Lend = xr.DataArray(np.zeros([Nlen,Nlat,Nlon]), \
    coords=[np.arange(1,Nlen+1),lat,lon], dims=["len","lat","lon"])
  Lenb = xr.DataArray(np.zeros([Nlenb,Nlat,Nlon]), \
    coords=[np.arange(1,Nlenb+1),lat,lon], dims=["time","lat","lon"])
  Lendp = xr.DataArray(np.zeros([Nlen,Nlat,Nlon]), \
    coords=[np.arange(1,Nlen+1),lat,lon], dims=["len","lat","lon"])
  Lenbp = xr.DataArray(np.zeros([Nlenb,Nlat,Nlon]), \
    coords=[np.arange(1,Nlenb+1),lat,lon], dims=["time","lat","lon"])
  Lendn = xr.DataArray(np.zeros([Nlen,Nlat,Nlon]), \
    coords=[np.arange(1,Nlen+1),lat,lon], dims=["len","lat","lon"])
  Lenbn = xr.DataArray(np.zeros([Nlenb,Nlat,Nlon]), \
    coords=[np.arange(1,Nlenb+1),lat,lon], dims=["time","lat","lon"])

  # Assign numbers of days in each day bin (length of anomaly)
  for ilen in np.arange(0,Nlen):
    Lend[ilen,:,:] = PersDiff[ilen,:,:]*(ilen+1)  
    Lendp[ilen,:,:] = PersDiffp[ilen,:,:]*(ilen+1)  
    Lendn[ilen,:,:] = PersDiffn[ilen,:,:]*(ilen+1)  

  # Rebin into periods 
  for ilen in np.arange(0,Nlenb):
    Lenb[ilen,:,:] = Lend[lenb[ilen]-1:lene[ilen],:,:].\
        sum(dim="len")*1.
    Lenbp[ilen,:,:] = Lendp[lenb[ilen]-1:lene[ilen],:,:].\
        sum(dim="len")*1.
    Lenbn[ilen,:,:] = Lendn[lenb[ilen]-1:lene[ilen],:,:].\
        sum(dim="len")*1.
  # Smooth fields over 2 degree latitude and equal distance in longitude 
  Lenb=filter_run_mean_time_lat_lon(Lenb,2)
  Lenbp=filter_run_mean_time_lat_lon(Lenbp,2)
  Lenbn=filter_run_mean_time_lat_lon(Lenbn,2)

  for ilen in np.arange(0,Nlenb):
    Arr1=Lenb[ilen,:,:].\
        rename('P<'+str(lenb[ilen])+'-'+str(lene[ilen])).\
        drop_vars(names='time')
    Arr1p=Lenbp[ilen,:,:].\
        rename('P<'+str(lenb[ilen])+'-'+str(lene[ilen])).\
        drop_vars(names='time')
    Arr1n=Lenbn[ilen,:,:].\
        rename('P<'+str(lenb[ilen])+'-'+str(lene[ilen])).\
        drop_vars(names='time')
    if (ilen==0):
      dsPersDiff=Arr1*1.
      dsPersDiffp=Arr1p*1.
      dsPersDiffn=Arr1n*1.
    else:
      dsPersDiff=xr.merge([dsPersDiff,Arr1])
      dsPersDiffp=xr.merge([dsPersDiffp,Arr1p])
      dsPersDiffn=xr.merge([dsPersDiffn,Arr1n])

  os.system("rm -vf "+fileVar)
  dsPersDiff.to_netcdf(fileVar)
  os.system("rm -vf "+fileVarp)
  dsPersDiffp.to_netcdf(fileVarp)
  os.system("rm -vf "+fileVarn)
  dsPersDiffn.to_netcdf(fileVarn)

  os.system("rm -vf "+fileVarA)
  Lend.rename('Anom').to_netcdf(fileVarA)
else:
  dsPersDiff=xr.open_dataset(fileVar)
  dsPersDiffp=xr.open_dataset(fileVarp)
  dsPersDiffn=xr.open_dataset(fileVarn)
  Lend=xr.open_dataset(fileVarA)['Anom']

dsPlot=dsPersDiff*1.

Latb=45
Late=75
Lonb=-120 
Lone=60 

###########################
#Open MC
PathMC=PathE+'/MC/'
rMeth='FFT'  # 'BS', or 'FFT'
dsPersDiffMC=xr.open_dataset(PathMC+'PersAnomExt.'+rMeth+'.nc')
dsPersDiffMCsc = dsPersDiffMC/dsPersDiffMC.NMC

uFD2=FalseDiscovLatLon(dsPersDiffMCsc['P<3-'+str(Nlen)])

lat=dsPersDiff.lat
latb=30


FigTitle='Persistence difference (warm minus cold Arctic events)'
uTitle='Difference in # of days in anomalies lasting at least 3 days'
CBTitle='Days'

###
#Remove NEG, SEP 2025
#Include Box, NOV 2025
FigFormx='pdf'
Fignm='Fig5.'+FigFormx
Plot1BoxSig(dsPersDiff['P<3-'+str(Nlen)].sel(lat=(lat > latb)),
        8,2,40,
        uTitle,CBTitle,FigTitle,
        Latb,Late,Lonb,Lone,
        uFD2.sel(lat=(lat > latb)),
        0.99,
            PathFig,Fignm,FigFormx)
#        None,None,None)

# Write out Fig 1 data for Figshare, Nov 2025
dsF1=dsPersDiff['P<3-'+str(Nlen)].sel(lat=(lat > latb)).rename('PersDiff')
dsF2=uFD2.sel(lat=(lat > latb)).rename('Confidence')
dsFig5=xr.merge([dsF1,dsF2])
dsFig5.attrs["Units"]='PersTrends: days yr-1; Confidence: %'
dsFig5.attrs["Description"]='PersDiff: Difference in days within temperature anomalies lasting at least 3 days between 3-months warm and cold Arctic events; Confidence: confidence level' 
FilenmFigData=PathFig+'Fig5data.nc'
os.system("rm -vf "+FilenmFigData)
dsFig5.to_netcdf(FilenmFigData)

print(" ")
print("##################")
Ttime=TimeRun.time()-btime
print("Running time "+str(np.floor(Ttime/60))+" min and "+str(np.floor(Ttime % 60))+" sec") 
print("##################")
print(" ")

