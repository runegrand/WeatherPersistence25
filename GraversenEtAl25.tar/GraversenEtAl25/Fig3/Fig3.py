# -*- coding: utf-8 -*-
# Fig3.py
#
# Calculate spatial correlation between
# the zonal mass flux (uM) and temperature persistence,
# both for trends and composites of Arctic warm minus cold events.
#
# Input data produced by:
#         PersAnom.Fig1.FigS1.py
#         PersAnomArcticExt.Fig5.py
#         Trend.Fig2.FigS3.py
#         ArcricExt.Fig4.py
#
# Rune Grand Graversen: rune.graversen@uit.no
##################################

import xarray as xr
import pandas as pd
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cftime
import sys
import numpy as np
np.round_ = np.round
import time as TimeRun
import xrft
import os
import matplotlib.gridspec as gridspec
from matplotlib.colors import ListedColormap, LinearSegmentedColormap
from scipy import stats
from scipy.stats import linregress
from scipy.special import roots_legendre
from scipy.interpolate import griddata

#########################
# Setting tool script dir
# directory to tools script (tools.py and tools_plot.py)
toolPath=<tools_script_dir>
#toolPath='/cluster/home/runegg/python/WeathPers25/'
#########################
try:
    sys.path.index(toolPath)
except ValueError:
    sys.path.append(toolPath)
from tools import PersAnom, filter_run_mean_lat_lon, \
    filter_run_mean_time_lat_lon, FalseDiscovLatLon
from tools_plot import Plot2, Plot4, Plot2box

btime=TimeRun.time()

########################
# Settings
# PathW is temperature persistence input data directory;
# PathE is uM imput data directory; 
# PathFig is output directory
PathW=<input_SAT_dir>
PathE=<input_ArcExt_dir>
PathFig=<out_put_dir>
#PathW='/cluster/projects/nn9348k/Rune/WeathPers25/work/SATvar/'
#PathE='/cluster/projects/nn9348k/Rune/WeathPers25/work/ExtrArc/'
#PathFig='/cluster/projects/nn9348k/Rune/WeathPers25/Fig/'
#######################

YEARE   = 1980
YEARL   = 2008
NyearsE = 15
NyearsL = 15

fileVar1=PathW+'FigData/SATPersAnom'+str(YEARL)+'-'+str(YEARL+NyearsL-1)+\
    'minus'+str(YEARE)+'-'+str(YEARE+NyearsE-1)+'.nc'
fileVar2=PathE+'FigData/uMTrend.nc'
dsPersDiff=xr.open_dataset(fileVar1)
dsPDiff=xr.open_dataset(fileVar2)

fileVar1E=PathE+'FigData/uMExt.Z.nc'
fileVar2E=PathE+'FigData/SATPersAnomExt.Z.nc'
dsPersDiffE=xr.open_dataset(fileVar2E)
dsPDiffE=xr.open_dataset(fileVar1E)

lat=dsPersDiff.lat
latb=30
late=60
latint=5

latd=late-latb
latm=(np.abs(latb+late)/2.)
Nlon=round(360/latint*np.cos(latm*np.pi/180))
Nlat=round(latd/latint+1)

Varnm='P<3-365'
y2=dsPersDiff[Varnm]/15
x2=dsPDiff['Trend']/1.E4

VarnmE='P<3-90'
y2E=dsPersDiffE[VarnmE]
x2E=dsPDiffE['Ext']/1.E4

latl = np.linspace(late, latb, Nlat)
lonl = np.linspace(-180, 180, Nlon,endpoint=False)
yl=y2.interp(lat=latl, lon=lonl, method='linear')
xl=x2.interp(lat=latl, lon=lonl, method='linear')
yNaN=yl.values.flatten()
xNaN=xl.values.flatten()

ylE=y2E.interp(lat=latl, lon=lonl, method='linear')
xlE=x2E.interp(lat=latl, lon=lonl, method='linear')
yENaN=ylE.values.flatten()
xENaN=xlE.values.flatten()

x=xNaN[~np.isnan(yNaN)]
y=yNaN[~np.isnan(yNaN)]
res = linregress(x, y)
yfit = res.slope * x + res.intercept

xE=xENaN[~np.isnan(yENaN)]
yE=yENaN[~np.isnan(yENaN)]
resE = linregress(xE, yE)
yfitE = resE.slope * xE + resE.intercept

xTitle='Zonal mass transport [10$^4$ kg s$^{-1}$ m$^{-1}$]'
yTitle='Persistence [days yr$^{-1}$]'
scTitle='(2008-2022) minus (1980-1994)'
yTitleE='Persistence [days]'
scTitleE='Warm minus cold events'

textstr = f' r: {res.rvalue:.2f}\n p: {res.pvalue:.2f}\n N: {y.size:d}'
textstrE = f' r: {resE.rvalue:.2f}\n p: {resE.pvalue:.2f}\n N: {yE.size:d}'

fig = plt.figure(figsize=(15,7))
gs = gridspec.GridSpec(2,4,width_ratios=[0.2,1,0.2,1],height_ratios=[0.2,1],
                         wspace=0.0, hspace=0.0)

FigTitle='Spatial correlation over 30$^\circ$- 60$^\circ$ N of persistence and uM differences'
axT = fig.add_subplot(gs[0,:])
axT.axis('off')
axT.text(0.5,0.5,FigTitle,weight='bold',fontsize=20,ha='center')

axs = {}
plots = {}
axs[0]=fig.add_subplot(gs[1,1])
plots[0]=plt.scatter(x,y,c='black',s=4.)
plots[0]=plt.plot(x,yfit,color='red')
axs[0]=plt.gca()
axs[0].set_xlabel(xTitle,fontsize=15)
axs[0].set_ylabel(yTitle,fontsize=15)
axs[0].set_title(scTitle,fontsize=17)
axs[0].set_title('(a)',loc='left',weight='bold',fontsize=17)
axs[0].tick_params(axis='y', labelsize=15)
axs[0].tick_params(axis='x', labelsize=15)
axs[0]=plt.text(0.78, 0.95, textstr, transform=plt.gca().transAxes,
         fontsize=15, verticalalignment='top',
         bbox=dict(facecolor='white', alpha=0.5, boxstyle='round,pad=0.5'))
axs[1]=fig.add_subplot(gs[1,3])
plots[1]=plt.scatter(xE,yE,c='black',s=4.)
plots[1]=plt.plot(xE,yfitE,color='red')
axs[1]=plt.gca()
axs[1].set_xlabel(xTitle,fontsize=15)
axs[1].set_ylabel(yTitleE,fontsize=15)
axs[1].set_title(scTitleE,fontsize=17)
axs[1].set_title('(b)',loc='left',weight='bold',fontsize=17)
axs[1].tick_params(axis='y', labelsize=15)
axs[1].tick_params(axis='x', labelsize=15)
axs[1]=plt.text(0.78, 0.95, textstrE, transform=plt.gca().transAxes,
         fontsize=15, verticalalignment='top',
         bbox=dict(facecolor='white', alpha=0.5, boxstyle='round,pad=0.5'))

FigForm='eps'
#Fignm='Fig_3.'+FigForm
Fignm='Fig3.'+FigForm
plt.savefig(PathFig+Fignm,bbox_inches='tight',
              pad_inches=0.02,format=FigForm)
plt.show()

# Write out Fig 3 data for Figshare, Nov 2025
dsF1=xr.DataArray(y,coords={'uMTrend': x}, dims=["uMTrend"]).rename('PersTrend')
dsF2=xr.DataArray(yE,coords={'uMDiff': xE}, dims=["uMDiff"]).rename('PersDiff')
dsF1L=xr.DataArray(yfit,coords={'uMTrend': x}, dims=["uMTrend"]).rename('PersTrendLinear')
dsF2L=xr.DataArray(yfitE,coords={'uMDiff': xE}, dims=["uMDiff"]).rename('PersDiffLinear')
dsFig3=xr.merge([dsF1,dsF1L,dsF2,dsF2L])
dsFig3.attrs["Units"]='PersTrend(Linear): days yr-1; PersDiff(Linear): days: uMTrend/Diff: 10^4 kg s-1 m-1 K'
dsFig3.attrs["Description"]='Persistence and zonal mass flux north of 30 N interpolated to a 5x7.2 lat-lon grid. PersTrend: trends in persistence as a function of uM trends (2008-2022 minus 1980-1994); PersDiff: composite difference in persistence as a function of uM composite difference (warm minus cold 3-months Arctic events); PersTrend/DiffLinear: least-square linear fit between persistence and uM trends/composite differences.'
dsFig3.attrs["CorrelationTrend"]=f'r: {res.rvalue:.2f}; p: {res.pvalue:.2f}; N: {y.size:d}'
dsFig3.attrs["CorrelationDiff"]=f'r: {resE.rvalue:.2f}; p: {resE.pvalue:.2f}; N: {yE.size:d}'
FilenmFigData=PathFig+'Fig3data.nc'
os.system("rm -vf "+FilenmFigData)
dsFig3.to_netcdf(FilenmFigData)

print(" ")
print("##################")
Ttime=TimeRun.time()-btime
print("Runing time "+str(np.floor(Ttime/60))+\
      " min and "+str(np.floor(Ttime % 60))+" sec")
print("##################")

