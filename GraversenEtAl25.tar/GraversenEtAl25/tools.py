# -*- coding: utf-8 -*-
# tools.py
# For Graversen et al., Comm Earth Env, 2025
#
# Rune Grand Graversen: rune.graversen@uit.no
###################################################

import xarray as xr
import numpy as np
import pyresample
import math
import sys
import xrft
import numpy.random as rd
from scipy import stats
import pandas as pd

def filter_run_mean_lat_lon(u,Nlatrm):
  ### IMPLEMTED 25 March 2025:
  ###       Circular boundary conditions in lon
  #Running-mean smoothing, first lat then lon.
  #u(lat,lon): array to be smoothed
  #NlatrmL Number of latitudes to smooth 

  #print("Do filter_run_mean_lat_lon")

  PI=3.1415
  dtor = 2*PI/360.

  lat=u["lat"]
  lon=u["lon"]
  Nlat=u["lat"].shape[0]
  Nlon=u["lon"].shape[0]
  coslat = np.cos(lat*dtor)

  lond=lon[1]-lon[0]
  lonx=np.arange(lon[0]-360,lon[Nlon-1]+360+lond,lond)
  Nlonx=lonx.shape[0]
  us = xr.DataArray(
    data=np.zeros((Nlat,Nlonx)),
    dims=["lat", "lon"],
    coords=dict(
        lon=lonx,
        lat=lat
    )
  )

  NstepLat=np.rint(Nlatrm/abs(lat[1]-lat[0])).to_numpy().astype(int)
  if (NstepLat % 2) == 0: NstepLat = NstepLat-1
  NstepLath=np.rint((NstepLat-1)/2).astype(int)
  
  coslatLL = np.cos(lat*dtor).expand_dims({"lon": lon},axis=1)
  coslatLL = coslatLL.rename("coslat").astype(np.float32)
  
  ucos     = u*coslatLL
  ucos     = ucos.rename("ucos")

  urm   = ucos.rolling(lat=NstepLat,center=True).mean()

  us[:,0:Nlon] = urm.data
  us[:,Nlon:2*Nlon] = urm.data
  us[:,2*Nlon:3*Nlon] = urm.data

  urm = urm.rename("urm")

  for ilat in range(NstepLath,Nlat-NstepLath,1):
    NstepLon = (NstepLat/coslat[ilat]).to_numpy().astype(int)
    if (NstepLon % 2) == 0: NstepLon = NstepLon+1

    us[ilat,:] =  us[ilat,:].rolling(lon=NstepLon,center=True).mean()

    urm[ilat,:] = us[ilat,Nlon:2*Nlon] /coslatLL[ilat,:]
    
  return urm

def filter_run_mean_time_lat_lon(u,Nlatrm):
  ### IMPLEMTED 6 September 2024:
  ###       Circular boundary conditions in lon
  #Running-mean smoothing, first lat then lon.
  #u(time,lat,lon): array to be smoothed
  #NlatrmL Number of latitudes to smooth 

  #print("Do filter_run_mean_lat_lon")

  PI=3.1415
  dtor = 2*PI/360.

  lat=u["lat"]
  lon=u["lon"]
  time=u["time"]
  Nlat=u["lat"].shape[0]
  Nlon=u["lon"].shape[0]
  Ntime=u["time"].shape[0]
  coslat = np.cos(lat*dtor)

  lond=lon[1]-lon[0]
  lonx=np.arange(lon[0]-360,lon[Nlon-1]+360+lond,lond)
  Nlonx=lonx.shape[0]
  us = xr.DataArray(
    data=np.zeros((Ntime,Nlat,Nlonx)),
    dims=["time", "lat", "lon"],
    coords=dict(
        lon=lonx,
        lat=lat,
        time=time
    )
  )

  NstepLat=np.rint(Nlatrm/abs(lat[1]-lat[0])).to_numpy().astype(int)
  if (NstepLat % 2) == 0: NstepLat = NstepLat+1
  NstepLath=np.rint((NstepLat-1)/2).astype(int)
  
  coslatLL = np.cos(lat*dtor).expand_dims({ "time": time, "lon": lon}, \
                                          axis=[0,2])
  coslatLL = coslatLL.rename("coslat").astype(np.float32)
  
  ucos     = u*coslatLL
  ucos     = ucos.rename("ucos")

  urm  = ucos.rolling(lat=NstepLat,center=True).mean()

  us[:,:,0:Nlon] = urm.data
  us[:,:,Nlon:2*Nlon] = urm.data
  us[:,:,2*Nlon:3*Nlon] = urm.data

  urm = urm.rename("urm")

  for ilat in range(NstepLath,Nlat-NstepLath,1):
#    if (ilat % 5) == 0: print(str(ilat)+' '+str(lat[ilat].data))
    NstepLon = (NstepLat/coslat[ilat]).to_numpy().astype(int)
    if (NstepLon % 2) == 0: NstepLon = NstepLon+1

    us[:,ilat,:] =  us[:,ilat,:].rolling(lon=NstepLon,center=True).mean() 

    urm[:,ilat,:] = us[:,ilat,Nlon:2*Nlon] /coslatLL[:,ilat,:]

  return urm

#####################
def Change_yr(u,styr,enyr):
  ### IMPLEMTED 3 Apri 2025:
  # Randomly change years in date array
  # for changeing years in ArcticExtremes.py 
  # u(time,lat,lon): Date array where years should be changed
  # Random years within [styr;enyr]
  ###

  Ndate=u.size
  uc = np.full(Ndate, np.datetime64("NaT"), dtype="datetime64[D]")

  ran_yr=np.random.randint(styr, enyr, Ndate)
  for idate in np.arange(0,Ndate):
    du=u[idate]
    if not (np.isnat(du)):
      uc[idate]=pd.Timestamp(str(du.data)).replace(year=(ran_yr[idate]))

  return uc
#######################      
  
def fft_filter(u,dayF,dayS):
  ### IMPLEMTED 8 October 2024:
  ### Retain variability in interval [dayF,dayS]
  # u(time,lat,lon): array to be filtered
  #     time resolution must be day
  # dayF: fastest limit of filtering in days
  # dayS: slowest limit of fultering in days

  FreqF = 1./dayF # 1/#days fastest limit
  FreqS = 1./dayS # 1/#days slowest limit

  time=u["time"]
  Nt=time.size
#  NtE=timeE.size-2*365
  Nlat=u["lat"].size
  Nlon=u["lon"].size

#  dsFFT = dsSATan['urm'][365:NtxE-365,:,:] #.chunk(chunks=(Nt,Nlat,Nlon))
  u["time"]=np.arange(0,Nt)
  u_fft = xrft.fft(u, \
           dim="time", true_phase=True, true_amplitude=True)

  fft_time=u_fft.freq_time
  fft_i=np.where(np.logical_or(abs(fft_time)>FreqF,abs(fft_time)<FreqS))[0]
  u_fft[fft_i,:,:]=0+0j
  u_filt = xrft.ifft(u_fft,lag=0, \
        dim="freq_time", true_phase=True, true_amplitude=True).real
  u_filt["time"] = time
  return u_filt

def xfft_TLL(b1):
  # Make random field of b1 but retain power spectrum in time
  time=b1["time"]
  Nt=time.size
  Nlat=b1["lat"].size
  Nlon=b1["lon"].size
  b1["time"]=np.arange(0,time.size)

  da_fft = xrft.fft(b1, \
           dim="time", true_phase=True, true_amplitude=True)
  
  arr1=np.ones((1,Nlat,Nlon))
  if (Nt % 2 == 0):
    theta=2*np.pi*rd.rand(np.int_(Nt/2-1),Nlat,Nlon)
    factor=np.cos(theta)+np.sin(theta)*1j
    factor2=np.append(arr1,np.append(factor, \
       np.append(arr1,np.flip(np.conjugate(factor), \
       axis=0),axis=0),axis=0),axis=0)
  else:
    theta=2*np.pi*rd.rand(np.int_((Nt-1)/2),Nlat,Nlon)
    factor=np.cos(theta)+np.sin(theta)*1j
    factor2=np.append(factor, \
        np.append(arr1,np.flip(np.conjugate(factor),axis=0),axis=0),axis=0)

  dsr = xrft.ifft(da_fft*factor2, lag=0, \
           dim="freq_time", true_phase=True, true_amplitude=True).real
  dsr["time"]=time
  b1["time"]=time
  return dsr

def xfft_T(b1):
  # Make random field of b1 but retain power spectrum in time
  time=b1["time"]
  Nt=time.size
  b1["time"]=np.arange(0,time.size)

  da_fft = xrft.fft(b1, \
           dim="time", true_phase=True, true_amplitude=True)
  
#  arr1=np.ones((1,Nlat,Nlon))
  if (Nt % 2 == 0):
    theta=2*np.pi*rd.rand(np.int_(Nt/2-1))
    factor=np.cos(theta)+np.sin(theta)*1j
#    factor2=np.append(arr1,np.append(factor, \
#       np.append(arr1,np.flip(np.conjugate(factor), \
#       axis=0),axis=0),axis=0),axis=0)
    factor2=np.append(1,np.append(factor, \
       np.append(1,np.flip(np.conjugate(factor)))))
  else:
    theta=2*np.pi*rd.rand(np.int_((Nt-1)/2))
    factor=np.cos(theta)+np.sin(theta)*1j
#    factor2=np.append(factor, \
#        np.append(arr1,np.flip(np.conjugate(factor),axis=0),axis=0),axis=0)
    factor2=np.append(factor, \
        np.append(1,np.flip(np.conjugate(factor))))

  dsr = xrft.ifft(da_fft*factor2, lag=0, \
           dim="freq_time", true_phase=True, true_amplitude=True).real
  dsr["time"]=time
  b1["time"]=time
  return dsr

def IntData_TLL(b1):
  # Interchange time data randomly
  timeO=b1.time
  Ntime=timeO.size
  time=np.arange(0,Ntime)

  b1r=b1*1.
  b1r['time']=time
  np.random.shuffle(time)
  b1r=b1r.isel(time=time) 
  b1r['time']=timeO
  return b1r
  
def corr_auto(u,lag):
  # Make autocorerelation "lag" days
  # u[time,lat,lon]
  lat=u.lat
  Nlat=np.size(lat)
  lon=u.lon
  Nlon=np.size(lon)
  Nlag=np.size(lag)
  u_corr = xr.DataArray(np.zeros([Nlag,Nlat,Nlon]), \
                coords=[lag,lat,lon], dims=["lag","lat","lon"])
  for ilag in lag:
    us = u.shift(time=-ilag)
    u_corr.loc[ilag] = xr.corr(u,us,dim='time')
  return u_corr

def corr_auto_LL(u,lagi):
  # Make autocorerelation with "lagi" days
  # u[time,lat,lon]
  lat=u.lat
  Nlat=np.size(lat)
  lon=u.lon
  Nlon=np.size(lon)
  us = u.shift(time=-lagi)
  u_corr = xr.corr(u,us,dim='time')
  return u_corr

def PersAnom(u,Len,anB):
  # Make statisics of positive anomaly duration
  # Calculate number of anomalies with a given length up to "Len"
  # u[time,lat,lon]
  # Len: maximum annomaly length
  # anB: annomalies are defined above this value
  # return: [len,lat,lon]
  lat=u.lat
  Nlat=np.size(lat)
  lon=u.lon
  Nlon=np.size(lon)
  
  u1=u.where(u>anB,float("NaN")).notnull()
  u2=u1.cumsum(dim="time")
  u3=u2.where(np.invert(u1)).ffill(dim="time").fillna(0)
  u4=(u2-u3).astype(int)
  
  len=np.arange(1,Len+1)
  Nlen=np.size(len)
  dsLen = xr.DataArray(np.zeros([Nlen,Nlat,Nlon]), \
                    coords=[len,lat,lon], dims=["len","lat","lon"])
  for ilen in len:
    dsLen[ilen-1,:,:]=u4.where(u4==ilen).count(dim="time")
    if (not dsLen[ilen-1,:,:].max() > 0):
      break

  return dsLen-dsLen.shift(len=-1).fillna(0)

def FalseDiscovLatLon(u):
  # The false discovery rate control procedure
  # based on the  Benjaminini-Yekutieli method
  #
  # u:   Input Lat-lon field with significance in
  #      each gri point
  # uFD: outputm changed significance due to the
  #      false discovery test.
  b1=u.stack(latlon=('lat', 'lon'))
  b0=b1*0.
  b2=b0+stats.false_discovery_control(1.-b1,method='by')
  uFD=(1.-b2).unstack('latlon')
  return uFD

  
