# -*- coding: utf-8 -*-
# tools_plot.py
# For Graversen et al., Comm Earth Env, 2025
#
# Rune Grand Graversen: rune.graversen@uit.no
###################################################

import xarray as xr
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from matplotlib.ticker import MultipleLocator
import numpy as np
import pyresample
import math
import sys
import xrft
import numpy.random as rd
import os
import matplotlib.gridspec as gridspec
from matplotlib.colors import ListedColormap, LinearSegmentedColormap

def Plot1Ext(u,Vmm,CBint,Ncol,uTitle,CBTitle,FigTitle,uMC,SigLev,
          PathFig,Fignm,FigForm):
  # u(lat,lon)
  # Vmm: plot range [-Vmm;Vmm]
  # CBint: Colour table interval between ticks
  # Ncol: Number of coloor-shading levels
  # uTitle
  # CBTitle: Colour-table title
  # uMC: Significance of u (if None: not plotted)
  # SigLev: array with 2 Levels of significance, a number in [0,1]
  # PathFig: Path to figure output
  # Fignm: Filename of figure output
  # FigForm: Formate of figure file (if None: no figure output in file)
  useMC=[True]
  dsW=u.rename('w1')
  if uMC is not None:
    dsW=xr.merge([dsW,uMC.rename('w1MC')])
  else:
    useMC[0]=False

#  cmap = plt.cm.get_cmap("bwr",Ncol)
  cmap = plt.cm.get_cmap("RdBu_r",Ncol)
  cmapi=cmap(np.linspace(0, 1, Ncol))
  cmapi[int(Ncol/2-1),:]=np.array([1,1,1,1])
  cmapw = ListedColormap(cmapi)
  cmapiu=cmap(np.linspace(0, 1, Ncol))
  cmapiu[int(Ncol/2),:]=np.array([1,1,1,1])
  cmapwu = ListedColormap(cmapiu)
  levels=np.linspace(-Vmm, Vmm, Ncol)
  CBlevels=np.arange(-Vmm+CBint, Vmm, CBint)

  kwMC = {'levels':SigLev, 'colors':['g'], 'linestyles':['solid','dotted'],
        'linewidths':[1.,1.]}
#  if SigLev is not None:
#    kwMCf = {'levels':[0,SigLev,1.01], 'hatches':["","..."],'colors':['none']}
    
  proj=ccrs.PlateCarree()

#  fig = plt.figure(figsize=(14,3.5)) 
#  gs = gridspec.GridSpec(3,1,width_ratios=[1],height_ratios=[0.15,1,0.06],
#                         wspace=0.0, hspace=0.0)
  fig = plt.figure(figsize=(15,3.7))
  gs = gridspec.GridSpec(3,1,width_ratios=[1],height_ratios=[1,0.01,0.07],
                         wspace=0.0, hspace=0.0)

#  axT = fig.add_subplot(gs[0,0])
#  axT.axis('off')
#  axT.text(0.5,0.5,FigTitle,weight='bold',fontsize=18,ha='center')

  axs = {}
  plots = {}
  plotsCB = {}
  for i in np.arange(0,1):
#    axnm='ax'+str(i+1)
    axnm='ax'+str(i)
    varnm='w'+str(i+1)
    varMCnm='w'+str(i+1)+'MC'
    axs[axnm] = fig.add_subplot(gs[i+1-1,0],projection=proj) 
    
    plots[axnm] = dsW[varnm].plot.contourf(ax=axs[axnm],
          transform=ccrs.PlateCarree(),robust=False, add_colorbar=False,
          colors=cmapwu,center=0.0,levels=levels)
    plotsCB[axnm]=plots[axnm]
    if useMC[i]:
      plots[axnm] = dsW[varMCnm].plot.contour(ax=axs[axnm],
            transform=ccrs.PlateCarree(),robust=False, add_colorbar=False, 
                                                    **kwMC)
#      plots[axnm] = dsW[varMCnm].plot.contourf(ax=axs[axnm],
#            transform=ccrs.PlateCarree(),robust=False,add_colorbar=False, 
#                                **kwMCf)
#      for ii, collection in enumerate(plots[axnm].collections):
#        collection.set_facecolor('none')  
#        collection.set_edgecolor('0.6')
#        collection.set_linewidth(0.0)
    axs[axnm].coastlines()
    axs[axnm].set_title(uTitle,fontsize=16)
    gl = axs[axnm].gridlines(draw_labels=True, crs=proj)
    gl.xlines=False
    gl.ylines=False
    gl.top_labels = False
    gl.ylocator = MultipleLocator(20)
    gl.xlabel_style = {'size': 14, 'color': 'black'}
    gl.ylabel_style = {'size': 14, 'color': 'black'}


  cbSMB = fig.add_subplot(gs[2,0])
  colourb= plt.colorbar(plotsCB[axnm],
          cbSMB,
          ticks=CBlevels,orientation="horizontal",
          extend='neither')
  colourb.set_label(CBTitle,fontsize=14)
  colourb.ax.tick_params(labelsize=14)
  if FigForm is not None:
    plt.savefig(PathFig+Fignm,bbox_inches='tight',
              pad_inches=0.02,format=FigForm)

##################################
def Plot1BoxSig(u,Vmm,CBint,Ncol,uTitle,CBTitle,FigTitle,
          Latb,Late,Lonb,Lone,
          uMC,SigLev,
          PathFig,Fignm,FigForm):
  # Two plots with the same scaling
  # u(lat,lon)
  # Vmm: plot range [-Vmm;Vmm]
  # CBint: Colour table interval between ticks
  # Ncol: Number of coloor-shading levels
  # uTitle
  # CBTitle: Colour-table title
  # uMC: Significance of u (if None: not plotted)
  # SigLev: Levels of significance, a number in [0,1]
  # PathFig: Path to figure output
  # Fignm: Filename of figure output
  # FigForm: Formate of figure file (if None: no figure output in file)

  useMC=[True]
  dsW=u.rename('w1').to_dataset()
  if uMC is not None:
    dsW=xr.merge([dsW,uMC.rename('w1MC')])
  else:
    useMC[0]=False
  Title=[uTitle]

  cmap = plt.cm.get_cmap("RdBu_r",Ncol)
  cmapi=cmap(np.linspace(0, 1, Ncol))
  cmapi[int(Ncol/2-1),:]=np.array([1,1,1,1])
  cmapw = ListedColormap(cmapi)
  cmapiu=cmap(np.linspace(0, 1, Ncol))
  cmapiu[int(Ncol/2),:]=np.array([1,1,1,1])
  cmapwu = ListedColormap(cmapiu)
  levels=[np.linspace(-Vmm, Vmm, Ncol),np.linspace(-Vmm, Vmm, Ncol)]
  CBlevels=[np.arange(-Vmm+CBint, Vmm, CBint),np.arange(-Vmm+CBint, Vmm, CBint)]

  kwMC = {'levels':[SigLev], 'colors':['g'], 'linestyles':['solid'],
        'linewidths':[1.]}
  if SigLev is not None:
    kwMCf = {'levels':[0,SigLev,1.01], 'hatches':["",".."],'colors':['none']}

  proj=ccrs.PlateCarree()

  fig = plt.figure(figsize=(14,3.7))
  gs = gridspec.GridSpec(4,1,width_ratios=[1],height_ratios=[0.08,1,0.03,0.07],
                         wspace=0.0, hspace=0.0)

  axT = fig.add_subplot(gs[0,0])
  axT.axis('off')
  axT.text(0.5,0.5,FigTitle,weight='bold',fontsize=20,ha='center')

  axs = {}
  plots = {}
  plotsCB = {}
  for i in np.arange(0,1):
    axnm='ax'+str(i+1)
    varnm='w'+str(i+1)
    varMCnm='w'+str(i+1)+'MC'
    axs[axnm] = fig.add_subplot(gs[i+1,0],projection=proj) 
    
    plots[axnm] = dsW[varnm].plot.contourf(ax=axs[axnm],
          transform=ccrs.PlateCarree(),robust=False, add_colorbar=False,
          colors=cmapwu,center=0.0,levels=levels[i])
    plotsCB[axnm]=plots[axnm]
    if useMC[i]:
      #plots[axnm] = dsW[varMCnm].plot.contour(ax=axs[axnm],
      #      transform=ccrs.PlateCarree(),robust=False, add_colorbar=False, 
      #                                              **kwMC)
      plots[axnm] = dsW[varMCnm].plot.contourf(ax=axs[axnm],
            transform=ccrs.PlateCarree(),robust=False,add_colorbar=False, 
                                **kwMCf)
      plots[axnm].set_facecolor('none')
      plots[axnm].set_edgecolor('0.6')
      plots[axnm].set_linewidth(0.0)
    axs[axnm].coastlines()
    axs[axnm].set_title(Title[i],fontsize=16)
    if (i==0):
      axs[axnm].plot([Lonb,Lonb,Lone,Lone,Lonb], [Latb,Late,Late,Latb,Latb],
         color='dimgray', linewidth=2, linestyle='dashed',
         transform=ccrs.PlateCarree(), #remove this line to get straight lines
         )
    gl = axs[axnm].gridlines(draw_labels=True, crs=proj)
    gl.xlines=False
    gl.ylines=False
    gl.top_labels = False
    gl.ylocator = MultipleLocator(20)
    gl.xlabel_style = {'size': 14, 'color': 'black'}
    gl.ylabel_style = {'size': 14, 'color': 'black'}

  cbSMB = fig.add_subplot(gs[3,0])
  colourb=plt.colorbar(plotsCB['ax1'],
          cbSMB,
          ticks=CBlevels[0],orientation="horizontal",
          extend='neither')
  colourb.set_label(CBTitle,fontsize=14)
  colourb.ax.tick_params(labelsize=14)
  if FigForm is not None:
    plt.savefig(PathFig+Fignm,bbox_inches='tight',
              pad_inches=0.02,format=FigForm)

##################################
def Plot1box(u,Vmm,CBint,Ncol,uTitle,CBTitle,FigTitle,
             Latb,Late,Lonb,Lone,
             uMC,SigLev,
             PathFig,Fignm,FigForm):
  # u(lat,lon)
  # Vmm: plot range [-Vmm;Vmm]
  # CBint: Colour table interval between ticks
  # Ncol: Number of coloor-shading levels
  # uTitle
  # CBTitle: Colour-table title
  # uMC: Significance of u (if None: not plotted)
  # SigLev: Levels of significance, a number in [0,1]
  # PathFig: Path to figure output
  # Fignm: Filename of figure output
  # FigForm: Formate of figure file (if None: no figure output in file)

  useMC=[True]
  dsW=u.rename('w1').to_dataset()
  if uMC is not None:
    dsW=xr.merge([dsW,uMC.rename('w1MC')])
  else:
    useMC[0]=False
  Title=[uTitle]

  cmap = plt.cm.get_cmap("RdBu_r",Ncol)
  cmapi=cmap(np.linspace(0, 1, Ncol))
  cmapi[int(Ncol/2-1),:]=np.array([1,1,1,1])
  cmapw = ListedColormap(cmapi)
  cmapiu=cmap(np.linspace(0, 1, Ncol))
  cmapiu[int(Ncol/2),:]=np.array([1,1,1,1])
  cmapwu = ListedColormap(cmapiu)
  levels=[np.linspace(-Vmm, Vmm, Ncol),np.linspace(-Vmm, Vmm, Ncol)]
  CBlevels=[np.arange(-Vmm+CBint, Vmm, CBint),np.arange(-Vmm+CBint, Vmm, CBint)]

  kwMC = {'levels':[SigLev], 'colors':['g'], 'linestyles':['solid'],
        'linewidths':[1.]}
  if SigLev is not None:
    kwMCf = {'levels':[0,SigLev,1.01], 'hatches':["","..."],'colors':['none']}

  proj=ccrs.PlateCarree()

  fig = plt.figure(figsize=(14,3.7))
  gs = gridspec.GridSpec(4,1,width_ratios=[1],height_ratios=[0.08,1,0.03,0.07],
                         wspace=0.0, hspace=0.0)

  axT = fig.add_subplot(gs[0,0])
  axT.axis('off')
  axT.text(0.5,0.5,FigTitle,weight='bold',fontsize=20,ha='center')

  axs = {}
  plots = {}
  plotsCB = {}
  for i in np.arange(0,1):
    axnm='ax'+str(i+1)
    varnm='w'+str(i+1)
    varMCnm='w'+str(i+1)+'MC'
    axs[axnm] = fig.add_subplot(gs[i+1,0],projection=proj) 
    
    plots[axnm] = dsW[varnm].plot.contourf(ax=axs[axnm],
          transform=ccrs.PlateCarree(),robust=False, add_colorbar=False,
          colors=cmapwu,center=0.0,levels=levels[i])
    plotsCB[axnm]=plots[axnm]
    if useMC[i]:
      plots[axnm] = dsW[varMCnm].plot.contour(ax=axs[axnm],
            transform=ccrs.PlateCarree(),robust=False, add_colorbar=False, 
                                                    **kwMC)
      plots[axnm] = dsW[varMCnm].plot.contourf(ax=axs[axnm],
            transform=ccrs.PlateCarree(),robust=False,add_colorbar=False, 
                                **kwMCf)
      for ii, collection in enumerate(plots[axnm].collections):
        collection.set_facecolor('none')  
        collection.set_edgecolor('0.6')
        collection.set_linewidth(0.0)
    axs[axnm].coastlines()
    axs[axnm].set_title(Title[i],fontsize=16)
    if (i==0):
      axs[axnm].plot([Lonb,Lonb,Lone,Lone,Lonb], [Latb,Late,Late,Latb,Latb],
         color='darkgray', linewidth=2, linestyle='dashed',
         transform=ccrs.PlateCarree(), #remove this line to get straight lines
         )
    gl = axs[axnm].gridlines(draw_labels=True, crs=proj)
    gl.xlines=False
    gl.ylines=False
    gl.top_labels = False
    gl.ylocator = MultipleLocator(20)
    gl.xlabel_style = {'size': 14, 'color': 'black'}
    gl.ylabel_style = {'size': 14, 'color': 'black'}

  cbSMB = fig.add_subplot(gs[3,0])
  colourb=plt.colorbar(plotsCB['ax1'],
          cbSMB,#label=CBTitle,
          ticks=CBlevels[0],orientation="horizontal",
          extend='neither')
  colourb.set_label(CBTitle,fontsize=14)
  colourb.ax.tick_params(labelsize=14)
  if FigForm is not None:
    plt.savefig(PathFig+Fignm,bbox_inches='tight',
              pad_inches=0.02,format=FigForm)

##################################
def Plot2(u,v,Vmm,CBint,Ncol,uTitle,vTitle,CBTitle,FigTitle,uMC,vMC,SigLev,
          PathFig,Fignm,FigForm):
  # Two plots with the same scaling
  # u(lat,lon)
  # v(lat,lon)
  # Vmm: plot range [-Vmm;Vmm]
  # CBint: Colour table interval between ticks
  # Ncol: Number of coloor-shading levels
  # uTitle
  # vTitle
  # CBTitle: Colour-table title
  # uMC: Significance of u (if None: not plotted)
  # vMC: Significance of v (if None: not plotted)
  # SigLev: Levels of significance, a number in [0,1]
  # PathFig: Path to figure output
  # Fignm: Filename of figure output
  # FigForm: Formate of figure file (if None: no figure output in file)

  useMC=[True, True]
  dsW=u.rename('w1')
  dsW=xr.merge([dsW,v.rename('w2')])
  if uMC is not None:
    dsW=xr.merge([dsW,uMC.rename('w1MC')])
  else:
    useMC[0]=False
  if vMC is not None:
    dsW=xr.merge([dsW,vMC.rename('w2MC')])
  else:
    useMC[1]=False
  Title=[uTitle,vTitle]

#  cmap = plt.cm.get_cmap("bwr",Ncol)
  cmap = plt.cm.get_cmap("RdBu_r",Ncol)
  cmapi=cmap(np.linspace(0, 1, Ncol))
  cmapi[int(Ncol/2-1),:]=np.array([1,1,1,1])
  cmapw = ListedColormap(cmapi)
  cmapiu=cmap(np.linspace(0, 1, Ncol))
  cmapiu[int(Ncol/2),:]=np.array([1,1,1,1])
  cmapwu = ListedColormap(cmapiu)
  levels=[np.linspace(-Vmm, Vmm, Ncol),np.linspace(-Vmm, Vmm, Ncol)]
  CBlevels=[np.arange(-Vmm+CBint, Vmm, CBint),np.arange(-Vmm+CBint, Vmm, CBint)]

  kwMC = {'levels':[SigLev], 'colors':['g'], 'linestyles':['solid'],
        'linewidths':[1.]}
  if SigLev is not None:
    kwMCf = {'levels':[0,SigLev,1.01], 'hatches':["","..."],'colors':['none']}

  Fi=['(a)','(b)']
  proj=ccrs.PlateCarree()

#  fig = plt.figure(figsize=(14,6.5)) 
#  gs = gridspec.GridSpec(4,1,width_ratios=[1],height_ratios=[0.15,1,1,0.06],
#                         wspace=0.0, hspace=0.0)
  fig = plt.figure(figsize=(14,6.9))
  gs = gridspec.GridSpec(5,1,width_ratios=[1],height_ratios=[0.08,1,1,0.03,0.07],
                         wspace=0.0, hspace=0.0)

  axT = fig.add_subplot(gs[0,0])
  axT.axis('off')
  axT.text(0.5,0.5,FigTitle,weight='bold',fontsize=20,ha='center')

  axs = {}
  plots = {}
  plotsCB = {}
  for i in np.arange(0,2):
    axnm='ax'+str(i+1)
    varnm='w'+str(i+1)
    varMCnm='w'+str(i+1)+'MC'
    axs[axnm] = fig.add_subplot(gs[i+1,0],projection=proj) 
    
    plots[axnm] = dsW[varnm].plot.contourf(ax=axs[axnm],
          transform=ccrs.PlateCarree(),robust=False, add_colorbar=False,
          colors=cmapwu,center=0.0,levels=levels[i])
    plotsCB[axnm]=plots[axnm]
    if useMC[i]:
      plots[axnm] = dsW[varMCnm].plot.contour(ax=axs[axnm],
            transform=ccrs.PlateCarree(),robust=False, add_colorbar=False, 
                                                    **kwMC)
      plots[axnm] = dsW[varMCnm].plot.contourf(ax=axs[axnm],
            transform=ccrs.PlateCarree(),robust=False,add_colorbar=False, 
                                **kwMCf)
      plots[axnm].set_facecolor('none')
      plots[axnm].set_edgecolor('0.6')
      plots[axnm].set_linewidth(0.0)
    axs[axnm].coastlines()
    axs[axnm].set_title(Title[i],fontsize=16)
    axs[axnm].set_title(Fi[i],loc='left',weight='bold',fontsize=16)
    gl = axs[axnm].gridlines(draw_labels=True, crs=proj)
    gl.xlines=False
    gl.ylines=False
    gl.top_labels = False
    gl.ylocator = MultipleLocator(20)
    gl.xlabel_style = {'size': 14, 'color': 'black'}
    gl.ylabel_style = {'size': 14, 'color': 'black'}

  cbSMB = fig.add_subplot(gs[4,0])
  colourb=plt.colorbar(plotsCB['ax1'],
          cbSMB,
          ticks=CBlevels[0],orientation="horizontal",
          extend='neither')
  colourb.set_label(CBTitle,fontsize=14)
  colourb.ax.tick_params(labelsize=14)
  if FigForm is not None:
    plt.savefig(PathFig+Fignm,bbox_inches='tight',
              pad_inches=0.02,format=FigForm)

##################################
def Plot2_2CTB(u,v,Vmm1,Vmm2,CBint1,CBint2,Ncol,
          uTitle,vTitle,CBTitle,FigTitle,uMC,vMC,SigLev,
          PathFig,Fignm,FigForm):
  # Two plots with the same scaling
  # u(lat,lon)
  # v(lat,lon)
  # Vmm: plot range [-Vmm;Vmm]
  # CBint: Colour table interval between ticks
  # Ncol: Number of coloor-shading levels
  # uTitle
  # vTitle
  # CBTitle: Colour-table title
  # uMC: Significance of u (if None: not plotted)
  # vMC: Significance of v (if None: not plotted)
  # SigLev: Levels of significance, a number in [0,1]
  # PathFig: Path to figure output
  # Fignm: Filename of figure output
  # FigForm: Formate of figure file (if None: no figure output in file)

  useMC=[True, True]
  dsW=u.rename('w1')
  dsW=xr.merge([dsW,v.rename('w2')])
  if uMC is not None:
    dsW=xr.merge([dsW,uMC.rename('w1MC')])
  else:
    useMC[0]=False
  if vMC is not None:
    dsW=xr.merge([dsW,vMC.rename('w2MC')])
  else:
    useMC[1]=False
  Title=[uTitle,vTitle]

#  cmap = plt.cm.get_cmap("bwr",Ncol)
  cmap = plt.cm.get_cmap("RdBu_r",Ncol)
  cmapi=cmap(np.linspace(0, 1, Ncol))
  cmapi[int(Ncol/2-1),:]=np.array([1,1,1,1])
  cmapw = ListedColormap(cmapi)
  cmapiu=cmap(np.linspace(0, 1, Ncol))
  cmapiu[int(Ncol/2),:]=np.array([1,1,1,1])
  cmapwu = ListedColormap(cmapiu)
#  levels=[np.linspace(-Vmm, Vmm, Ncol),np.linspace(-Vmm, Vmm, Ncol)]
#  CBlevels=[np.arange(-Vmm+CBint, Vmm, CBint),np.arange(-Vmm+CBint, Vmm, CBint)]
  levels=[np.linspace(-Vmm1, Vmm1, Ncol),np.linspace(-Vmm2, Vmm2, Ncol)]
  CBlevels=[np.arange(-Vmm1+CBint1, Vmm1, CBint1),np.arange(-Vmm2+CBint2, Vmm2, CBint2)]

  kwMC = {'levels':[SigLev], 'colors':['g'], 'linestyles':['solid'],
        'linewidths':[1.]}
  if SigLev is not None:
    kwMCf = {'levels':[0,SigLev,1.01], 'hatches':["",".."],'colors':['none']}

  Fi=['(a)','(b)']
  proj=ccrs.PlateCarree()

#  fig = plt.figure(figsize=(14,6.9))
#  gs = gridspec.GridSpec(5,1,width_ratios=[1],height_ratios=[0.08,1,1,0.03,0.07],
#                         wspace=0.0, hspace=0.0)
  fig = plt.figure(figsize=(14,8.1))
  gs = gridspec.GridSpec(8,1,width_ratios=[1],height_ratios=[0.08,1,0.03,0.07,0.25,1,0.03,0.07],
                         wspace=0.0, hspace=0.0)

  axT = fig.add_subplot(gs[0,0])
  axT.axis('off')
  axT.text(0.5,0.5,FigTitle,weight='bold',fontsize=20,ha='center')

  axs = {}
  plots = {}
  plotsCB = {}
  for i in np.arange(0,2):
    axnm='ax'+str(i+1)
    varnm='w'+str(i+1)
    varMCnm='w'+str(i+1)+'MC'
    if i==0: iFR=i+1
    elif i==1: iFR=i+4
    else: print("Don't know!!")
    axs[axnm] = fig.add_subplot(gs[iFR,0],projection=proj) 
    
    plots[axnm] = dsW[varnm].plot.contourf(ax=axs[axnm],
          transform=ccrs.PlateCarree(),robust=False, add_colorbar=False,
          colors=cmapwu,center=0.0,levels=levels[i])
    plotsCB[axnm]=plots[axnm]
    if useMC[i]:
      #plots[axnm] = dsW[varMCnm].plot.contour(ax=axs[axnm],
      #      transform=ccrs.PlateCarree(),robust=False, add_colorbar=False, 
      #                                              **kwMC)
      plots[axnm] = dsW[varMCnm].plot.contourf(ax=axs[axnm],
            transform=ccrs.PlateCarree(),robust=False,add_colorbar=False, 
                                **kwMCf)
      plots[axnm].set_facecolor('none')
      plots[axnm].set_edgecolor('0.6')
      plots[axnm].set_linewidth(0.0)
    axs[axnm].coastlines()
    axs[axnm].set_title(Title[i],fontsize=16)
    axs[axnm].set_title(Fi[i],loc='left',weight='bold',fontsize=16)
    gl = axs[axnm].gridlines(draw_labels=True, crs=proj)
    gl.xlines=False
    gl.ylines=False
    gl.top_labels = False
    gl.ylocator = MultipleLocator(20)
    gl.xlabel_style = {'size': 14, 'color': 'black'}
    gl.ylabel_style = {'size': 14, 'color': 'black'}

  cbSMB = fig.add_subplot(gs[3,0])
  colourb=plt.colorbar(plotsCB['ax1'],
          cbSMB,
          ticks=CBlevels[0],orientation="horizontal",
          extend='neither')
  colourb.set_label(CBTitle,fontsize=14)
  colourb.ax.tick_params(labelsize=14)
  cbSMB = fig.add_subplot(gs[7,0])
  colourb=plt.colorbar(plotsCB['ax2'],
          cbSMB,
          ticks=CBlevels[1],orientation="horizontal",
          extend='neither')
  colourb.set_label(CBTitle,fontsize=14)
  colourb.ax.tick_params(labelsize=14)
  if FigForm is not None:
    plt.savefig(PathFig+Fignm,bbox_inches='tight',
              pad_inches=0.02,format=FigForm)

##################################
def Plot2box(u,v,Vmm,CBint,Ncol,uTitle,vTitle,CBTitle,FigTitle,
             Latb,Late,Lonb,Lone,
             uMC,vMC,SigLev,
             PathFig,Fignm,FigForm):
  # Two plots with the same scaling
  # u(lat,lon)
  # v(lat,lon)
  # Vmm: plot range [-Vmm;Vmm]
  # CBint: Colour table interval between ticks
  # Ncol: Number of coloor-shading levels
  # uTitle
  # vTitle
  # CBTitle: Colour-table title
  # uMC: Significance of u (if None: not plotted)
  # vMC: Significance of v (if None: not plotted)
  # SigLev: Levels of significance, a number in [0,1]
  # PathFig: Path to figure output
  # Fignm: Filename of figure output
  # FigForm: Formate of figure file (if None: no figure output in file)

  useMC=[True, True]
  dsW=u.rename('w1')
  dsW=xr.merge([dsW,v.rename('w2')])
  if uMC is not None:
    dsW=xr.merge([dsW,uMC.rename('w1MC')])
  else:
    useMC[0]=False
  if vMC is not None:
    dsW=xr.merge([dsW,vMC.rename('w2MC')])
  else:
    useMC[1]=False
  Title=[uTitle,vTitle]

#  cmap = plt.cm.get_cmap("bwr",Ncol)
  cmap = plt.cm.get_cmap("RdBu_r",Ncol)
  cmapi=cmap(np.linspace(0, 1, Ncol))
  cmapi[int(Ncol/2-1),:]=np.array([1,1,1,1])
  cmapw = ListedColormap(cmapi)
  cmapiu=cmap(np.linspace(0, 1, Ncol))
  cmapiu[int(Ncol/2),:]=np.array([1,1,1,1])
  cmapwu = ListedColormap(cmapiu)
  levels=[np.linspace(-Vmm, Vmm, Ncol),np.linspace(-Vmm, Vmm, Ncol)]
  CBlevels=[np.arange(-Vmm+CBint, Vmm, CBint),np.arange(-Vmm+CBint, Vmm, CBint)]

  kwMC = {'levels':[SigLev], 'colors':['g'], 'linestyles':['solid'],
        'linewidths':[1.]}
  if SigLev is not None:
    kwMCf = {'levels':[0,SigLev,1.01], 'hatches':["","..."],'colors':['none']}

  Fi=['(a)','(b)']
  proj=ccrs.PlateCarree()

  fig = plt.figure(figsize=(14,6.9))
  gs = gridspec.GridSpec(5,1,width_ratios=[1],height_ratios=[0.08,1,1,0.03,0.07],
                         wspace=0.0, hspace=0.0)

  axT = fig.add_subplot(gs[0,0])
  axT.axis('off')
  axT.text(0.5,0.5,FigTitle,weight='bold',fontsize=20,ha='center')

  axs = {}
  plots = {}
  plotsCB = {}
  for i in np.arange(0,2):
    axnm='ax'+str(i+1)
    varnm='w'+str(i+1)
    varMCnm='w'+str(i+1)+'MC'
    axs[axnm] = fig.add_subplot(gs[i+1,0],projection=proj) 
    
    plots[axnm] = dsW[varnm].plot.contourf(ax=axs[axnm],
          transform=ccrs.PlateCarree(),robust=False, add_colorbar=False,
          colors=cmapwu,center=0.0,levels=levels[i])
    plotsCB[axnm]=plots[axnm]
    if useMC[i]:
      plots[axnm] = dsW[varMCnm].plot.contour(ax=axs[axnm],
            transform=ccrs.PlateCarree(),robust=False, add_colorbar=False, 
                                                    **kwMC)
      plots[axnm] = dsW[varMCnm].plot.contourf(ax=axs[axnm],
            transform=ccrs.PlateCarree(),robust=False,add_colorbar=False, 
                                **kwMCf)
      for ii, collection in enumerate(plots[axnm].collections):
        collection.set_facecolor('none')  
        collection.set_edgecolor('0.6')
        collection.set_linewidth(0.0)
    axs[axnm].coastlines()
    axs[axnm].set_title(Title[i],fontsize=16)
    axs[axnm].set_title(Fi[i],loc='left',weight='bold',fontsize=16)
    if (i==0):
      axs[axnm].plot([Lonb,Lonb,Lone,Lone,Lonb], [Latb,Late,Late,Latb,Latb],
         color='darkgray', linewidth=2, linestyle='dashed',
         transform=ccrs.PlateCarree(), #remove this line to get straight lines
         )
    gl = axs[axnm].gridlines(draw_labels=True, crs=proj)
    gl.xlines=False
    gl.ylines=False
    gl.top_labels = False
    gl.ylocator = MultipleLocator(20)
    gl.xlabel_style = {'size': 14, 'color': 'black'}
    gl.ylabel_style = {'size': 14, 'color': 'black'}

  cbSMB = fig.add_subplot(gs[4,0])
  colourb=plt.colorbar(plotsCB['ax1'],
          cbSMB,#label=CBTitle,
          ticks=CBlevels[0],orientation="horizontal",
          extend='neither')
  colourb.set_label(CBTitle,fontsize=14)
  colourb.ax.tick_params(labelsize=14)
  if FigForm is not None:
    plt.savefig(PathFig+Fignm,bbox_inches='tight',
              pad_inches=0.02,format=FigForm)

###################################
def Plot2_2(u1,u2,v1,v2,Umm,Vmm,Zmm,CBintU,CBintV,Cint,Cscale,Ncol,
          uTitle,vTitle,CBTitleU,CBTitleV,
          FigTitle,PathFig,Fignm,FigForm):
  # Two plots with different scaling and with two fields
  # u1/2(lat,lon)
  # v1/2(lat,lon)
  # V/V/ZmmU: plot range [-Vmm;Vmm]
  # CBintU/V: Colour table interval between ticks
  # Cscale: scale of countourlines of u/v2
  # Cint: interval of levels in u/v2
  # Ncol: Number of coloor-shading levels
  # uTitle
  # vTitle
  # CBTitleU/V: Colour-table title
  # PathFig: Path to figure output
  # Fignm: Filename of figure output
  # FigForm: Formate of figure file (if None: no figure output in file)
    
  dsW=u1.rename('w1')
  dsW=xr.merge([dsW,u2.rename('w2')])
  dsW=xr.merge([dsW,v1.rename('wZ1')])
  dsW=xr.merge([dsW,v2.rename('wZ2')])
  Title=[uTitle,vTitle]
  CBTitle=[CBTitleU,CBTitleV]

#  cmap = plt.cm.get_cmap("bwr",Ncol)
  cmap = plt.cm.get_cmap("RdBu_r",Ncol)
  cmapi=cmap(np.linspace(0, 1, Ncol))
  cmapi[int(Ncol/2-1),:]=np.array([1,1,1,1])
  cmapw = ListedColormap(cmapi)
  cmapiu=cmap(np.linspace(0, 1, Ncol))
  cmapiu[int(Ncol/2),:]=np.array([1,1,1,1])
  cmapwu = ListedColormap(cmapiu)
  levels=[np.linspace(-Umm, Umm, Ncol),np.linspace(-Vmm, Vmm, Ncol)]
  CBlevels=[np.arange(-Umm+CBintU, Umm, CBintU),
            np.arange(-Vmm+CBintV, Vmm, CBintV)]

  levelsZ=np.arange(-Zmm,Zmm+1,Cint)
#  levelsZ=np.array([1,2,3])
  linest=np.where(levelsZ<0,'dotted','solid')
  linew=np.where(levelsZ==0,3,2)
  kw = {'levels':levelsZ, 'colors':['g'],
            'linestyles':linest,'linewidths':linew}

  Fi=['(a)','(b)']
  proj=ccrs.PlateCarree()

#  fig = plt.figure(figsize=(15,8.1))
#  gs = gridspec.GridSpec(6,1,width_ratios=[1],height_ratios=[0.1,1,0.06,0.3,1,0.06],
#                         wspace=0.0, hspace=0.0)
  fig = plt.figure(figsize=(15,8.5))
  gs = gridspec.GridSpec(8,1,width_ratios=[1],\
                         height_ratios=[0.02,1,0.01,0.06,0.2,1,0.01,0.06],
                         wspace=0.0, hspace=0.0)

  axT = fig.add_subplot(gs[0,0])
  axT.axis('off')
  axT.text(0.5,0.5,FigTitle,weight='bold',fontsize=20,ha='center')

  axs = {}
  plots = {}
  plotsCB = {}
  for i in np.arange(0,2):
    axnm='ax'+str(i+1)
    varnm='w'+str(i+1)
    varnmZ='wZ'+str(i+1)
    if (i==0):
      vf=1
    elif (i==1):
      vf=4+1
    axs[axnm] = fig.add_subplot(gs[vf,0],projection=proj) 
    
    plots[axnm] = dsW[varnm].plot.contourf(ax=axs[axnm],
          transform=ccrs.PlateCarree(),robust=False, add_colorbar=False,
          colors=cmapwu,center=0.0,levels=levels[i])
    plotsCB[axnm]=plots[axnm]
    plots[axnm] = dsW[varnmZ].plot.contour(ax=axs[axnm],
            transform=ccrs.PlateCarree(),robust=False, add_colorbar=False, 
                                                    **kw)
    fmt={}
    for l in plots[axnm].levels:
      fmt[l]=str(int(l)*Cscale)
    axs[axnm].clabel(plots[axnm],plots[axnm].levels,inline='True',
                     fmt=fmt,fontsize=10)
    axs[axnm].coastlines()
    axs[axnm].set_title(Title[i],fontsize=16)
    axs[axnm].set_title(Fi[i],loc='left',weight='bold',fontsize=16)
    gl = axs[axnm].gridlines(draw_labels=True, crs=proj)
    gl.xlines=False
    gl.ylines=False
    gl.top_labels = False
    gl.ylocator = MultipleLocator(20)
    gl.xlabel_style = {'size': 14, 'color': 'black'}
    gl.ylabel_style = {'size': 14, 'color': 'black'}

    cbSMB = fig.add_subplot(gs[vf+1+1,0])
    colourb=plt.colorbar(plotsCB[axnm],
          cbSMB,#label=CBTitle[i],
          ticks=CBlevels[i],orientation="horizontal",
          extend='neither')
    colourb.set_label(CBTitle[i],fontsize=14)
    colourb.ax.tick_params(labelsize=14)
  if FigForm is not None:
    plt.savefig(PathFig+Fignm,bbox_inches='tight',
              pad_inches=0.02,format=FigForm)

####################################
def Plot3(u1,u2,u3,Vmm,CBint,Ncol,
          u1Title,u2Title,u3Title,CBTitle,FigTitle,
          u1MC,u2MC,u3MC,SigLev,
          PathFig,Fignm,FigForm):
  # u1/2/3(lat,lon)
  # Vmm: plot range [-Vmm;Vmm]
  # CBint: Colour table interval between ticks
  # Ncol: Number of coloor-shading levels
  # u1/2/3Title
  # CBTitle: Colour-table title
  # u1/2/3MC: Significance of u (if None: not plotted)
  # SigLev: Levels of significance, a number in [0,1]
  # PathFig: Path to figure output
  # Fignm: Filename of figure output
  # FigForm: Formate of figure file (if None: no figure output in file)

  useMC=[True, True, True]
  dsW=u1.rename('w1')
  dsW=xr.merge([dsW,u2.rename('w2')])
  dsW=xr.merge([dsW,u3.rename('w3')])
  if u1MC is not None:
    dsW=xr.merge([dsW,u1MC.rename('w1MC')])
  else:
    useMC[0]=False
  if u2MC is not None:
    dsW=xr.merge([dsW,u2MC.rename('w2MC')])
  else:
    useMC[1]=False
  if u3MC is not None:
    dsW=xr.merge([dsW,u3MC.rename('w3MC')])
  else:
    useMC[2]=False
  Title=[u1Title,u2Title,u3Title]
    
#  cmap = plt.cm.get_cmap("bwr",Ncol)
  cmap = plt.cm.get_cmap("RdBu_r",Ncol)
  cmapi=cmap(np.linspace(0, 1, Ncol))
  cmapi[int(Ncol/2-1),:]=np.array([1,1,1,1])
  cmapw = ListedColormap(cmapi)
  cmapiu=cmap(np.linspace(0, 1, Ncol))
  cmapiu[int(Ncol/2),:]=np.array([1,1,1,1])
  cmapwu = ListedColormap(cmapiu)
  levels=np.linspace(-Vmm, Vmm, Ncol)
  CBlevels=np.arange(-Vmm+CBint, Vmm, CBint)
  if SigLev is not None:
    kwMC = {'levels':[SigLev], 'colors':['g'], 'linestyles':['solid'],
        'linewidths':[1.]}
    kwMCf = {'levels':[0,SigLev,1.01], 'hatches':["","..."],'colors':['none']}
    
  Fi=['(a)','(b)','(c)']
  proj=ccrs.PlateCarree()

  fig = plt.figure(figsize=(15,9.7)) 
  gs = gridspec.GridSpec(5,1,width_ratios=[1],height_ratios=[0.15,1,1,1,0.06],
                         wspace=0.07, hspace=0.0)

  axT = fig.add_subplot(gs[0,0])
  axT.axis('off')
  axT.text(0.5,0.5,FigTitle,weight='bold',size='x-large',ha='center')

  axs = {}
  plots = {}
  plotsCB= {}
  for i in np.arange(0,3):
    axnm='ax'+str(i+1)
    varnm='w'+str(i+1)
    varMCnm='w'+str(i+1)+'MC'
    vf=i+1
    hf=0
    axs[axnm] = fig.add_subplot(gs[vf,hf],projection=proj) 
    
    plots[axnm] = dsW[varnm].plot(ax=axs[axnm],
          transform=ccrs.PlateCarree(),robust=False, add_colorbar=False,
          colors=cmapwu,center=0.0,levels=levels)
    plotsCB[axnm]=plots[axnm]
    if useMC[i]:
      plots[axnm] = dsW[varMCnm].plot.contour(ax=axs[axnm],
            transform=ccrs.PlateCarree(),robust=False, add_colorbar=False, 
                                                    **kwMC)
      plots[axnm] = dsW[varMCnm].plot.contourf(ax=axs[axnm],
            transform=ccrs.PlateCarree(),robust=False,add_colorbar=False, 
                                **kwMCf)
      for ii, collection in enumerate(plots[axnm].collections):
        collection.set_facecolor('none')  
        collection.set_edgecolor('0.6')
        collection.set_linewidth(0.0)
    axs[axnm].coastlines()
    axs[axnm].set_title(Title[i])
    axs[axnm].set_title(Fi[i],loc='left',weight='bold',fontsize=15)

  cbSMB = fig.add_subplot(gs[4,0])
  plt.colorbar(plotsCB['ax1'],
          cbSMB,label=CBTitle,
          ticks=CBlevels,orientation="horizontal",
          extend='neither')
  if FigForm is not None:
    plt.savefig(PathFig+Fignm,bbox_inches='tight',
              pad_inches=0.02,format=FigForm)

def Plot4(u1,v1,u2,v2,Vmm1,Vmm2,CBint1,CBint2,Ncol,
          u1Title,v1Title,u2Title,v2Title,CBTitle,FigTitle,
          u1MC,v1MC,u2MC,v2MC,SigLev,
          PathFig,Fignm,FigForm):
  # u1/2(lat,lon)
  # v1/2(lat,lon)
  # Vmm: plot range [-Vmm;Vmm]
  # CBint: Colour table interval between ticks
  # Ncol: Number of coloor-shading levels
  # u1/2Title
  # v1/2Title
  # CBTitle: Colour-table title
  # u1/2MC: Significance of u (if None: not plotted)
  # v1/2MC: Significance of v (if None: not plotted)
  # SigLev: Levels of significance, a number in [0,1]
  # PathFig: Path to figure output
  # Fignm: Filename of figure output
  # FigForm: Formate of figure file (if None: no figure output in file)

  useMC=[True, True, True, True]
  dsW=u1.rename('w1')
  dsW=xr.merge([dsW,v1.rename('w2')])
  dsW=xr.merge([dsW,u2.rename('w3')])
  dsW=xr.merge([dsW,v2.rename('w4')])
  if u1MC is not None:
    dsW=xr.merge([dsW,u1MC.rename('w1MC')])
  else:
    useMC[0]=False
  if v1MC is not None:
    dsW=xr.merge([dsW,v1MC.rename('w2MC')])
  else:
    useMC[1]=False
  if u2MC is not None:
    dsW=xr.merge([dsW,u2MC.rename('w3MC')])
  else:
    useMC[2]=False
  if v2MC is not None:
    dsW=xr.merge([dsW,v2MC.rename('w4MC')])
  else:
    useMC[3]=False
  Title=[u1Title,v1Title,u2Title,v2Title]
    
#  cmap = plt.cm.get_cmap("bwr",Ncol)
  cmap = plt.cm.get_cmap("RdBu_r",Ncol)
  cmapi=cmap(np.linspace(0, 1, Ncol))
  cmapi[int(Ncol/2-1),:]=np.array([1,1,1,1])
  cmapw = ListedColormap(cmapi)
  cmapiu=cmap(np.linspace(0, 1, Ncol))
  cmapiu[int(Ncol/2),:]=np.array([1,1,1,1])
  cmapwu = ListedColormap(cmapiu)
  levels=[np.linspace(-Vmm1, Vmm1, Ncol),np.linspace(-Vmm1, Vmm1, Ncol),
          np.linspace(-Vmm2, Vmm2, Ncol),np.linspace(-Vmm2, Vmm2, Ncol)]
  CBlevels=[np.arange(-Vmm1+CBint1, Vmm1, CBint1),np.arange(-Vmm1+CBint1, Vmm1, CBint1),
            np.arange(-Vmm2+CBint2, Vmm2, CBint2),np.arange(-Vmm2+CBint2, Vmm2, CBint2)]
  kwMC = {'levels':[SigLev], 'colors':['g'], 'linestyles':['solid'],
        'linewidths':[1.]}
  if SigLev is not None:
    kwMCf = {'levels':[0,SigLev,1.01], 'hatches':["","..."],'colors':['none']}
    
  Fi=['(a)','(b)','(c)','(d)']
  proj=ccrs.PlateCarree()

#  fig = plt.figure(figsize=(15,3.9))
  fig = plt.figure(figsize=(16,4.3))
  gs = gridspec.GridSpec(4,2,width_ratios=[1,1],
                         height_ratios=[0.15,1,1,0.06],
                         wspace=0.07, hspace=0.0)

  Tit_gs = gridspec.GridSpecFromSubplotSpec(1,1, subplot_spec=gs[0,:])
  axT = fig.add_subplot(Tit_gs[0,0])
  axT.axis('off')
  axT.text(0.5,0.5,FigTitle,weight='bold',fontsize=18,ha='center')

  axs = {}
  plots = {}
  plotsCB= {}
  for i in np.arange(0,4):
    axnm='ax'+str(i+1)
    varnm='w'+str(i+1)
    varMCnm='w'+str(i+1)+'MC'
    vf=i % 2 +1
    hf=int(np.floor(i/2))
    axs[axnm] = fig.add_subplot(gs[vf,hf],projection=proj) 
    
    plots[axnm] = dsW[varnm].plot.contourf(ax=axs[axnm],
          transform=ccrs.PlateCarree(),robust=False, add_colorbar=False,
          colors=cmapwu,center=0.0,levels=levels[i])
    plotsCB[axnm]=plots[axnm]
    if useMC[i]:
      plots[axnm] = dsW[varMCnm].plot.contour(ax=axs[axnm],
            transform=ccrs.PlateCarree(),robust=False, add_colorbar=False, 
                                                    **kwMC)
      plots[axnm] = dsW[varMCnm].plot.contourf(ax=axs[axnm],
            transform=ccrs.PlateCarree(),robust=False,add_colorbar=False, 
                                **kwMCf)
      plots[axnm].set_facecolor('none')
      plots[axnm].set_edgecolor('0.6')
      plots[axnm].set_linewidth(0.0)
    axs[axnm].coastlines()
    axs[axnm].set_title(Title[i],fontsize=15)
    axs[axnm].set_title(Fi[i],loc='left',weight='bold',fontsize=15)

#  cbar_gs = gridspec.GridSpecFromSubplotSpec(1,1, subplot_spec=gs[2,:])
  cbSMB = fig.add_subplot(gs[3,0])
  colourb=plt.colorbar(plotsCB['ax1'],
          cbSMB,
          ticks=CBlevels[0],orientation="horizontal",
          extend='neither')
  colourb.set_label(CBTitle,fontsize=14)
  colourb.ax.tick_params(labelsize=12)
  cbSMB = fig.add_subplot(gs[3,1])
  colourb=plt.colorbar(plotsCB['ax3'],
          cbSMB,
          ticks=CBlevels[2],orientation="horizontal",
          extend='neither')
  colourb.set_label(CBTitle,fontsize=14)
  colourb.ax.tick_params(labelsize=12)
  if FigForm is not None:
    plt.savefig(PathFig+Fignm,bbox_inches='tight',
              pad_inches=0.02,format=FigForm)

#############################
def Plot6(u1,v1,u2,v2,u3,v3,Umm,Vmm,CBintU,CBintV,Ncol,
          u1Title,v1Title,u2Title,v2Title,u3Title,v3Title,
          CBTitleU,CBTitleV,FigTitle,
          u1MC,v1MC,u2MC,v2MC,u3MC,v3MC,SigLev,
          PathFig,Fignm,FigForm):
  # u1/2/3(lat,lon)
  # v1/2/3(lat,lon)
  # U/Vmm: plot range [-U/Vmm;U/Vmm]
  # CBint: Colour table interval between ticks
  # Ncol: Number of coloor-shading levels
  # u1/2/3Title
  # v1/2/3Title
  # CBTitleU/V: Colour-table title
  # u1/2/3MC: Significance of u (if None: not plotted)
  # v1/2/3MC: Significance of v (if None: not plotted)
  # SigLev: Levels of significance, a number in [0,1]
  # PathFig: Path to figure output
  # Fignm: Filename of figure output
  # FigForm: Formate of figure file (if None: no figure output in file)

  useMC=[True, True, True, True, True, True]
  dsW=u1.rename('w1')
  dsW=xr.merge([dsW,v1.rename('w2')])
  dsW=xr.merge([dsW,u2.rename('w3')])
  dsW=xr.merge([dsW,v2.rename('w4')])
  dsW=xr.merge([dsW,u3.rename('w5')])
  dsW=xr.merge([dsW,v3.rename('w6')])
  if u1MC is not None:
    dsW=xr.merge([dsW,u1MC.rename('w1MC')])
  else:
    useMC[0]=False
  if v1MC is not None:
    dsW=xr.merge([dsW,v1MC.rename('w2MC')])
  else:
    useMC[1]=False
  if u2MC is not None:
    dsW=xr.merge([dsW,u2MC.rename('w3MC')])
  else:
    useMC[2]=False
  if v2MC is not None:
    dsW=xr.merge([dsW,v2MC.rename('w4MC')])
  else:
    useMC[3]=False
  if u3MC is not None:
    dsW=xr.merge([dsW,u3MC.rename('w5MC')])
  else:
    useMC[4]=False
  if v3MC is not None:
    dsW=xr.merge([dsW,v3MC.rename('w6MC')])
  else:
    useMC[5]=False
  Title=[u1Title,v1Title,u2Title,v2Title,u3Title,v3Title]
    
#  cmap = plt.cm.get_cmap("bwr",Ncol)
  cmap = plt.cm.get_cmap("RdBu_r",Ncol)
  cmapi=cmap(np.linspace(0, 1, Ncol))
  cmapi[int(Ncol/2-1),:]=np.array([1,1,1,1])
  cmapw = ListedColormap(cmapi)
  cmapiu=cmap(np.linspace(0, 1, Ncol))
  cmapiu[int(Ncol/2),:]=np.array([1,1,1,1])
  cmapwu = ListedColormap(cmapiu)
  levels=[np.linspace(-Umm, Umm, Ncol),np.linspace(-Vmm, Vmm, Ncol),
          np.linspace(-Umm, Umm, Ncol),np.linspace(-Vmm, Vmm, Ncol),
          np.linspace(-Umm, Umm, Ncol),np.linspace(-Vmm, Vmm, Ncol)]
  CBlevels=[np.arange(-Umm+CBintU, Umm, CBintU),np.arange(-Vmm+CBintV, Vmm, CBintV),
            np.arange(-Umm+CBintU, Umm, CBintU),np.arange(-Vmm+CBintV, Vmm, CBintV),
            np.arange(-Umm+CBintU, Umm, CBintU),np.arange(-Vmm+CBintV, Vmm, CBintV)]
  if SigLev is not None:
    kwMC = {'levels':[SigLev], 'colors':['g'], 'linestyles':['solid'],
            'linewidths':[1.]}
    kwMCf = {'levels':[0,SigLev,1.01], 'hatches':["","..."],'colors':['none']}
    
  proj=ccrs.PlateCarree()

  fig = plt.figure(figsize=(15,6.5)) 
  gs = gridspec.GridSpec(5,2,width_ratios=[1,1],height_ratios=[0.15,1,1,1,0.06],
                         wspace=0.07, hspace=0.0)

  Tit_gs = gridspec.GridSpecFromSubplotSpec(1,1, subplot_spec=gs[0,:])
  axT = fig.add_subplot(Tit_gs[0,0])
  axT.axis('off')
  axT.text(0.5,0.5,FigTitle,weight='bold',size='x-large',ha='center')

  axs = {}
  plots = {}
  plotsCB= {}
  for i in np.arange(0,6):
    axnm='ax'+str(i+1)
    varnm='w'+str(i+1)
    varMCnm='w'+str(i+1)+'MC'
#    vf=i % 2 +1
#    hf=int(np.floor(i/2))
    vf=int(np.floor(i/2))+1
    hf=i % 2
    axs[axnm] = fig.add_subplot(gs[vf,hf],projection=proj) 
    
    plots[axnm] = dsW[varnm].plot(ax=axs[axnm],
          transform=ccrs.PlateCarree(),robust=False, add_colorbar=False,
          colors=cmapwu,center=0.0,levels=levels[i])
    plotsCB[axnm]=plots[axnm]
    if useMC[i]:
      plots[axnm] = dsW[varMCnm].plot.contour(ax=axs[axnm],
            transform=ccrs.PlateCarree(),robust=False, add_colorbar=False, 
                                                    **kwMC)
      plots[axnm] = dsW[varMCnm].plot.contourf(ax=axs[axnm],
            transform=ccrs.PlateCarree(),robust=False,add_colorbar=False, 
                                **kwMCf)
      for ii, collection in enumerate(plots[axnm].collections):
        collection.set_facecolor('none')  
        collection.set_edgecolor('0.6')
        collection.set_linewidth(0.0)
    axs[axnm].coastlines()
    axs[axnm].title.set_text(Title[i])

#  cbar_gs = gridspec.GridSpecFromSubplotSpec(1,1, subplot_spec=gs[2,:])
  cbSMB = fig.add_subplot(gs[4,0])
  plt.colorbar(plotsCB['ax1'],
          cbSMB,label=CBTitleU,
          ticks=CBlevels[0],orientation="horizontal",
          extend='neither')
  cbSMB = fig.add_subplot(gs[4,1])
  plt.colorbar(plotsCB['ax2'],
          cbSMB,label=CBTitleV,
          ticks=CBlevels[1],orientation="horizontal",
          extend='neither')
  if FigForm is not None:
    plt.savefig(PathFig+Fignm,bbox_inches='tight',
              pad_inches=0.02,format=FigForm)

def get_axis_limits(ax, scaleX, scaleY):
    return ax.get_xlim()[1]*scaleX, ax.get_ylim()[1]*scaleY

###################################                                          
def Plot4_2(u1,u2,v1,v2,w,x,y,yfit,Umm,Vmm,Zmm,Wmm,
            CBintU,CBintV,CBintW,Cint,Cscale,Ncol,
            uTitle,vTitle,wTitle,xTitle,yTitle,scTitle,frText,
            CBTitleU,CBTitleV,CBTitleW,
          FigTitle,PathFig,Fignm,FigForm):
  # Two plots with different scaling and with two fields                     
  # u1/2(lat,lon)                                                            
  # v1/2(lat,lon)                                                            
  # V/V/ZmmU: plot range [-Vmm;Vmm]                                          
  # CBintU/V: Colour table interval between ticks                            
  # Cscale: scale of countourlines of u/v2                                   
  # Cint: interval of levels in u/v2                                         
  # Ncol: Number of coloor-shading levels                                    
  # uTitle                                                                   
  # vTitle                                                                   
  # CBTitleU/V: Colour-table title                                           
  # PathFig: Path to figure output                                           
  # Fignm: Filename of figure output                                         
  # FigForm: Formate of figure file (if None: no figure output in file)      

  dsW=w.rename('w1')
  dsW=xr.merge([dsW,u1.rename('w2')])
  dsW=xr.merge([dsW,u2.rename('w3')])
  dsW=xr.merge([dsW,v1.rename('wZ2')])
  dsW=xr.merge([dsW,v2.rename('wZ3')])
  Title=[wTitle,uTitle,vTitle]
  CBTitle=[CBTitleW,CBTitleU,CBTitleV]

#  cmap = plt.cm.get_cmap("bwr",Ncol)                                        
  cmap = plt.cm.get_cmap("RdBu_r",Ncol)
  cmapi=cmap(np.linspace(0, 1, Ncol))
  cmapi[int(Ncol/2-1),:]=np.array([1,1,1,1])
  cmapw = ListedColormap(cmapi)
  cmapiu=cmap(np.linspace(0, 1, Ncol))
  cmapiu[int(Ncol/2),:]=np.array([1,1,1,1])
  cmapwu = ListedColormap(cmapiu)
  levels=[np.linspace(-Wmm, Wmm, Ncol),np.linspace(-Umm, Umm, Ncol),\
          np.linspace(-Vmm, Vmm, Ncol)]
  CBlevels=[np.arange(-Wmm+CBintW, Wmm, CBintW),\
            np.arange(-Umm+CBintU, Umm, CBintU),\
            np.arange(-Vmm+CBintV, Vmm, CBintV)]

  levelsZ=np.arange(-Zmm,Zmm+1,Cint)
#  levelsZ=np.array([1,2,3])                                                 
  linest=np.where(levelsZ<0,'dotted','solid')
  linew=np.where(levelsZ==0,3,2)
  kw = {'levels':levelsZ, 'colors':['g'],
            'linestyles':linest,'linewidths':linew}

  Fi=['(a)','(b)','(c)','(d)']
  proj=ccrs.PlateCarree()

#  fig = plt.figure(figsize=(15,18))
#  gs = gridspec.GridSpec(11,1,width_ratios=[1],\
#      height_ratios=[0.1,1,0.06,0.3,1,0.06,0.3,1,0.06,0.55,1.2],
#      wspace=0.0, hspace=0.0)
  fig = plt.figure(figsize=(15,19))
  gs = gridspec.GridSpec(11,1,width_ratios=[1],\
      height_ratios=[0.03,1,0.06,0.21,1,0.06,0.21,1,0.06,0.47,1.2],
      wspace=0.0, hspace=0.0)

  axT = fig.add_subplot(gs[0,0])
  axT.axis('off')
  axT.text(0.5,0.5,FigTitle,weight='bold',fontsize=20,ha='center')

  axs = {}
  plots = {}
  plotsCB = {}
  dd=3
  for i in np.arange(0,3):
    axnm='ax'+str(i+1)
    varnm='w'+str(i+1)
    varnmZ='wZ'+str(i+1)
    vf=1+dd*i
    axs[axnm] = fig.add_subplot(gs[vf,0],projection=proj)

    plots[axnm] = dsW[varnm].plot.contourf(ax=axs[axnm],
          transform=ccrs.PlateCarree(),robust=False, add_colorbar=False,
          colors=cmapwu,center=0.0,levels=levels[i])
    plotsCB[axnm]=plots[axnm]
    if (i>0):
      plots[axnm] = dsW[varnmZ].plot.contour(ax=axs[axnm],
            transform=ccrs.PlateCarree(),robust=False, add_colorbar=False,
                                                    **kw)
      fmt={}
      for l in plots[axnm].levels:
        fmt[l]=str(int(l)*Cscale)
      axs[axnm].clabel(plots[axnm],plots[axnm].levels,inline='True',
                     fmt=fmt,fontsize=10)
    axs[axnm].coastlines()
    axs[axnm].set_title(Title[i],fontsize=16)
    axs[axnm].set_title(Fi[i],loc='left',weight='bold',fontsize=16)
    gl = axs[axnm].gridlines(draw_labels=True, crs=proj)
    gl.xlines=False
    gl.ylines=False
    gl.top_labels = False
    gl.ylocator = MultipleLocator(20)
    gl.xlabel_style = {'size': 14, 'color': 'black'}
    gl.ylabel_style = {'size': 14, 'color': 'black'}

    cbSMB = fig.add_subplot(gs[vf+1,0])
    colourb=plt.colorbar(plotsCB[axnm],
          cbSMB,
          ticks=CBlevels[i],orientation="horizontal",
          extend='neither')
    colourb.set_label(CBTitle[i],fontsize=14)
    colourb.ax.tick_params(labelsize=14)

  axnm='ax4'
  ScatGr= gridspec.GridSpecFromSubplotSpec(
    1, 3, subplot_spec=gs[10, 0],
    width_ratios=[0.3, 0.4, 0.3])
  axs[axnm] = fig.add_subplot(ScatGr[0,1])
  plots[axnm]=axs[axnm].scatter(x,y,c='black',s=2.)
  plots[axnm]=axs[axnm].plot(x,yfit,color='red')
  axs[axnm].set_xlabel(xTitle,fontsize=14)
  axs[axnm].set_ylabel(yTitle,fontsize=14)
  axs[axnm].set_title(scTitle,fontsize=16)
  axs[axnm].set_title(Fi[3],loc='left',weight='bold',fontsize=16)
  axs[axnm].text(0.78, 0.94, frText, transform=plt.gca().transAxes,
         fontsize=13, verticalalignment='top',
         bbox=dict(facecolor='white', alpha=0.5, boxstyle='round,pad=0.5'))
  if FigForm is not None:
    plt.savefig(PathFig+Fignm,bbox_inches='tight',
              pad_inches=0.02,format=FigForm)

####################################                                         
def Plot4_2x2(u1,u2,x1,y1,yfit1,x2,y2,yfit2,x3,y3,yfit3,x4,y4,yfit4,
            Umm1,Umm2,CBintU1,CBintU2,Ncol,
            uTitle1,uTitle2,
            xTitle,yTitle,
            scTitle1,scTitle2,scTitle3,scTitle4,
            frText1,frText2,frText3,frText4,
            CBTitleU1,CBTitleU2,
            FigTitle,PathFig,Fignm,FigForm):
  # Two plots with different scaling and with two fields
  # u1/2(lat,lon)
  # v1/2(lat,lon)
  # V/V/ZmmU: plot range [-Vmm;Vmm]
  # CBintU/V: Colour table interval between ticks
  # Cscale: scale of countourlines of u/v2
  # Cint: interval of levels in u/v2
  # Ncol: Number of coloor-shading levels
  # uTitle
  # vTitle
  # CBTitleU/V: Colour-table title
  # PathFig: Path to figure output
  # Fignm: Filename of figure output
  # FigForm: Formate of figure file (if None: no figure output in file) 

  dsW=u1.rename('w1')
  dsW=xr.merge([dsW,u2.rename('w2')])
  dsSP=xr.DataArray(x1).rename('x1').rename({'dim_0': 't1'})
  dsSP=xr.merge([dsSP,xr.DataArray(y1).rename('y1').\
                 rename({'dim_0':'t1'})])
  dsSP=xr.merge([dsSP,xr.DataArray(yfit1).rename('yf1').\
                 rename({'dim_0':'t1'})])
  dsSP=xr.merge([dsSP,xr.DataArray(x2).rename('x2').\
                 rename({'dim_0':'t2'})])
  dsSP=xr.merge([dsSP,xr.DataArray(y2).rename('y2').\
                 rename({'dim_0':'t2'})])
  dsSP=xr.merge([dsSP,xr.DataArray(yfit2).rename('yf2').\
                 rename({'dim_0':'t2'})])
  dsSP=xr.merge([dsSP,xr.DataArray(x3).rename('x3').\
                 rename({'dim_0':'t3'})])
  dsSP=xr.merge([dsSP,xr.DataArray(y3).rename('y3').\
                 rename({'dim_0':'t3'})])
  dsSP=xr.merge([dsSP,xr.DataArray(yfit3).rename('yf3').\
                 rename({'dim_0':'t3'})])
  dsSP=xr.merge([dsSP,xr.DataArray(x4).rename('x4').\
                 rename({'dim_0':'t4'})])
  dsSP=xr.merge([dsSP,xr.DataArray(y4).rename('y4').\
                 rename({'dim_0':'t4'})])
  dsSP=xr.merge([dsSP,xr.DataArray(yfit4).rename('yf4').\
                 rename({'dim_0':'t4'})])
  Title=[uTitle1,uTitle2]
  CBTitle=[CBTitleU1,CBTitleU2]
  TitleSP=[scTitle1,scTitle2,scTitle3,scTitle4]
  frTextSP=[frText1,frText2,frText3,frText4]

  cmap = plt.cm.get_cmap("RdBu_r",Ncol)
  cmapi=cmap(np.linspace(0, 1, Ncol))
  cmapi[int(Ncol/2-1),:]=np.array([1,1,1,1])
  cmapw = ListedColormap(cmapi)
  cmapiu=cmap(np.linspace(0, 1, Ncol))
  cmapiu[int(Ncol/2),:]=np.array([1,1,1,1])
  cmapwu = ListedColormap(cmapiu)
  levels=[np.linspace(-Umm1, Umm1, Ncol),np.linspace(-Umm2, Umm2, Ncol)]  
  CBlevels=[np.arange(-Umm1+CBintU1, Umm1, CBintU1),\
            np.arange(-Umm2+CBintU2, Umm2, CBintU2)]

  Fi=['(a)','(b)','(c)','(d)','(e)','(f)']
  proj=ccrs.PlateCarree()

#  fig = plt.figure(figsize=(15,24))
#  gs = gridspec.GridSpec(9,1,width_ratios=[1],\
#        height_ratios=[0.1,1,0.06,0.3,1,0.06,0.4,2.3,2.3],
#        wspace=0.0, hspace=0.0)
  fig = plt.figure(figsize=(15,25.5))
  gs = gridspec.GridSpec(9,1,width_ratios=[1],\
        height_ratios=[0.05,1,0.06,0.23,1,0.06,0.4,2.3,2.3],
        wspace=0.0, hspace=0.0)

  axT = fig.add_subplot(gs[0,0])
  axT.axis('off')
  axT.text(0.5,0.5,FigTitle,weight='bold',fontsize=20,ha='center')

  axs = {}
  plots = {}
  plotsCB = {}
  dd=3
  for i in np.arange(0,2):
    axnm='ax'+str(i+1)
    varnm='w'+str(i+1)
    vf=1+dd*i
    axs[axnm] = fig.add_subplot(gs[vf,0],projection=proj)

    plots[axnm] = dsW[varnm].plot.contourf(ax=axs[axnm],
          transform=ccrs.PlateCarree(),robust=False, add_colorbar=False,
          colors=cmapwu,center=0.0,levels=levels[i])
    plotsCB[axnm]=plots[axnm]

    axs[axnm].coastlines()
    axs[axnm].set_title(Title[i],fontsize=16)
    axs[axnm].set_title(Fi[i],loc='left',weight='bold',fontsize=16)
    gl = axs[axnm].gridlines(draw_labels=True, crs=proj)
    gl.xlines=False
    gl.ylines=False
    gl.top_labels = False
    gl.ylocator = MultipleLocator(20)
    gl.xlabel_style = {'size': 14, 'color': 'black'}
    gl.ylabel_style = {'size': 14, 'color': 'black'}

    cbSMB = fig.add_subplot(gs[vf+1,0])
    colourb=plt.colorbar(plotsCB[axnm],
          cbSMB,
          ticks=CBlevels[i],orientation="horizontal",
          extend='neither')
    colourb.set_label(CBTitle[i],fontsize=14)
    colourb.ax.tick_params(labelsize=14)

  ddd=7
  df=0
  dd=2
  ScatGr= gridspec.GridSpecFromSubplotSpec(
    3, 5, subplot_spec=gs[ddd:ddd+1, 0],
    width_ratios=[0.4,1,0.1,1,0.4],height_ratios=[1,0.2,1])

  for iv in np.arange(0,2):
    for ih in np.arange(0,2):
      axnm='ax'+str(iv)+str(ih)
      xnm='x'+str(df+1)
      ynm='y'+str(df+1)
      yfnm='yf'+str(df+1)
      axs[axnm] = fig.add_subplot(ScatGr[iv*2,ih*2+1])
      plots[axnm]=axs[axnm].scatter(dsSP[xnm],dsSP[ynm],c='black',s=2.)
      plots[axnm]=axs[axnm].plot(dsSP[xnm],dsSP[yfnm],color='red')
      axs[axnm].set_xlabel(xTitle,fontsize=14)
      axs[axnm].set_ylabel(yTitle,fontsize=14)
      axs[axnm].set_title(TitleSP[df],fontsize=16)
      axs[axnm].set_title(Fi[df+dd],loc='left',weight='bold',fontsize=16)
      axs[axnm].text(0.75,0.92,frTextSP[df],\
        transform=plt.gca().transAxes,
         fontsize=13, verticalalignment='top',
         bbox=dict(facecolor='white', alpha=0.5,
         boxstyle='round,pad=0.5'))
      df=df+1
  if FigForm is not None:
    plt.savefig(PathFig+Fignm,bbox_inches='tight',
              pad_inches=0.02,format=FigForm)

####################################
def Plot3_AdvG(u1,u2,v1,v2,w,Umm,Vmm,Zmm,Wmm,
            CBintU,CBintV,CBintW,Cint,Cscale,Ncol,
            uTitle,vTitle,wTitle,
            CBTitleU,CBTitleV,CBTitleW,
          FigTitle,PathFig,Fignm,FigForm):
  # Two plots with different scaling and with two fields
  # u1/2(lat,lon)
  # v1/2(lat,lon)
  # V/V/ZmmU: plot range [-Vmm;Vmm]
  # CBintU/V: Colour table interval between ticks
  # Cscale: scale of countourlines of u/v2
  # Cint: interval of levels in u/v2
  # Ncol: Number of coloor-shading levels
  # uTitle
  # vTitle
  # CBTitleU/V: Colour-table title
  # PathFig: Path to figure output
  # Fignm: Filename of figure output
  # FigForm: Formate of figure file (if None: no figure output in file)
  
  dsW=u1.rename('w1')
  dsW=xr.merge([dsW,u2.rename('w2')])
  dsW=xr.merge([dsW,w.rename('w3')])
  dsW=xr.merge([dsW,v1.rename('wZ1')])
  dsW=xr.merge([dsW,v2.rename('wZ2')])
  Title=[uTitle,vTitle,wTitle]
  CBTitle=[CBTitleU,CBTitleV,CBTitleW]

  cmap = plt.cm.get_cmap("RdBu_r",Ncol)
  cmapi=cmap(np.linspace(0, 1, Ncol))
  cmapi[int(Ncol/2-1),:]=np.array([1,1,1,1])
  cmapw = ListedColormap(cmapi)
  cmapiu=cmap(np.linspace(0, 1, Ncol))
  cmapiu[int(Ncol/2),:]=np.array([1,1,1,1])
  cmapwu = ListedColormap(cmapiu)
  levels=[np.linspace(-Umm, Umm, Ncol),np.linspace(-Vmm, Vmm, Ncol),\
          np.linspace(-Wmm, Wmm, Ncol)]
  CBlevels=[np.arange(-Umm+CBintU, Umm, CBintU),\
            np.arange(-Vmm+CBintV, Vmm, CBintV),\
            np.arange(-Wmm+CBintW, Wmm, CBintW)]

  levelsZ=np.arange(-Zmm,Zmm+1,Cint)

  linest=np.where(levelsZ<0,'dotted','solid')
  linew=np.where(levelsZ==0,3,2)
  kw = {'levels':levelsZ, 'colors':['g'],
            'linestyles':linest,'linewidths':linew}

  Fi=['(a)','(b)','(c)']
  proj=ccrs.PlateCarree()

  fig = plt.figure(figsize=(15,16))
  gs = gridspec.GridSpec(10,1,width_ratios=[1],\
      height_ratios=[0.03,1,0.06,0.21,1,0.06,0.21,1,0.06,0.47],
      wspace=0.0, hspace=0.0)

  axT = fig.add_subplot(gs[0,0])
  axT.axis('off')
  axT.text(0.5,0.5,FigTitle,weight='bold',fontsize=32,ha='center')

  axs = {}
  plots = {}
  plotsCB = {}
  dd=3
  for i in np.arange(0,3):
    axnm='ax'+str(i+1)
    varnm='w'+str(i+1)
    varnmZ='wZ'+str(i+1)
    vf=1+dd*i
    axs[axnm] = fig.add_subplot(gs[vf,0],projection=proj)

    plots[axnm] = dsW[varnm].plot.contourf(ax=axs[axnm],
          transform=ccrs.PlateCarree(),robust=False, add_colorbar=False,
          colors=cmapwu,center=0.0,levels=levels[i])
    plotsCB[axnm]=plots[axnm]
#    if (i>0):
    if (i<2):
      plots[axnm] = dsW[varnmZ].plot.contour(ax=axs[axnm],
            transform=ccrs.PlateCarree(),robust=False, add_colorbar=False,
                                                    **kw)
      fmt={}
      for l in plots[axnm].levels:
        fmt[l]=str(int(l)*Cscale)
      axs[axnm].clabel(plots[axnm],plots[axnm].levels,inline='True',
                     fmt=fmt,fontsize=20)
    axs[axnm].coastlines()
    axs[axnm].set_title(Title[i],weight='bold',fontsize=22)
#    axs[axnm].set_title(Fi[i],loc='left',weight='bold',fontsize=16)
    gl = axs[axnm].gridlines(draw_labels=True, crs=proj)
    gl.xlines=False
    gl.ylines=False
    gl.top_labels = False
    gl.ylocator = MultipleLocator(20)
    gl.xlabel_style = {'size': 18, 'color': 'black'}
    gl.ylabel_style = {'size': 18, 'color': 'black'}

    cbSMB = fig.add_subplot(gs[vf+1,0])
    colourb=plt.colorbar(plotsCB[axnm],
          cbSMB,
          ticks=CBlevels[i],orientation="horizontal",
          extend='neither')
    colourb.set_label(CBTitle[i],fontsize=18)
    colourb.ax.tick_params(labelsize=18)

#  axnm='ax4'
#  ScatGr= gridspec.GridSpecFromSubplotSpec(
#    1, 3, subplot_spec=gs[10, 0],
#    width_ratios=[0.3, 0.4, 0.3])
#  axs[axnm] = fig.add_subplot(ScatGr[0,1])
#  plots[axnm]=axs[axnm].scatter(x,y,c='black',s=2.)
#  plots[axnm]=axs[axnm].plot(x,yfit,color='red')
#  axs[axnm].set_xlabel(xTitle,fontsize=14)
#  axs[axnm].set_ylabel(yTitle,fontsize=14)
#  axs[axnm].set_title(scTitle,fontsize=16)
#  axs[axnm].set_title(Fi[3],loc='left',weight='bold',fontsize=16)
#  axs[axnm].text(0.78, 0.94, frText, transform=plt.gca().transAxes,
#         fontsize=13, verticalalignment='top',
#         bbox=dict(facecolor='white', alpha=0.5, boxstyle='round,pad=0.5'))
  if FigForm is not None:
    plt.savefig(PathFig+Fignm,bbox_inches='tight',
              pad_inches=0.02,format=FigForm)

####################################                                              
