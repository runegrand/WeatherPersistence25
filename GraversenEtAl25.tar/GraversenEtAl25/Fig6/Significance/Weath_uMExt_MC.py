# -*- coding: utf-8 -*-       
## Weath_uMExt_MC.py
#
# sys.argv[1]: Nlag
# sys.argv[2]: Nlen, max anomaly length AND period over
#              which to calculate anomaly length
# sys.argv[3]: NMC, Number of MC number
# sys.argv[4]: SNB, Script number
# sys.argv[5]: NbR, Run Number
# sys.argv[6]: rMeth, Random method: 'BS' or 'FFT'
# 
# Rolling patterns over the difference of composites of
# warm and cold periods with zero lag at the first day
# of the period
# Periods (warm and cold Arctic) are produced by
#          WarmArctic.py
# Input data produced by "WeathVar.uM.Z.py"
#          and WarmArctic.py
####################
import xarray as xr
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cftime
import sys
import numpy as np
np.round_ = np.round
import time as TimeRun
import xrft
import os

#########################
# Setting tool script dir
# directory to tools script (tools.py and tools_plot.py)
toolPath=<tools_script_dir>
#toolPath='/cluster/home/runegg/python/WeathPers25/'
try:
    sys.path.index(toolPath)
except ValueError:
    sys.path.append(toolPath)
from tools import xfft_TLL, Change_yr
import warnings   ## Apparently solved by updating cftime 'conda update cftime'
warnings.filterwarnings("ignore", category=RuntimeWarning,
                        module="xarray.coding.times")

btime=TimeRun.time()

#Nlag = 90
#Nlen = 90
#NMC=10
#SNB=1
#NbR=1
#rMeth='BS'
Nlag = int(sys.argv[1])
Nlen = int(sys.argv[2])
NMC= int(sys.argv[3])
SNB= int(sys.argv[4])
NbR= int(sys.argv[5])
rMeth= sys.argv[6]

PathW=
PathUM=
pathAN=
PathAW=
#PathW='/cluster/projects/nn9348k/Rune/WeathPers25/work/SATvar/'
#PathUM='/cluster/projects/nn9348k/Rune/WeathPers25/work/uM/'
#PathAN='/cluster/projects/nn9348k/Rune/WeathPers25/work/ExtrArctic/FigData/'
#PathAW='/cluster/projects/nn9348k/Rune/WeathPers25/work/ExtrArc/'

Evar = "Z" # "SAT", "T" or "Z"

lat=xr.open_dataset(PathW+'/SATrm.1979.nc').lat
dlat=np.abs(lat[0].data-lat[1].data)

dates=xr.open_dataset(PathAW+'ArcticExtremes.nc')

datpO=dates["Zp"]
datnO=dates["Zn"]
Ndate=datpO.size

LatEnd=44
LatBeg=70
LatStep=2
LatLoop = np.arange(LatBeg,LatEnd,-LatStep)
lenRM=10

fileVar=PathAW+'FigData/uMRolling.'+Evar+'.Nlag'+str(Nlag)+'.RM'+str(lenRM)+'.nc'
UManDpO=xr.open_dataset(fileVar)['uM']

for iMC in range(NMC):
  if (rMeth=='FFT'):
    datp=datpO
    datn=datnO
  elif (rMeth=='BS'):
    datpc=Change_yr(datpO,1980,2022)
    datnc=Change_yr(datnO,1980,2022)
    datp = xr.DataArray(datpc,dims=["time"],\
      coords={"time": np.arange(1,Ndate+1)},name="Zp")
    datn = xr.DataArray(datnc,dims=["time"],
      coords={"time": np.arange(1,Ndate+1)},name="Zn")
  else:
    sys.exit('"rMeth" must be either "BS" or "FFT"')
  
  first=True
  for Lati in LatLoop:
    print("Calculating for latitude: "+str(Lati))
    latb=Lati
    late=Lati-LatStep+dlat

    pathSAT=PathUM+'uMan'+'_Lat'+str(late)+'to'+str(latb)+'.nc'

    SATan=xr.open_dataset(pathSAT)['uM'].compute()
    NtimeSAT=np.size(SATan.time)
    SATan=SATan[182:NtimeSAT-183,:,:]

    if (rMeth=='FFT'):
      print("Phase shift")
      SATanr=xfft_TLL(SATan)
      print("Phase shift done")
    elif (rMeth=='BS'):
      SATanr=SATan
    else:
      sys.exit('"rMeth" must be either "BS" or "FFT"')
      
    del SATan

    time=SATanr.time    
    firstp=0
    firstn=0
    for idate in np.arange(0,Ndate):
      dp=datp[idate]
      dn=datn[idate]
      if not (np.isnat(dp)):
        if (dp.dt.year > 1979) & (dp.dt.year < 2023):
          iExt=np.where(time==dp)[0][0]
          SATanWx=SATanr[iExt-Nlag:iExt+Nlen+Nlag,:,:]
          SATanWx=SATanWx.rename({'time': 'lag'})
          SATanWx['lag']=np.arange(-Nlag,Nlen+Nlag)
          if (firstp == 0):
            SATanW=SATanWx*1.
          else:
            SATanW=SATanW+SATanWx
          firstp=firstp+1
      if not (np.isnat(dn)):
        if (dn.dt.year > 1979) & (dn.dt.year < 2023):
          iExt=np.where(time==dn)[0][0]
          SATanCx=SATanr[iExt-Nlag:iExt+Nlen+Nlag,:,:]
          SATanCx=SATanCx.rename({'time': 'lag'})
          SATanCx['lag']=np.arange(-Nlag,Nlen+Nlag)
          if (firstn == 0):
            SATanC=SATanCx*1.
          else:
            SATanC=SATanC+SATanCx
          firstn=firstn+1

    SATanDL=SATanW/firstp - SATanC/firstn

    del SATanr

    if (first):
      uManD=SATanDL*1.
    else:
      uManD=xr.concat([uManD,SATanDL],dim="lat")

    first=False

  latuM=uManD['lat']
  lonuM=uManD['lon']
  coslat=np.cos(np.deg2rad(latuM))
  latANb=45
  latANe=70
  lonANb=-180
  lonANe=179.5
  lenRM=10

  UManDp=uManD.\
      sel(lon=((lonuM>=lonANb) & (lonuM<=lonANe))).\
      sel(lat=((latuM>=latANb) & (latuM<=latANe))).\
      weighted(coslat).mean(('lat','lon')).\
      rolling(lag=lenRM,center=True).mean()/1.E4

  del uManD

  # Compare random to origiional
  UManDpMCn=xr.DataArray(np.zeros([2*Nlag+Nlen])+1,\
      coords=[np.arange(-Nlag,Nlag+Nlen)],dims=["lag"])
  UManDpMCn = UManDpMCn.where(np.fabs(UManDpO) > \
                               np.fabs(UManDp), 0)

  if iMC==0:
    UManDpMC=UManDpMCn*1
  else:
    UManDpMC=UManDpMC+UManDpMCn

dsUManDpMC=UManDpMC.to_dataset(name='uMMC')
dsUManDpMC=dsUManDpMC.assign(NMC=NMC)

fileMC = PathAW+'MC/run/Roll.uM.Script'+\
    str(SNB)+'.MCrun'+str(NbR)+'.'+rMeth+'.nc'
os.system('rm -f '+fileMC)
dsUManDpMC.to_netcdf(fileMC)

print(" ")
print("##################")
Ttime=TimeRun.time()-btime
print("Running time "+str(np.floor(Ttime/60))+" min and "+str(np.floor(Ttime % 60))+" sec")
print("##################")
print(" ")

print(".. Done uM Ext")

