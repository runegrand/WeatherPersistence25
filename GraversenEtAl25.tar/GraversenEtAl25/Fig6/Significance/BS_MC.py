# -*- coding: utf-8 -*-
#
# sys.argv[1]: SNB Script number
# Make change of years in ArcticExtremes.nc 
# For:
# WeathVar_PersAnomExtRoll_MC2.py
# #####

import xarray as xr
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cftime
import sys
import numpy as np
np.round_ = np.round
import time as TimeRun
import xrft
import os
import pandas as pd

#########################
# Setting tool script dir
# directory to tools script (tools.py and tools_plot.py)
toolPath=<tools_script_dir>
#toolPath='/cluster/home/runegg/python/WeathPers25/'
try:
    sys.path.index(toolPath)
except ValueError:
    sys.path.append(toolPath)
from tools import Change_yr

btime=TimeRun.time()

#SNB=1 
SNB= int(sys.argv[1])

PathW=
PathAW=
#PathW='/cluster/projects/nn9348k/Rune/WeathPers25/work/SATvar/'
#PathAW='/cluster/projects/nn9348k/Rune/WeathPers25/work/ExtrArc/'

Evar = "Z" # "SAT", "T" or "Z"                                                                 
dates=xr.open_dataset(PathAW+'ArcticExtremes.nc')

datp=dates["Zp"]
datn=dates["Zn"]
Ndate=datp.size

datpc=Change_yr(datp,1980,2022)
datnc=Change_yr(datn,1980,2022)
    
da_datpc = xr.DataArray(
    datpc,
    dims=["time"],
    coords={"time": np.arange(1,Ndate+1)}, 
    name="datpc"
)
da_datnc = xr.DataArray(
    datnc,
    dims=["time"],
    coords={"time": np.arange(1,Ndate+1)},
    name="datnc"
)

dsDateCH=xr.merge([da_datpc,da_datnc])

pathExt_save=PathAW+'MC/run/ArcticExtremesCH.Script'+str(SNB)+'.nc'
os.system('rm -f '+pathExt_save)
dsDateCH.to_netcdf(pathExt_save)

print(" ")
print("##################")
Ttime=TimeRun.time()-btime
print("Runing time "+str(np.floor(Ttime/60))+" min and "+str(np.floor(Ttime % 60))+" sec")
print("##################")
print(" ")
