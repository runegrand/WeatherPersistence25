#!/bin/bash
# Weath_uMExt_MC.sh
#
# Calculate statistical significance of uM
# computed by ExtRolling_Fig6.py. A bootstrapping approach
# randomly interchanging years is applied. 
#
# Calculate temperature persistence over a 90 day period
# Uses:
# -- Weath_uMExt_MC.py: provides the calculations
# -- Weath_Persitencecollect.py: combines calculations into a single file
#
# Rune Grand Graversen: rune.graversen@uit.no
################################################### 

#SBATCH --account=nn9348k
#SBATCH --job-name=uM_MC
#SBATCH --nodes=1
#SBATCH --time=36:05:00

# The following must be set:
source /cluster/home/runegg/python/WeathPers25/.Pyth_login
cd /cluster/home/runegg/python/WeathPers25/PersAnom/Rolling

Nlag=90
Nlen=90
NMC=500  #70
NbR=6
SNB=2  # Script number
Meth='FFT'  # 'BS or 'FFT', random method

Pro="python3 Weath_uMExt_MC.py"
Pro_collect="python3 Weath_uMExt_MCcollect.py"

# The set of parallel runs:
for i in $(seq 1 1 $((NbR))); do
    srun --ntasks=1 --exact $Pro $Nlag $Nlen $NMC $SNB $i $Meth &
    echo srun --ntasks=1 --exact $Pro $Nlag $Nlen $NMC $SNB $i $Meth
done
wait
$Pro_collect $SNB $NbR $Meth 
wait

echo " ... Weath_uMExt_MC.py done"

exit 0
