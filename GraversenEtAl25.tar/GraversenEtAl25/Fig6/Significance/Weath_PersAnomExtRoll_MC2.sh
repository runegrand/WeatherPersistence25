#!/bin/bash
# Weath_PersAnomExtRoll_MC2.sh
#
# Calculate statistical significance of temperature persistence
# computed by Weath_PersAnomExtRoll.sh. A bootstrapping approach
# randomly interchanging years is applied. 
#
# Calculate temperature persistence over a 90 day period
# Uses:
# -- BS_MC.py: randomly shuffel years
# -- Weath_PersAnomExtRoll_MC2.py: provides calculations for each lag day
# -- Weath_PersAnomExtRoll_MCcollect2.py: combines all lag days
#                                         into a single file
#
# Rune Grand Graversen: rune.graversen@uit.no
################################################### 

#SBATCH --account=nn9348k
#SBATCH --job-name=Weath_MC
#SBATCH --nodes=1
#SBATCH --time=36:05:00
#SBATCH --ntasks=20
#SBATCH --mem-per-cpu=8G

# The following must be set:
source /cluster/home/runegg/python/WeathPers25/.Pyth_login
cd /cluster/home/runegg/python/WeathPers25/PersAnom/Rolling


NMC=50 #60 #50  #70
NbR=32
SNB=$1  # Script number

Nlag=130
Nlen=90
Meth='BS'  # 'BS or 'FFT', random method

Pro_fft="python3 fft_MC.py"
Pro_bs="python3 BS_MC.py"
Pro="python3 Weath_PersAnomExtRoll_MC2.py"
Pro_collect="python3 Weath_PersAnomExtRoll_MCcollect2.py"

for iMC in $(seq 1 1 $NMC); do

if [ $Meth == 'FFT' ]; then    
  $Pro_fft $SNB
fi
if [ $Meth == 'BS' ]; then   	
  $Pro_bs $SNB
fi
  
# The set of parallel runs:
for i in $(seq -$Nlag 1 $Nlag); do
    srun --ntasks=1 --exact $Pro $i $Nlag $Nlen $iMC $SNB $Meth &
    echo srun --ntasks=1 --exact $Pro $i $Nlag $Nlen $iMC $SNB $Meth
    if [ $(($i % $NbR)) == 0 ]; then
       wait
    fi
done

wait

done

wait
$Pro_collect $Nlag $Nlen $NMC $SNB $Meth
wait

echo " ... Weath_PersAnomExtRoll_MC.py done"

exit 0
