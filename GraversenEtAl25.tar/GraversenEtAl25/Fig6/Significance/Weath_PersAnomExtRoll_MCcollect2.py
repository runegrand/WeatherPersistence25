# -*- coding: utf-8 -*-
#
# WeathVar_PersAnomExt_MCcollect.py
#
# sys.argv[1]: Nlag, lag days go from [-Nlag;Nalg]
# sys.argv[2]: Nlen, max anomaly length AND period over
#              which to calculate anomaly length
# sys.argv[3]: NMC,
# sys.argv[4]: SNB, Script number
# sys.argv[5]: rMeth Random method: 'BS' or 'FFT'
# Input data produced by "WeathVar.2.py"
####################

import xarray as xr
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cftime
import sys
import numpy as np
np.round_ = np.round
import xrft
import os

#Nlag = 130
#Nlen = 90
#NMC = 2
#SNB=2
#rMeth='BS'
Nlag  = int(sys.argv[1])
Nlen = int(sys.argv[2])
NMC=int(sys.argv[3])
SNB=int(sys.argv[4])
rMeth= sys.argv[5]

PathAW=
PathW=
#PathW='/cluster/projects/nn9348k/Rune/WeathPers25/work/SATvar/'
#PathAW='/cluster/projects/nn9348k/Rune/WeathPers25/work/ExtrArc/'

fileMC_tot = PathAW+'MC/PersAnomExtRoll.'+rMeth+'.nc'
fileMCb_tot = PathAW+'MC/back/PersAnomExtRoll.'+rMeth+'.nc' 

for dlag in np.arange(-Nlag,Nlag+1):
  fileMC = PathAW+'MC/run/Roll.Nlen'+str(Nlen)+'.dlag'+str(dlag)+'.'+rMeth+\
    '.Script'+str(SNB)+'.nc'
  ANpMCx=xr.open_dataset(fileMC)['AnomMC']
  NMCcheck=int(xr.open_dataset(fileMC)['NMCcheck'])  
  if (not NMC==NMCcheck):
    print("NMC not equal to NMCcheck")
    print("NMC: "+str(NMC)+", NMCcheck: "+str(NMCcheck)+", SNB: "+str(SNB))
    print("Collection stoped !!")
    sys.exit()
  if (dlag==-Nlag):
    ANpMC=ANpMCx
  else:
    ANpMC=ANpMC+ANpMCx
  os.system("rm -f "+fileMC)

if os.path.isfile(fileMC_tot):
  dsANpMC_tot=xr.open_dataset(fileMC_tot)
  ANpMC_tot=dsANpMC_tot['AnomMC']
  NMC_tot=dsANpMC_tot['NMC']
  ANpMC_tot=ANpMC_tot+ANpMC
  NMC_tot=NMC_tot+NMC
  del dsANpMC_tot
  os.system("mv -f "+fileMC_tot+" "+fileMCb_tot)
else:
  ANpMC_tot=ANpMC
  NMC_tot=NMC

dsANpMC_tot=ANpMC_tot.to_dataset(name='AnomMC')
dsANpMC_tot=dsANpMC_tot.assign(NMC=NMC_tot)
dsANpMC_tot.to_netcdf(fileMC_tot)

if (rMeth=='FFT'):
  LatEnd=44
  LatStart=70
  LatStep=2
  LatLoop = np.arange(LatStart,LatEnd,-LatStep)

  lat=xr.open_dataset(PathW+'/SATrm.1979.nc').lat
  dlat=np.abs(lat[0].data-lat[1].data)
  for Lati in LatLoop:
    latb=Lati
    late=Lati-LatStep+dlat

    pathSAT_save=PathAW+'MC/run/SATan'+'_Lat'+str(late)+'to'+str(latb)+\
      '.Script'+str(SNB)+'.ft.nc'
    os.system("rm -f "+pathSAT_save)
elif (rMeth=='BS'):
  pathExt_save=PathAW+'MC/run/ArcticExtremesCH.Script'+str(SNB)+'.nc'
  os.system('rm -f '+pathExt_save)
    
print(" .. end collect Roll")
