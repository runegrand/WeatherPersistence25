# -*- coding: utf-8 -*-
#
# WeathVar_uMExt_MCcollect.py
#
# sys.argv[1]: SNB, Script number
# sys.argv[2]: NbR, Number of Run 
# sys.argv[3]: rMeth, Random method: 'BS' or 'FFT'
# Period starts YEAR and ends YEAR+Nyears
####################

import xarray as xr
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cftime
import sys
import numpy as np
np.round_ = np.round
import xrft
import os

#NbR=1
#SNB=1
#rMeth='BS'
SNB=int(sys.argv[1])
NbR=int(sys.argv[2])
rMeth=sys.argv[3]
PathAW=
PathAW='/cluster/projects/nn9348k/Rune/WeathPers25/work/ExtrArc/'

fileMC_tot = PathAW+'MC/uMExtRoll.'+rMeth+'.nc'
fileMCb_tot = PathAW+'MC/back/uMExtRoll.'+rMeth+'.nc' 

if os.path.isfile(fileMC_tot):
  uMMC_tot=xr.open_dataset(fileMC_tot)
  for irun in np.arange(1,NbR+1):
    fileMC = PathAW+'MC/run/Roll.uM.Script'+\
       str(SNB)+'.MCrun'+str(irun)+'.'+rMeth+'.nc'
    uMMC=xr.open_dataset(fileMC)
    uMMC_tot=uMMC_tot+uMMC
    os.system("rm -vf "+fileMC)
else:
  fileMC = PathAW+'MC/run/Roll.uM.Script'+\
       str(SNB)+'.MCrun1.'+rMeth+'.nc'
  uMMC=xr.open_dataset(fileMC)
  uMMC_tot=uMMC*1.
  os.system("rm -vf "+fileMC)
  for irun in np.arange(2,NbR+1):
    fileMC = PathAW+'MC/run/Roll.uM.Script'+\
       str(SNB)+'.MCrun'+str(irun)+'.'+rMeth+'.nc'
    uMMC=xr.open_dataset(fileMC)
    uMMC_tot=uMMC_tot+uMMC
    os.system("rm -vf "+fileMC)

if os.path.isfile(fileMC_tot):
  os.system("mv -f "+fileMC_tot+" "+fileMCb_tot)

uMMC_tot.to_netcdf(fileMC_tot)

print(" .. end collect")
