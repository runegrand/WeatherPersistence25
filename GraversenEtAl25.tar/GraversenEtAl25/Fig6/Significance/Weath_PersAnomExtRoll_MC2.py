# -*- coding: utf-8 -*-
#
# WeathVar_PersAnomExtRoll_MC2.py
#     as ..MC.py but without lag loop.
#
# sys.argv[1]: dlag, lag days go from [-Nlag;Nlag]
# sys.argv[2]: Nlag
# sys.argv[3]: Nlen, max anomaly length AND period over
#              which to calculate anomaly length
# sys.argv[4]: iMC, MC number
# sys.argv[5]: SNB Script number
# sys.argv[6]: Random method: 'BS' or 'FFT'
# Periods (warm and cold Arctic) are produced by
#          WarmArctic.py at Nird
# Input data produced by "WeathVar.py"
#          and WarmArctic.py
####################

import xarray as xr
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cftime
import sys
import numpy as np
np.round_ = np.round
import time as TimeRun
import xrft
import os

#########################
# Setting tool script dir
# directory to tools script (tools.py and tools_plot.py)
toolPath=<tools_script_dir>
#toolPath='/cluster/home/runegg/python/WeathPers25/'
try:
    sys.path.index(toolPath) 
except ValueError:
    sys.path.append(toolPath)
from tools import PersAnom, filter_run_mean_time_lat_lon, xfft_TLL

btime=TimeRun.time()

#dlag  = -130
#Nlag = 130
#Nlen = 90 
#iMC=1 
#SNB=1
#rMeth='FFT'
dlag  = int(sys.argv[1])
Nlag = int(sys.argv[2])
Nlen = int(sys.argv[3])
iMC= int(sys.argv[4])
SNB= int(sys.argv[5])
rMeth= sys.argv[6]

PlotAn='B' # P: Positive, N: Negative, B: Both

PathW=
PathE=
PathAW=
#PathW='/cluster/projects/nn9348k/Rune/WeathPers25/work/SATvar/'
#PathE='/cluster/projects/nn9348k/Rune/WeathPers25/work/work/Rolling/'
#PathAW='/cluster/projects/nn9348k/Rune/WeathPers25/work/ExtrArc/'

Evar = "Z" # "SAT", "T" or "Z"

LatEnd=44
LatStart=70
LatStep=2
LatLoop = np.arange(LatStart,LatEnd,-LatStep)

lat=xr.open_dataset(PathW+'/SATrm.1979.nc').lat
dlat=np.abs(lat[0].data-lat[1].data)

lenb=[1,3,1,5,1,11]
lene=[2,Nlen,4,Nlen,10,Nlen]

#rMeth='FFT'  # Test of AN
if (rMeth=='FFT'):
  #Nlenb=np.size(lenb)
  dates=xr.open_dataset(PathAW+'ArcticExtremes.nc')
  datp=dates["Zp"]
  datn=dates["Zn"]
elif (rMeth=='BS'):
  pathExt_save=PathAW+'MC/run/ArcticExtremesCH.Script'+str(SNB)+'.nc'
  dsDateCH=xr.open_dataset(pathExt_save)
  datp=dsDateCH['datpc'].rename('Zp')
  datn=dsDateCH['datnc'].rename('Zn')
else:
  print("rMeth must på 'BS', 'FFT'")
  sys.exit()
Ndate=datp.size

ilag=Nlag+dlag
fileVar=PathAW+'FigData/ANArcticRolling.'+Evar+'.Nlen'+str(Nlen)+'.Nlag'+\
    str(Nlag)+'.nc'
ANpO=xr.open_dataset(fileVar)['Anom'][ilag]

anB=0.0
first=True
for Lati in LatLoop:
#  print("Calculating for latitude: "+str(Lati))
  latb=Lati
  late=Lati-LatStep+dlat

#  rMeth='BS'  # Test of AN
  if (rMeth=='FFT'):
    pathSAT_save=PathAW+'MC/run/SATan'+'_Lat'+str(late)+'to'+str(latb)+\
         '.Script'+str(SNB)+'.ft.nc'
    SATanr=xr.open_dataset(pathSAT_save)['SAT'].compute()
  elif (rMeth=='BS'):
    pathSAT=PathW+'SATan'+'_Lat'+str(late)+'to'+str(latb)+'.nc'
    SATan=xr.open_dataset(pathSAT)['urm'].compute()
    NtimeSAT=np.size(SATan.time)
    SATanr=SATan[182:NtimeSAT-183,:,:]
  
  lat=SATanr.lat
  lon=SATanr.lon
  Nlat=np.size(lat)
  Nlon=np.size(lon)
  LendL = xr.DataArray(np.zeros([Nlen,Nlat,Nlon]),\
        coords=[np.arange(1,Nlen+1),lat,lon],\
        dims=["len","lat","lon"])

  time=SATanr.time  
  firstp=0
  firstn=0
  for idate in np.arange(0,Ndate):
    dp=datp[idate]
    dn=datn[idate]
    if not (np.isnat(dp)):
      if (dp.dt.year > 1979) & (dp.dt.year < 2023):      
        iExt=np.where(time==dp)[0][0]
        SATanYx=SATanr[iExt+dlag:iExt+Nlen+dlag,:,:]
        SATanY=SATanYx-SATanYx.mean(dim="time")
        dsLenLp = PersAnom(SATanY,Nlen,anB)
        dsLenLn = PersAnom(-1.*SATanY,Nlen,anB)
        if (firstp == 0):
          dsLenL=dsLenLp+dsLenLn
        else:
          dsLenL=dsLenL+(dsLenLp+dsLenLn)
        firstp=firstp+1
    if not (np.isnat(dn)):
      if (dn.dt.year > 1979) & (dn.dt.year < 2023):
        iExt=np.where(time==dn)[0][0]
        SATanYx=SATanr[iExt+dlag:iExt+Nlen+dlag,:,:]
        SATanY=SATanYx-SATanYx.mean(dim="time")
        dsLenEp = PersAnom(SATanY,Nlen,anB)
        dsLenEn = PersAnom(-1.*SATanY,Nlen,anB)
        if (firstn == 0):
          dsLenE=dsLenEp+dsLenEn
        else:
          dsLenE=dsLenE+(dsLenEp+dsLenEn)
        firstn=firstn+1
  dsLenL=dsLenL/firstp
  dsLenE=dsLenE/firstn
  PersDiffL = dsLenL-dsLenE
  
  for ilen in np.arange(0,Nlen):
    LendL[ilen,:,:] = PersDiffL[ilen,:,:]*(ilen+1)

  del SATanr

  if (first):
    Lend=LendL*1.
  else:
    Lend=xr.concat([Lend,LendL],dim="lat")    

  first=False

latAN=Lend['lat']
lonAN=Lend['lon']
lenAN=Lend['len']
NlatAN=np.size(latAN)
NlonAN=np.size(lonAN)
NlenAN=np.size(lenAN)
latANb=45
latANe=70
lonANb=-180
lonANe=179.5
lenANsplit=3
coslat=np.cos(np.deg2rad(latAN))

ANp=Lend.rename('Anom').\
      sel(lon=((lonAN>=lonANb) & (lonAN<=lonANe))).\
      sel(lat=((latAN>=latANb) & (latAN<=latANe))).\
      weighted(coslat).mean(('lat','lon')).\
      sel(len=(lenAN>=lenANsplit)).sum(dim='len')
del Lend

# For test of AN, produce An without random shuff
#fileVarS=PathAW+'MC/run/ANArcticRolling.'+\
#       '.Nlen'+str(Nlen)+'.dlag'+str(dlag)+'MC.nc'
#os.system('rm -vf '+fileVarS)
#ANp.to_netcdf(fileVarS)
#sys.exit('YES!!'+str(Nlag))

# Compare random to original
ANpMCn=xr.DataArray(np.zeros([2*Nlag+1]),\
      coords=[np.arange(-Nlag,Nlag+1)],dims=["lag"])
ANpMCn[ilag]=1
ANpMCn[ilag] = ANpMCn[ilag].where(np.fabs(ANpO) > \
                                  np.fabs(ANp), 0)
print(rMeth+': '+str(ANp.data)+' Orig: '+str(ANpO.data))

dsANpMCn=ANpMCn.to_dataset(name='AnomMC')
NMCcheck=1
dsANpMCn=dsANpMCn.assign(NMCcheck=NMCcheck)
fileMC = PathAW+'MC/run/Roll.Nlen'+str(Nlen)+'.dlag'+str(dlag)+'.'+rMeth+\
    '.Script'+str(SNB)+'.nc'
if (iMC==1):
  dsANpMC=dsANpMCn*1.
else:
  dsANpMC=xr.open_dataset(fileMC)
  dsANpMC=dsANpMC+dsANpMCn

os.system('rm -f '+fileMC)
dsANpMC.to_netcdf(fileMC)

print(" ")
print("##################")
Ttime=TimeRun.time()-btime
print("Running time "+str(np.floor(Ttime/60))+" min and "+str(np.floor(Ttime % 60))+" sec")
print("##################")
print(" ")

print(".. Done ANp Ext dlag: "+str(dlag))



