#!/bin/bash
# Weath_PersAnomExtRoll.sh
#
# Calculate temperature persistence over a 90 day period
# shifted with $i days within the interval [-Nlag;Nlag]
# where zero lag is the first day of 3-month cold and warm Arctic events.
# The composite difference between warm and cold events is taken.
#
# Uses:
# -- Weath_PersAnomExtRoll.py: provides calculations for each lag day
# -- Weath_Persitencecollect.py: combines all lag days into a single file
#
# Rune Grand Graversen: rune.graversen@uit.no
##################################

#SBATCH --account=nn9348k
#SBATCH --job-name=Weath
#SBATCH --nodes=1
#SBATCH --time=36:05:00
#SBATCH --ntasks=20
#SBATCH --mem-per-cpu=8G

Nlag=130
Nlen=90

Pro="python3 Weath_PersAnomExtRoll.py"
Pro_collect="python3 Weath_PersAnomExtRollcollect.py"

# The following must be set:
source /cluster/home/runegg/python/WeathPers25/.Pyth_login
cd /cluster/home/runegg/python/WeathPers25/PersAnom/Rolling

# The set of parallel runs:
for i in $(seq -$Nlag 1 $Nlag); do
    srun --ntasks=1 --exact $Pro $i $Nlen &
    echo srun --ntasks=1 --exact $Pro $Nlen $i
    if [ $(($i % 20)) == 0 ]; then
       wait
    fi
done

wait
$Pro_collect $Nlag $Nlen
wait

echo " ... WeathVar_PersAnomExtRoll.py done"

exit 0
