# -*- coding: utf-8 -*-
#
# WeathVar_PersAnomExt_MCcollect.py
#
# sys.argv[1] Number of Run
# sys.argv[2]: Nlen, max anomaly length AND period over
#              which to calculate anomaly length
# Period starts YEAR and ends YEAR+Nyears
####################

import xarray as xr
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cftime
import sys
import numpy as np
np.round_ = np.round
import xrft
import os

Nlag = int(sys.argv[1])
Nlen = int(sys.argv[2])

#PathE=
#PathW=
PathE='/cluster/projects/nn9348k/Rune/WeathPers25/work/ExtrArc/'
PathW='/cluster/projects/nn9348k/Rune/WeathPers25/work/work/Rolling/'

pathExt=[]
pathExtp=[]
pathExtn=[]
pathExtA=[]
for ilag in np.arange(-Nlag,Nlag+1):
  pathExt.append(PathW+'SATPersAnomExt.Z.Roll'+str(ilag)+'.nc')
  pathExtp.append(PathW+'SATPersAnomExtp.Z.Roll'+str(ilag)+'.nc')
  pathExtn.append(PathW+'SATPersAnomExtn.Z.Roll'+str(ilag)+'.nc')
  pathExtA.append(PathW+'SATPersAnomExtAll.Z.Roll'+str(ilag)+'.nc')

dsPersDiff=xr.open_mfdataset(pathExt,concat_dim='lag',combine='nested').\
  compute()
dsPersDiffp=xr.open_mfdataset(pathExtp,concat_dim='lag',combine='nested').\
  compute()
dsPersDiffn=xr.open_mfdataset(pathExtn,concat_dim='lag',combine='nested').\
  compute()
dsPersDiffA=xr.open_mfdataset(pathExtA,concat_dim='lag',combine='nested').\
  compute()

fileExt_tot=PathE+'FigData/SATPersAnomExt.Z.RollN'+str(Nlag)+'.Len'+\
    str(Nlen)+'.nc'
fileExtp_tot=PathE+'FigData/SATPersAnomExtp.Z.RollN'+str(Nlag)+'.Len'+\
    str(Nlen)+'.nc'
fileExtn_tot=PathE+'FigData/SATPersAnomExtn.Z.RollN'+str(Nlag)+'.Len'+\
    str(Nlen)+'.nc'
fileExtA_tot=PathE+'FigData/SATPersAnomExtAll.Z.RollN'+str(Nlag)+'.Len'+\
    str(Nlen)+'.nc'

if os.path.isfile(fileExt_tot):
  os.system("rm -f "+fileExt_tot)
if os.path.isfile(fileExtp_tot):
  os.system("rm -f "+fileExtp_tot)
if os.path.isfile(fileExtn_tot):
  os.system("rm -f "+fileExtn_tot)
if os.path.isfile(fileExtA_tot):
  os.system("rm -f "+fileExtA_tot)

dsPersDiff.to_netcdf(fileExt_tot)
dsPersDiffp.to_netcdf(fileExtp_tot)
dsPersDiffn.to_netcdf(fileExtn_tot)
dsPersDiffA.to_netcdf(fileExtA_tot)

for ilag in np.arange(-Nlag,Nlag+1):
  os.system("rm -f "+pathExt[ilag])
  os.system("rm -f "+pathExtp[ilag])
  os.system("rm -f "+pathExtn[ilag])
  os.system("rm -f "+pathExtA[ilag])

print(" .. end collect")
