# -*- coding: utf-8 -*-
# ExtRolling.py
#
# Rolling patterns over the compsite differnece of
# warm and cold periods with zero lag at the frst day
# of the period.
# Plot Fig6.
# Periods (warm and cold Arctic) are produced by
#          WarmArctic.py
# Input data produced by "WeathVar.py"
#          and Weath_PersAnomExtRoll.py
#
# Rune Grand Graversen: rune.graversen@uit.no
####################

import xarray as xr
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cftime
import sys
import numpy as np
np.round_ = np.round
import time as TimeRun
import xrft
import os

#########################
# Setting tool script dir
# directory to tools script (tools.py and tools_plot.py)
toolPath=<tools_script_dir>
#toolPath='/cluster/home/runegg/python/WeathPers25/'
try:
    sys.path.index(toolPath)
except ValueError:
    sys.path.append(toolPath)
from tools import PersAnom, filter_run_mean_time_lat_lon
from tools_plot import Plot2, Plot4

btime=TimeRun.time()

MakeVar=False
ETlat=60
useAN='l'  #l: left, m: middle, r: right
lenRM=10    # Running mean for uM, Z500, SAT, and ET

# Set pathes:
PathW=
PathET=
PathUM=
PathZ=
pathAN=
PathE=
PathFig=
#PathW='/cluster/projects/nn9348k/Rune/WeathPers25/work/SATvar/'
#PathUM='/cluster/projects/nn9348k/Rune/WeathPers25/work/uM/'
#PathZ='/cluster/projects/nn9348k/Rune/WeathPers25/work/Z/'
#pathAN='/cluster/projects/nn9348k/Rune/WeathPers25/work/ExtrArc/FigData/'
#PathE='/cluster/projects/nn9348k/Rune/WeathPers25/work/ExtrArc/'
#PathFig='/cluster/projects/nn9348k/Rune/WeathPers25/Fig/'

Evar = "Z" # "SAT", "T" or "Z"

PI=3.1415
dtor = 2*PI/360.
R=3671.e3

lat=xr.open_dataset(PathW+'/SATrm.1979.nc').lat
dlat=np.abs(lat[0].data-lat[1].data)

Nlen=95
MakeLS='S' # DO NOT CHANGE L: 'Long, S: Short

if MakeLS=='S':
  lenb=[1,3,1,5,1,11]
  lene=[2,Nlen,4,Nlen,10,Nlen]
elif MakeLS=='L':
  lenb=[1,5,8,15,31,95]
  lene=[4,7,14,30,94,Nlen]
else:
  sys.exit("MakeLS should by 'L' or 'S'!!")

Nlenb=np.size(lenb)
dates=xr.open_dataset(PathE+'ArcticExtremes.nc')

datp=dates["Zp"]
datn=dates["Zn"]
Ndate=datp.size

Nlag=90 #90  # ilag=[-Nlag,Nlag]

print("Calculating for Z")
fileVar=PathE+'FigData/ZArcticRolling.'+Evar+'.nc'                                           
LatEnd=20
LatBeg=90
LatStep=10
LatLoop = np.arange(LatBeg,LatEnd,-LatStep)
if MakeVar:
  first=True
  for Lati in LatLoop:
    print("Calculating for latitude: "+str(Lati))
    latb=Lati
    late=Lati-LatStep+dlat
    if ((late-dlat)==LatEnd):
      late=LatEnd
      
    pathSAT=PathZ+'Zan'+'_Lat'+str(late)+'to'+str(latb)+'.nc'

    SATan=xr.open_dataset(pathSAT)['Z500'].compute()
    time=SATan.time
    firstp=0
    firstn=0
    for idate in np.arange(0,Ndate):
      dp=datp[idate]
      dn=datn[idate]
      if not (np.isnat(dp)):
        if (dp.dt.year > 1979) & (dp.dt.year < 2023):
          iExt=np.where(time==dp)[0][0]
          SATanWx=SATan[iExt-Nlag:iExt+90+Nlag,:,:]
          SATanWx=SATanWx.rename({'time': 'lag'})
          SATanWx['lag']=np.arange(-Nlag,Nlag+90)
          if (firstp == 0):
            SATanW=SATanWx*1.
          else:
            SATanW=SATanW+SATanWx
          firstp=firstp+1
      if not (np.isnat(dn)):
        if (dn.dt.year > 1979) & (dn.dt.year < 2023):
          iExt=np.where(time==dn)[0][0]
          SATanCx=SATan[iExt-Nlag:iExt+90+Nlag,:,:]
          SATanCx=SATanCx.rename({'time': 'lag'})
          SATanCx['lag']=np.arange(-Nlag,Nlag+90)
          if (firstn == 0):
            SATanC=SATanCx*1.
          else:
            SATanC=SATanC+SATanCx
          firstn=firstn+1

    SATanDL=SATanW/firstp - SATanC/firstn

    del SATan

    if (first):
      ZanD=SATanDL*1.
    else:
      ZanD=xr.concat([ZanD,SATanDL],dim="lat")

    first=False

  ZanD=ZanD.rename('Z')
  os.system("rm -f "+fileVar)
  ZanD.to_netcdf(fileVar)
else:
  ZanD=xr.open_dataset(fileVar)['Z']

#######################################                                  
print("Calculating for uM")
fileVar=PathE+'FigData/uMArcticRolling.'+Evar+'.nc'
LatEnd=40
LatBeg=80
LatStep=10
LatLoop = np.arange(LatBeg,LatEnd,-LatStep)
if MakeVar:
  first=True
  for Lati in LatLoop:
    print("Calculating for latitude: "+str(Lati))
    latb=Lati
    late=Lati-LatStep+dlat
#    if ((late-dlat)==LatEnd):
#      late=LatEnd

    pathSAT=PathUM+'uMan'+'_Lat'+str(late)+'to'+str(latb)+'.nc'

    SATan=xr.open_dataset(pathSAT)['uM'].compute()
    time=SATan.time
    firstp=0
    firstn=0
    for idate in np.arange(0,Ndate):
      dp=datp[idate]
      dn=datn[idate]
      if not (np.isnat(dp)):
        if (dp.dt.year > 1979) & (dp.dt.year < 2023):
          iExt=np.where(time==dp)[0][0]
          SATanWx=SATan[iExt-Nlag:iExt+90+Nlag,:,:]
          SATanWx=SATanWx.rename({'time': 'lag'})
          SATanWx['lag']=np.arange(-Nlag,Nlag+90)
          if (firstp == 0):
            SATanW=SATanWx*1.
          else:
            SATanW=SATanW+SATanWx
          firstp=firstp+1
      if not (np.isnat(dn)):
        if (dn.dt.year > 1979) & (dn.dt.year < 2023):
          iExt=np.where(time==dn)[0][0]
          SATanCx=SATan[iExt-Nlag:iExt+90+Nlag,:,:]
          SATanCx=SATanCx.rename({'time': 'lag'})
          SATanCx['lag']=np.arange(-Nlag,Nlag+90)
          if (firstn == 0):
            SATanC=SATanCx*1.
          else:
            SATanC=SATanC+SATanCx
          firstn=firstn+1

    SATanDL=SATanW/firstp - SATanC/firstn

    del SATan

    if (first):
      uManD=SATanDL*1.
    else:
      uManD=xr.concat([uManD,SATanDL],dim="lat")

    first=False

  uManD=uManD.rename('uM')
  os.system("rm -f "+fileVar)
  uManD.to_netcdf(fileVar)
else:
  uManD=xr.open_dataset(fileVar)['uM']
###################################

Atl=False
Nlen=90
NlagAN=130
fileAN=pathAN+'SATPersAnomExtAll.Z.RollN'+str(NlagAN)+\
    '.Len'+str(Nlen)+'.nc'
dsAN=xr.open_dataset(fileAN)

# MC
rMeth='BS'
fileANMC=PathE+'MC/PersAnomExtRoll.'+rMeth+'.nc'
dsANpMC=xr.open_dataset(fileANMC)
ANpMC=dsANpMC['AnomMC']/dsANpMC['NMC']

fileUMMC = PathE+'MC/uMExtRoll.'+rMeth+'.nc'
dsUManDpMC=xr.open_dataset(fileUMMC)
UManDpMC=dsUManDpMC['uMMC']/dsUManDpMC['NMC']

latAN=dsAN['lat']
lonAN=dsAN['lon']
lenAN=dsAN['len']
NlatAN=np.size(latAN)
NlonAN=np.size(lonAN)
NlenAN=np.size(lenAN)
latANb=45#45
latANe=70#75
lonANb=-180 #-90
lonANe=179.5  #20 #130

lonb=-180 #-90  #-180 #-90
lone=179.5  #20 #179.5 #20
latb=ETlat

latZ=ZanD['lat']
lonZ=ZanD['lon']
latuM=uManD['lat']
lonuM=uManD['lon']

coslat=np.cos(np.deg2rad(latZ))

lenANsplit=3 
ANp=dsAN['Anom'].\
      sel(lon=((lonAN>=lonANb) & (lonAN<=lonANe))).\
      sel(lat=((latAN>=latANb) & (latAN<=latANe))).\
      weighted(coslat).mean(('lat','lon')).\
      sel(len=(lenAN>=lenANsplit)).sum(dim='len')
fileVar=PathE+'FigData/ANArcticRolling.'+Evar+'.Nlen'+str(Nlen)+'.Nlag'+\
    str(NlagAN)+'.nc'
os.system("rm -f "+fileVar)
ANp.to_netcdf(fileVar)

if (useAN=='m'):
  ANp['lag']=ANp['lag']+Nlen/2
  ANpMC['lag']=ANpMC['lag']+Nlen/2
elif (useAN=='l'):
  ANp['lag']=ANp['lag']+Nlen
  ANpMC['lag']=ANpMC['lag']+Nlen
ANp=ANp.sel(lag=((ANp['lag']<=180) & (ANp['lag']>=-30)))
ANpMC=ANpMC.sel(lag=((ANpMC['lag']<=180) & (ANpMC['lag']>=-30)))

ZanDp=(ZanD.\
    sel(lon=((lonZ>=lonb) & (lonZ<=lone))).\
    sel(lat=((latZ>=latb) & (latZ<=90))).\
    weighted(coslat).mean(("lat","lon"))-
    ZanD.\
    sel(lon=((lonZ>=lonb) & (lonZ<=lone))).\
    sel(lat=((latZ>=20) & (latZ<=latb))).\
    weighted(coslat).mean(("lat","lon"))).\
    rolling(lag=lenRM,center=True).mean()/1.E3

#Mass flux averaged over 45-70
UManDp=uManD.\
      sel(lon=((lonuM>=lonANb) & (lonuM<=lonANe))).\
      sel(lat=((latuM>=latANb) & (latuM<=latANe))).\
      weighted(coslat).mean(('lat','lon')).\
      rolling(lag=lenRM,center=True).mean()/1.E4
fileVar=PathE+'FigData/uMRolling.'+Evar+'.Nlag'+str(Nlag)+'.RM'+str(lenRM)+'.nc'
os.system("rm -f "+fileVar)
UManDp.to_netcdf(fileVar)

#######################################
# Plot:GPH gradient -- Zonal mass flux -- Anomales (Fig6)
fig, ax1 = plt.subplots(figsize=(9, 6))
colorp='blue'
ax1.set_xlabel('lag [days]',fontsize=14)
ax1.set_ylabel('Zonal mass flux [10$^4$ kg m$^{-1}$ s$^{-1}$]', \
               color=colorp,fontsize=16)
ax1.plot(UManDp.lag,UManDp,color=colorp,linewidth=3)
ax1.tick_params(axis='y', labelcolor=colorp, width=2, labelsize=14)
ax1.tick_params(axis='x', width=2, labelsize=12)
ax1.spines['top'].set_linewidth(2)  # Thicker frame
ax1.spines['right'].set_linewidth(2)
ax1.spines['left'].set_linewidth(2)
ax1.spines['bottom'].set_linewidth(2)
colorp='red'
ax2=ax1.twinx()
ax2.set_ylabel('Arctic-midlatitude 500 hPa GPH difference [10$^3$ m]',
               color=colorp,fontsize=16)
ax2.plot(ZanDp.lag,ZanDp,color=colorp,linewidth=3)
ax2.tick_params(axis='y', labelcolor=colorp, width=2, labelsize=14)
colorp='green'
ax3=ax1.twinx()
ax3.spines['right'].set_position(('outward', 80))
ax3.set_frame_on(True)
ax3.patch.set_visible(False)
ax3.yaxis.set_ticks_position('right')
ax3.yaxis.set_label_position('right')
ax3.set_ylabel('Persistence [days]',\
               color=colorp,fontsize=16)
ax3.plot(ANp.lag,ANp,color=colorp,linewidth=3)
ax3.tick_params(axis='y', labelcolor=colorp, width=2, labelsize=14)
ax3.spines['right'].set_linewidth(2)
ax1.set_xlim(-90, 180)
ax1.set_ylim(2.6, -2.6*1.6)
ax2.set_ylim(-0.7, 0.7*1.6)
ax3.set_ylim(-1.3, 1.3*1.6)
UManDpSig=UManDp.where(UManDpMC > 0.95, np.nan)
ax1.plot(UManDp.lag,UManDpSig,color='blue',linewidth=15,alpha=0.3)
ANpSig=ANp.where(ANpMC > 0.95, np.nan)
ax3.plot(ANp.lag,ANpSig,color='green',linewidth=15,alpha=0.3)

# Add a horizontal line at y=0 for each axis
ax1.axhline(0, color='black', linewidth=1.5, linestyle='--')
fig.tight_layout()
plt.title('Composite difference \n (warm minus cold periods)',
          fontsize=18)
FigForm='eps'
if Atl:
  Fignm='LagAnomExt.Atlantic.Len'+str(Nlen)+'.'+FigForm
else:
  Fignm='Fig6.'+FigForm
plt.savefig(PathFig+Fignm,bbox_inches='tight',
              pad_inches=0.02,format=FigForm)
plt.show()
plt.close()

# Write out Fig 6 data for Figshare, Nov 2025
dsF1=xr.DataArray(UManDp,coords={'lag': UManDp.lag}, dims=["lag"]).rename('uM')
dsF2=xr.DataArray(ZanDp,coords={'lag': ZanDp.lag}, dims=["lag"]).rename('Z500')
dsF3=xr.DataArray(ANp,coords={'lag': ANp.lag}, dims=["lag"]).rename('Pers')
dsF1S=xr.DataArray(UManDpMC,coords={'lag': UManDpMC.lag}, dims=["lag"]).rename('uM_Sig')
dsF3S=xr.DataArray(ANpMC,coords={'lag': ANpMC.lag}, dims=["lag"]).rename('Pers_Sig')
dsFig6=xr.merge([dsF1,dsF2,dsF3,dsF1S,dsF3S])
dsFig6.attrs["Units"]='Pers: days; uM: 10^4 kg m-1 s-1: Z500: 10^3 m; Pers/uM_Sig: %'
dsFig6.attrs["Description"]='Composites of warm minus cold 3-months Arctic events as a function of days (lag) of events; zero lag is the first day of the events. Pers/uM_Sig indicate confidence level of Pers and uM, respectively. Persistence is number of days within anomalies lasting at least three days, calculated over a 90 day period prior to the lag day. Z500 is the difference in geopotential height between the Arctic and the mid-latitudes.'
FilenmFigData=PathFig+'Fig6data.nc'
os.system("rm -vf "+FilenmFigData)
dsFig6.to_netcdf(FilenmFigData)

print(" ")
print("##################")
Ttime=TimeRun.time()-btime
print("Ruuning time "+str(np.floor(Ttime/60))+" min and "+str(np.floor(Ttime % 60))+" sec")
print("##################")
print(" ")
