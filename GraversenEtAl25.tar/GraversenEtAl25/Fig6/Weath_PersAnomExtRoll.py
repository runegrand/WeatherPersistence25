# -*- coding: utf-8 -*-
#
# WeathVar_PersAnomExtRoll.py
#
# sys.argv[1]: dlag, lag relative to first day of period
# sys.argv[2]: Nlen, max anomaly length AND period over
#              which to calculate anomaly length
#
# Periods (warm and cold Arctic) are produced by
#          WarmArctic.py at Nird
# Input data produced by "WeathVar.py"
#          and WarmArctic.py
####################

import xarray as xr
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cftime
import sys
import numpy as np
np.round_ = np.round
import time as TimeRun
import xrft
import os

#########################
# Setting tool script dir
# directory to tools script (tools.py and tools_plot.py)
#toolPath=<tools_script_dir>
toolPath='/cluster/home/runegg/python/WeathPers25/'
try:
    sys.path.index(toolPath) 
except ValueError:
    sys.path.append(toolPath)
from tools import PersAnom, filter_run_mean_time_lat_lon
from tools_plot import Plot2, Plot4

btime=TimeRun.time()

dlag  = int(sys.argv[1])
Nlen = int(sys.argv[2])
#dlag  = 0
#Nlen = 90

PlotAn='B' # P: Positive, N: Negative, B: Both

#PathW=
#PathE=
#PathAW=
PathW='/cluster/projects/nn9348k/Rune/WeathPers25/work/SATvar/'
PathE='/cluster/projects/nn9348k/Rune/WeathPers25/work/work/Rolling/'
PathAW='/cluster/projects/nn9348k/Rune/WeathPers25/work/ExtrArc/'

Evar = "Z" 

LatEnd=20
LatStep=10
LatStart=90
LatLoop = np.arange(LatStart,LatEnd,-LatStep)

lat=xr.open_dataset(PathW+'/SATrm.1979.nc').lat
dlat=np.abs(lat[0].data-lat[1].data)

#Nlen=90 #40  #95 ## 28 FEB 2025
lenb=[1,3,1,5,1,11]
lene=[2,Nlen,4,Nlen,10,Nlen]

Nlenb=np.size(lenb)
dates=xr.open_dataset(PathAW+'ArcticExtremes.nc')


datp=dates["Zp"]
datn=dates["Zn"]
Ndate=datp.size

fileVar=PathE+'SATPersAnomExt.'+Evar+'.Roll'+str(dlag)+'.nc'
fileVarp=PathE+'SATPersAnomExtp.'+Evar+'.Roll'+str(dlag)+'.nc'
fileVarn=PathE+'SATPersAnomExtn.'+Evar+'.Roll'+str(dlag)+'.nc'
fileVarA=PathE+'SATPersAnomExtAll.'+Evar+'.Roll'+str(dlag)+'.nc'

anB=0.0
first=True
for Lati in LatLoop:
  print("Calculating for latitude: "+str(Lati))
  latb=Lati
  late=Lati-LatStep+dlat
  if ((late-dlat)==LatEnd):
    late=LatEnd

  pathSAT=PathW+'SATan'+'_Lat'+str(late)+'to'+str(latb)+'.nc'

  SATan=xr.open_dataset(pathSAT)['urm'].compute()
  time=SATan.time  
  firstp=0
  firstn=0
  for idate in np.arange(0,Ndate):
    dp=datp[idate]
    dn=datn[idate]
    if not (np.isnat(dp)):
      if (dp.dt.year > 1979) & (dp.dt.year < 2023):
        iExt=np.where(time==dp)[0][0]
        SATanYx=SATan[iExt+dlag:iExt+Nlen+dlag,:,:]
        SATanY=SATanYx-SATanYx.mean(dim="time")
        dsLenLp = PersAnom(SATanY,Nlen,anB)
        dsLenLn = PersAnom(-1.*SATanY,Nlen,anB)
        if (firstp == 0):
          dsLenL=dsLenLp+dsLenLn
          dsLenLpp=dsLenLp*1.
          dsLenLnn=dsLenLn*1.
        else:
          dsLenL=dsLenL+(dsLenLp+dsLenLn)
          dsLenLpp=dsLenLpp+dsLenLp
          dsLenLnn=dsLenLnn+dsLenLn
        firstp=firstp+1
    if not (np.isnat(dn)):
      if (dn.dt.year > 1979) & (dn.dt.year < 2023):
        iExt=np.where(time==dn)[0][0]
        SATanYx=SATan[iExt+dlag:iExt+Nlen+dlag,:,:]
        SATanY=SATanYx-SATanYx.mean(dim="time")
        dsLenEp = PersAnom(SATanY,Nlen,anB)
        dsLenEn = PersAnom(-1.*SATanY,Nlen,anB)
        if (firstn == 0):
          dsLenE=dsLenEp+dsLenEn
          dsLenEpp=dsLenEp*1.
          dsLenEnn=dsLenEn*1.
        else:
          dsLenE=dsLenE+(dsLenEp+dsLenEn)
          dsLenEpp=dsLenEpp+dsLenEp
          dsLenEnn=dsLenEnn+dsLenEn
        firstn=firstn+1

  dsLenL=dsLenL/firstp
  dsLenE=dsLenE/firstn
  PersDiffL = dsLenL-dsLenE

  dsLenLpp=dsLenLpp/firstp
  dsLenEpp=dsLenEpp/firstn
  PersDiffLp = dsLenLpp-dsLenEpp
  dsLenLnn=dsLenLnn/firstp
  dsLenEnn=dsLenEnn/firstn
  PersDiffLn = dsLenLnn-dsLenEnn

  del SATan

  if (first):
    PersDiff=PersDiffL*1.
    PersDiffp=PersDiffLp*1.
    PersDiffn=PersDiffLn*1.
  else:
    PersDiff=xr.concat([PersDiff,PersDiffL],dim="lat")    
    PersDiffp=xr.concat([PersDiffp,PersDiffLp],dim="lat")    
    PersDiffn=xr.concat([PersDiffn,PersDiffLn],dim="lat")    

  first=False

lat=PersDiff.lat  
lon=PersDiff.lon
Nlat=np.size(lat)
Nlon=np.size(lon)
Lend = xr.DataArray(np.zeros([Nlen,Nlat,Nlon]), \
  coords=[np.arange(1,Nlen+1),lat,lon], dims=["len","lat","lon"])
Lenb = xr.DataArray(np.zeros([Nlenb,Nlat,Nlon]), \
  coords=[np.arange(1,Nlenb+1),lat,lon], dims=["time","lat","lon"])
Lendp = xr.DataArray(np.zeros([Nlen,Nlat,Nlon]), \
  coords=[np.arange(1,Nlen+1),lat,lon], dims=["len","lat","lon"])
Lenbp = xr.DataArray(np.zeros([Nlenb,Nlat,Nlon]), \
  coords=[np.arange(1,Nlenb+1),lat,lon], dims=["time","lat","lon"])
Lendn = xr.DataArray(np.zeros([Nlen,Nlat,Nlon]), \
  coords=[np.arange(1,Nlen+1),lat,lon], dims=["len","lat","lon"])
Lenbn = xr.DataArray(np.zeros([Nlenb,Nlat,Nlon]), \
  coords=[np.arange(1,Nlenb+1),lat,lon], dims=["time","lat","lon"])

# PersDiff is number of anomalies of given length.
# Here days within anomlies of given length:
for ilen in np.arange(0,Nlen):
  Lend[ilen,:,:] = PersDiff[ilen,:,:]*(ilen+1)  
  Lendp[ilen,:,:] = PersDiffp[ilen,:,:]*(ilen+1)  
  Lendn[ilen,:,:] = PersDiffn[ilen,:,:]*(ilen+1)  

for ilen in np.arange(0,Nlenb):
  Lenb[ilen,:,:] = Lend[lenb[ilen]-1:lene[ilen],:,:].sum(dim="len")*1.
  Lenbp[ilen,:,:] = Lendp[lenb[ilen]-1:lene[ilen],:,:].\
      sum(dim="len")*1.
  Lenbn[ilen,:,:] = Lendn[lenb[ilen]-1:lene[ilen],:,:].\
      sum(dim="len")*1.

Lenb=filter_run_mean_time_lat_lon(Lenb,2)
Lenbp=filter_run_mean_time_lat_lon(Lenbp,2)
Lenbn=filter_run_mean_time_lat_lon(Lenbn,2)

for ilen in np.arange(0,Nlenb):
  Arr1=Lenb[ilen,:,:].\
      rename('P<'+str(lenb[ilen])+'-'+str(lene[ilen])).\
      drop_vars(names='time')
  Arr1p=Lenbp[ilen,:,:].\
      rename('P<'+str(lenb[ilen])+'-'+str(lene[ilen])).\
      drop_vars(names='time')
  Arr1n=Lenbn[ilen,:,:].\
      rename('P<'+str(lenb[ilen])+'-'+str(lene[ilen])).\
      drop_vars(names='time')
  if (ilen==0):
    dsPersDiff=Arr1*1.
    dsPersDiffp=Arr1p*1.
    dsPersDiffn=Arr1n*1.
  else:
    dsPersDiff=xr.merge([dsPersDiff,Arr1])
    dsPersDiffp=xr.merge([dsPersDiffp,Arr1p])
    dsPersDiffn=xr.merge([dsPersDiffn,Arr1n])

dsPersDiff=dsPersDiff.expand_dims(lag=[dlag])
dsPersDiffp=dsPersDiffp.expand_dims(lag=[dlag])
dsPersDiffn=dsPersDiffn.expand_dims(lag=[dlag])
Lend=Lend.expand_dims(lag=[dlag])
    
os.system("rm -vf "+fileVar)
dsPersDiff.to_netcdf(fileVar)
os.system("rm -vf "+fileVarp)
dsPersDiffp.to_netcdf(fileVarp)
os.system("rm -vf "+fileVarn)
dsPersDiffn.to_netcdf(fileVarn)

os.system("rm -vf "+fileVarA)
Lend.rename('Anom').to_netcdf(fileVarA)

print(" ")
print("##################")
Ttime=TimeRun.time()-btime
print("Runing time "+str(np.floor(Ttime/60))+" min and "+str(np.floor(Ttime % 60))+"\
 sec")
print("##################")
print(" ")
