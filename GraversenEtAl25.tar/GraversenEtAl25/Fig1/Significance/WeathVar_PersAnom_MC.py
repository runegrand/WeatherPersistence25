# -*- coding: utf-8 -*-
#
# WeathVar_PersAnom_MC.py
#
# sys.argv[1]: YEARE
# sys.argv[2]: NyearsE
# sys.argv[3]: YEARL
# sys.argv[4]: NyearsL
# sys.argv[5]: NMC, number of NC iterations
# sys.argv[6]: SNB Script number
# sys.argv[7] Run Number 
# Period starts YEAR and ends YEAR+Nyears                                   
# Input data produced by "WeathVar.py"
####################

import xarray as xr
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cftime
import sys
import numpy as np
np.round_ = np.round
import time as TimeRun
import xrft
import os

#########################
# Setting tool script dir
# directory to tools script (tools.py and tools_plot.py)
toolPath=<tools_script_dir>
#toolPath='/cluster/home/runegg/python/WeathPers25/'
try:
    sys.path.index(toolPath) 
except ValueError:
    sys.path.append(toolPath)
from tools import PersAnom, filter_run_mean_time_lat_lon, xfft_TLL

btime=TimeRun.time()

MakeLS='S' # L: 'Long, S: Short

#NMC=2
#SNB=8
#RunNb=1
NMC=int(sys.argv[5])
SNB=int(sys.argv[6])
RunNb=int(sys.argv[7])

PathW=
#PathW='/cluster/projects/nn9348k/Rune/WeathPers25/work/SATvar/'

#YEARE   = 1980 
#YEARL   = 2008 
#NyearsE = 15 
#NyearsL = 15 
YEARE   = int(sys.argv[1])
YEARL   = int(sys.argv[3])
NyearsE = int(sys.argv[2])
NyearsL = int(sys.argv[4])

LatEnd=20
LatStep=2
LatLoop = np.arange(90,LatEnd,-LatStep)

lat=xr.open_dataset(PathW+'/SATrm.1979.nc').lat
dlat=np.abs(lat[0].data-lat[1].data)

Nlen=365 #365
if MakeLS=='S':
  lenb=[1,3,1,5,1,11]
  lene=[2,Nlen,4,Nlen,10,Nlen]
elif MakeLS=='L':  
  lenb=[1,5,8,15,31,95]  
  lene=[4,7,14,30,94,Nlen]  
else:
  sys.exit("MakeLS should by 'L' or 'S'!!")
   
Nlenb=np.size(lenb)

fileVar=PathW+'Fig/SATPersAnom'+str(YEARL)+'-'+str(YEARL+NyearsL-1)+\
    'minus'+str(YEARE)+'-'+str(YEARE+NyearsE-1)+'.3.nc'
dsPersDiffO=xr.open_dataset(fileVar)

anB=0  # Anomaly threshold 0.5
for iMC in range(NMC):
  print("MC number: "+str(iMC))
  first=True
  for Lati in LatLoop:
    print("Calculating for latitude: "+str(Lati))
    latb=Lati
    late=Lati-LatStep+dlat
    if ((late-dlat)==LatEnd):
      late=LatEnd

    pathSAT=PathW+'SATan'+'_Lat'+str(late)+'to'+str(latb)+'.nc'

    SATan=xr.open_dataset(pathSAT)['urm'].compute()
    SATan=SATan.isel(time=(SATan.time.dt.year.isin(np.arange(1980,2023,1))))
 
    print("Phase shift")
    SATanr=xfft_TLL(SATan)
    print("Phase shift done")

    del SATan
 
    SATE = SATanr.isel(time=(SATanr.time.dt.year.
              isin(np.arange(YEARE,YEARE+NyearsE,1))))
    SATL = SATanr.isel(time=(SATanr.time.dt.year.
              isin(np.arange(YEARL,YEARL+NyearsL,1))))

    dsLenEp = PersAnom(SATE,Nlen,anB)
    dsLenEn = PersAnom(-1.*SATE,Nlen,anB)
    dsLenLp = PersAnom(SATL,Nlen,anB)
    dsLenLn = PersAnom(-1.*SATL,Nlen,anB)

    PersDiffL = (dsLenLp+dsLenLn) - (dsLenEp+dsLenEn)
    PersDiffL=PersDiffL.rename('pers')

    del SATanr
    
    if (first):
      PersDiff=PersDiffL*1.
    else:
      PersDiff=xr.concat([PersDiff,PersDiffL],dim="lat")    

    first=False

  lat=PersDiff.lat
  lon=PersDiff.lon
  Nlat=np.size(lat)
  Nlon=np.size(lon)
  Lend = xr.DataArray(np.zeros([Nlen,Nlat,Nlon]), \
          coords=[np.arange(1,Nlen+1),lat,lon], dims=["len","lat","lon"])
  Lenb = xr.DataArray(np.zeros([Nlenb,Nlat,Nlon]), \
              coords=[np.arange(1,Nlenb+1),lat,lon], dims=["time","lat","lon"])

  for ilen in np.arange(0,Nlen):
    Lend[ilen,:,:] = PersDiff[ilen,:,:]*(ilen+1)  

  for ilen in np.arange(0,Nlenb):
    Lenb[ilen,:,:] = Lend[lenb[ilen]-1:lene[ilen],:,:].sum(dim="len")*1.

  Lenb=filter_run_mean_time_lat_lon(Lenb,2)

  for ilen in np.arange(0,Nlenb):
    Arr1=Lenb[ilen,:,:].rename('P<'+str(lenb[ilen])+'-'+str(lene[ilen])). \
        drop_vars(names='time')

    if (ilen==0):
      dsPersDiff=Arr1*1.
    else:
      dsPersDiff=xr.merge([dsPersDiff,Arr1])
    
  # Compare random to origional 
  VarDiffMCn = dsPersDiff*0.+1
  VarDiffMCn = VarDiffMCn.where(np.fabs(dsPersDiffO) > \
                               np.fabs(dsPersDiff), 0)
  
  if iMC==0:
    VarDiffMC=VarDiffMCn*1.
  else:
    VarDiffMC=VarDiffMC+VarDiffMCn

fileMC = PathW+'MC/run/PersAnom.Script'+str(SNB)+'.MCrun'+str(RunNb)+'.nc'
os.system('rm -vf '+fileMC)
VarDiffMC=VarDiffMC.assign(NMC=NMC)

VarDiffMC.to_netcdf(fileMC)

print(" ")
print("##################")
Ttime=TimeRun.time()-btime
print("Running time "+str(np.floor(Ttime/60))+" min and "+str(np.floor(Ttime % 60))+" sec") 
print("##################")
print(" ")


print(".. Done Pers Anom MC: "+str(RunNb)) 

 
