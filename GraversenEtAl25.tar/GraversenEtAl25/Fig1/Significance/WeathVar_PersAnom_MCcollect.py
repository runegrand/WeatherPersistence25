# -*- coding: utf-8 -*-
#
# WeathVar_PersAnom_MCcollect.py
#
# sys.argv[1]: YEARE
# sys.argv[2]: NyearsE
# sys.argv[3]: YEARL
# sys.argv[4]: NyearsL
# sys.argv[5]: SNB Script number
# sys.argv[6] Number of Run
# Period starts YEAR and ends YEAR+Nyears

####################

import xarray as xr
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cftime
import sys
import numpy as np
np.round_ = np.round
import xrft
import os

#NbR=4
#SNB=1
SNB=int(sys.argv[5])
NbR=int(sys.argv[6])

PathW=
#PathW='/cluster/projects/nn9348k/Rune/WeathPers25/work/SATvar/'

#YEARE   = 1980 
#YEARL   = 2008 
#NyearsE = 15 
#NyearsL = 15 
YEARE   = int(sys.argv[1])
YEARL   = int(sys.argv[3])
NyearsE = int(sys.argv[2])
NyearsL = int(sys.argv[4])

fileMC_tot = PathW+'MC/PersAnom.'+str(YEARL)+'-'+str(YEARL+NyearsL-1)+\
    'minus'+str(YEARE)+'-'+str(YEARE+NyearsE-1)+'.nc'
fileMCb_tot = PathW+'MC/back/PersAnom.'+str(YEARL)+'-'+str(YEARL+NyearsL-1)+\
    'minus'+str(YEARE)+'-'+str(YEARE+NyearsE-1)+'.nc' 

if os.path.isfile(fileMC_tot):
  VarDiffMC_tot=xr.open_dataset(fileMC_tot)
  for irun in np.arange(1,NbR+1):
    fileMC = PathW+'MC/run/PersAnom.Script'+str(SNB)+'.MCrun'+str(irun)+'.nc'
    VarDiffMC=xr.open_dataset(fileMC)
    VarDiffMC_tot=VarDiffMC_tot+VarDiffMC
    os.system("rm -vf "+fileMC)
else:
  fileMC = PathW+'MC/run/PersAnom.Script'+str(SNB)+'.MCrun1.nc'
  VarDiffMC=xr.open_dataset(fileMC)
  VarDiffMC_tot=VarDiffMC
  os.system("rm -vf "+fileMC)
  for irun in np.arange(2,NbR+1):
    print(irun)
    fileMC = PathW+'MC/run/PersAnom.Script'+str(SNB)+'.MCrun'+str(irun)+'.nc'
    VarDiffMC=xr.open_dataset(fileMC)
    VarDiffMC_tot=VarDiffMC_tot+VarDiffMC
    os.system("rm -vf "+fileMC)

if os.path.isfile(fileMC_tot):
  os.system("mv -f "+fileMC_tot+" "+fileMCb_tot)

VarDiffMC_tot.to_netcdf(fileMC_tot)

print(" .. end collect")
