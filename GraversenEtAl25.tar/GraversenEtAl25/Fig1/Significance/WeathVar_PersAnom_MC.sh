#!/bin/bash
# Weath_PersAnom_MC.sh
#
# Calculate statistical significance of temperature persistence
# computed by PersAnom.Fig1.FigS1.py. An FFT approach randomly interchanging
# phases of modes in the time dimension is applied. 
#
# Calculate temperature persistence over a 90 day period
# Uses:
# -- WearhVar_PersAnom_MC.py: provides significance calculations 
# -- Weath_PersAnom_MCcollect.py: combines multible calculations
#    into a single file
#
# Rune Grand Graversen: rune.graversen@uit.no
################################################### 

#SBATCH --account=nn9348k
#SBATCH --job-name=Weath_MC
#SBATCH --nodes=1
#SBATCH --time=46:05:00
#SBATCH --ntasks=20
#SBATCH --mem-per-cpu=8G

# The following must be set:
source /cluster/home/runegg/python/WeathPers25/.Pyth_login
cd /cluster/home/runegg/python/WeathPers25/PersAnom/Rolling

NMC=35  #35
NbR=8
SNB=7 # Script number 

Pro="python3 WeathVar_PersAnom_MC.py 1980 15 2008 15"
Pro_collect="python3 WeathVar_PersAnom_MCcollect.py 1980 15 2008 15"

# The set of parallel runs:
for i in $(seq 1 1 $((NbR))); do
    srun --ntasks=1 --exact $Pro $NMC $SNB $i &
    echo srun --ntasks=1 --exact $Pro $NMC $SNB $i
done
wait
$Pro_collect $SNB $NbR
wait

echo " ... WeathVar_PersAnom_MC.py done"

exit 0
