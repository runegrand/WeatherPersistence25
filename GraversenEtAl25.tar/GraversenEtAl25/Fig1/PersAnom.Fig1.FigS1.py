# -*- coding: utf-8 -*-
#
# PersAnom.Fig1.FigS1.py
#
# Calculate persistence in two 15 year periods and
# the difference
#
# Input data produced by "WeathVar.py"
#
# Rune Grand Graversen: rune.graversen@uit.no
####################

import xarray as xr
import pandas as pd
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cftime
import sys
import numpy as np
np.round_ = np.round
import time as TimeRun
import xrft
import os
import matplotlib.gridspec as gridspec
from matplotlib.colors import ListedColormap, LinearSegmentedColormap
from scipy import stats

#########################
# Setting tool script dir
# directory to tools script (tools.py and tools_plot.py)
toolPath=<tools_script_dir>
#toolPath='/cluster/home/runegg/python/WeathPers25/GitHub/'
#########################
try:
    sys.path.index(toolPath)
except ValueError:
    sys.path.append(toolPath)
from tools import PersAnom, \
    filter_run_mean_time_lat_lon, FalseDiscovLatLon
from tools_plot import Plot1BoxSig, Plot2_2CTB                  

btime=TimeRun.time()

########################
# Settings
MakeVar=False # True: Calculate persistence and save
              # False: use saved fields
anB=0         # Anomaly threshold

YEARE   = 1980 # Start year of early period
YEARL   = 2008 # Start year of late period
NyearsE = 15   # Number of years in early period
NyearsL = 15   # Number of years in late period

LatEnd=20      # Persistence calculations north of this latitude
LatStep=10     # Latitude step of calculation

# PathW is input data directory, PathFig is output directory
PathW=<input_dir>
PathFig=<output_dir>
#PathW='/cluster/projects/nn9348k/Rune/WeathPers25/work/SATvar/'
#PathFig='/cluster/projects/nn9348k/Rune/WeathPers25/Fig/'
########################

LatLoop = np.arange(90,LatEnd,-LatStep)

lat=xr.open_dataset(PathW+'/SATrm.1979.nc').lat
dlat=np.abs(lat[0].data-lat[1].data)

#For rebinning into periods of length
#1-2,3-Nlen; 1-4,5-Nlen; 1-10,11-Nlen
#3-Nlen id Shown in Fig1 and 5-Nlen and 11-Nlen in FigS1  
Nlen=365
lenb=[1,3,1,5,1,11]
lene=[2,Nlen,4,Nlen,10,Nlen]
  
Nlenb=np.size(lenb)

fileVar=PathW+'FigData/SATPersAnom'+str(YEARL)+'-'+str(YEARL+NyearsL-1)+\
    'minus'+str(YEARE)+'-'+str(YEARE+NyearsE-1)+'.nc'
fileVarp=PathW+'FigData/SATPersAnom'+str(YEARL)+'-'+str(YEARL+NyearsL-1)+\
    'minus'+str(YEARE)+'-'+str(YEARE+NyearsE-1)+'.p.nc'
fileVarn=PathW+'FigData/SATPersAnom'+str(YEARL)+'-'+str(YEARL+NyearsL-1)+\
    'minus'+str(YEARE)+'-'+str(YEARE+NyearsE-1)+'.n.nc'
fileVarA=PathW+'FigData/SATPersAnom'+str(YEARL)+'-'+str(YEARL+NyearsL-1)+\
    'minus'+str(YEARE)+'-'+str(YEARE+NyearsE-1)+'.All.nc'

# Calculating difference in temperature persistence and save 
if MakeVar:
  first=True
  for Lati in LatLoop:
    print("Calculating for latitude: "+str(Lati))
    latb=Lati
    late=Lati-LatStep+dlat
    if ((late-dlat)==LatEnd):
      late=LatEnd

    pathSAT=PathW+'SATan'+'_Lat'+str(late)+'to'+str(latb)+'.nc'
    
    SATan=xr.open_dataset(pathSAT)['urm'].compute()
    
    SATE = SATan.isel(time=(SATan.time.dt.year.
              isin(np.arange(YEARE,YEARE+NyearsE,1))))
    SATL = SATan.isel(time=(SATan.time.dt.year.
              isin(np.arange(YEARL,YEARL+NyearsL,1))))

    # Calculate positive and negative temperature persistence 
    dsLenEp = PersAnom(SATE,Nlen,anB)
    dsLenEn = PersAnom(-1.*SATE,Nlen,anB)
    dsLenLp = PersAnom(SATL,Nlen,anB)
    dsLenLn = PersAnom(-1.*SATL,Nlen,anB)

    lat=dsLenEp.lat
    lon=dsLenEp.lon
    Nlat=np.size(lat)
    Nlon=np.size(lon)

    # Difference in persistence 
    PersDiffL = (dsLenLp+dsLenLn) - (dsLenEp+dsLenEn)
    PersDiffL = PersDiffL.rename('pers')

    # Difference for positive and negative anomalies
    PersDiffLp = dsLenLp - dsLenEp
    PersDiffLp=PersDiffLp.rename('pers')
    PersDiffLn = dsLenLn - dsLenEn
    PersDiffLn=PersDiffLn.rename('pers')

    if (first):
      PersDiff=PersDiffL*1.
      PersDiffp=PersDiffLp*1.
      PersDiffn=PersDiffLn*1.
    else:
      PersDiff=xr.concat([PersDiff,PersDiffL],dim="lat")    
      PersDiffp=xr.concat([PersDiffp,PersDiffLp],dim="lat")    
      PersDiffn=xr.concat([PersDiffn,PersDiffLn],dim="lat")    

    first=False

  lat=PersDiff.lat
  lon=PersDiff.lon
  Nlat=np.size(lat)
  Nlon=np.size(lon)
  Lend = xr.DataArray(np.zeros([Nlen,Nlat,Nlon]), \
                  coords=[np.arange(1,Nlen+1),lat,lon], dims=["len","lat","lon"])
  Lenb = xr.DataArray(np.zeros([Nlenb,Nlat,Nlon]), \
              coords=[np.arange(1,Nlenb+1),lat,lon], dims=["time","lat","lon"])
  Lendp = xr.DataArray(np.zeros([Nlen,Nlat,Nlon]), \
                  coords=[np.arange(1,Nlen+1),lat,lon], dims=["len","lat","lon"])
  Lenbp = xr.DataArray(np.zeros([Nlenb,Nlat,Nlon]), \
              coords=[np.arange(1,Nlenb+1),lat,lon], dims=["time","lat","lon"])
  Lendn = xr.DataArray(np.zeros([Nlen,Nlat,Nlon]), \
                  coords=[np.arange(1,Nlen+1),lat,lon], dims=["len","lat","lon"])
  Lenbn = xr.DataArray(np.zeros([Nlenb,Nlat,Nlon]), \
              coords=[np.arange(1,Nlenb+1),lat,lon], dims=["time","lat","lon"])

  # Assign numbers of days in each day bin (length of anomaly)
  for ilen in np.arange(0,Nlen):
    Lend[ilen,:,:] = PersDiff[ilen,:,:]*(ilen+1)  
    Lendp[ilen,:,:] = PersDiffp[ilen,:,:]*(ilen+1)  
    Lendn[ilen,:,:] = PersDiffn[ilen,:,:]*(ilen+1)  

  # Rebin into periods 
  for ilen in np.arange(0,Nlenb):
    Lenb[ilen,:,:] = Lend[lenb[ilen]-1:lene[ilen],:,:].sum(dim="len")*1.
    Lenbp[ilen,:,:] = Lendp[lenb[ilen]-1:lene[ilen],:,:].sum(dim="len")*1.
    Lenbn[ilen,:,:] = Lendn[lenb[ilen]-1:lene[ilen],:,:].sum(dim="len")*1.

  # Smooth fields over 2 degree latitude and equal distance in longitude  
  Lenb=filter_run_mean_time_lat_lon(Lenb,2)
  Lenbp=filter_run_mean_time_lat_lon(Lenbp,2)
  Lenbn=filter_run_mean_time_lat_lon(Lenbn,2)

  for ilen in np.arange(0,Nlenb):
    Arr1=Lenb[ilen,:,:].rename('P<'+str(lenb[ilen])+'-'+str(lene[ilen])). \
        drop_vars(names='time')
    Arr1p=Lenbp[ilen,:,:].rename('P<'+str(lenb[ilen])+'-'+str(lene[ilen])). \
        drop_vars(names='time')
    Arr1n=Lenbn[ilen,:,:].rename('P<'+str(lenb[ilen])+'-'+str(lene[ilen])). \
        drop_vars(names='time')
    if (ilen==0):
      dsPersDiff=Arr1*1.
      dsPersDiffp=Arr1p*1.
      dsPersDiffn=Arr1n*1.
    else:
      dsPersDiff=xr.merge([dsPersDiff,Arr1])
      dsPersDiffp=xr.merge([dsPersDiffp,Arr1p])
      dsPersDiffn=xr.merge([dsPersDiffn,Arr1n])
    
  os.system("rm -vf "+fileVar)
  dsPersDiff.to_netcdf(fileVar)
  os.system("rm -vf "+fileVarp)
  dsPersDiffp.to_netcdf(fileVarp)
  os.system("rm -vf "+fileVarn)
  dsPersDiffn.to_netcdf(fileVarn)

  os.system("rm -vf "+fileVarA)
  Lend.rename('Anom').to_netcdf(fileVarA)  
else:
  dsPersDiff=xr.open_dataset(fileVar)
  dsPersDiffp=xr.open_dataset(fileVarp)
  dsPersDiffn=xr.open_dataset(fileVarn)
  Lend=xr.open_dataset(fileVarA)['Anom']

dsPersDiff=dsPersDiff/15.    # To obtain unit of:  
dsPersDiffp=dsPersDiffp/15.  # change of days per year 
dsPersDiffn=dsPersDiffn/15.  # [days/year]   
Lend=Lend/15.

dsPlot=dsPersDiff*1.

# Coordinate of dashed box in Fig1
Latb=45
Late=70
Lonb=-90
Lone=140

#Open MC
PathMC=PathW+'MC/'
dsPersDiffMC=xr.open_dataset(PathMC+'PersAnom.2008-2022minus1980-1994.nc')
dsPersDiffMCsc = dsPersDiffMC/dsPersDiffMC.NMC

uFD2=FalseDiscovLatLon(dsPersDiffMCsc['P<3-365'])

lat=dsPersDiff.lat
latb=30

FigForm='pdf'
FigTitle='Change in persistence of temperature anomalies'
vTitle='Change in # days in anomalies lasting 1 and 2 days'
uTitle='Change in # days in anomalies lasting at least 3 days'
CBTitle='Days yr$^{-1}$'

Fignm='Fig1.'+FigForm
Plot1BoxSig(dsPersDiff['P<3-365'].sel(lat=(lat > latb)),
        12,4,40,
        uTitle,CBTitle,FigTitle,
        Latb,Late,Lonb,Lone, 
        uFD2.sel(lat=(lat > latb)),
        0.99,
        PathFig,Fignm,FigForm)
#        None,None,None)

# Write out Fig 1 data for Figshare
dsF1=dsPersDiff['P<3-365'].sel(lat=(lat > latb)).rename('PersTrends')
dsF2=uFD2.sel(lat=(lat > latb)).rename('Confidence')
dsFig1=xr.merge([dsF1,dsF2])
dsFig1.attrs["Units"]='PersTrends: days yr-1; Confidence: %'
dsFig1.attrs["Description"]='PersTrends: change in days within temperature anomalies lasting at least 3 days between 2008-2022 and 1980-1994 divided by 15 years; Confidence: confidence level' 
FilenmFigData=PathFig+'Fig1data.nc'
os.system("rm -vf "+FilenmFigData)
dsFig1.to_netcdf(FilenmFigData)

uFD21=FalseDiscovLatLon(dsPersDiffMCsc['P<5-365'])
uFD22=FalseDiscovLatLon(dsPersDiffMCsc['P<11-365'])
u1TitleNoNEG='Change in # days in anomalies lasting at least 5 days'
u2TitleNoNEG='Change in # days in anomslies lasting at leat 11 days'

Fignm='FigS1.'+FigForm
Plot2_2CTB(dsPlot['P<5-365'].sel(lat=(lat > latb)),
      dsPlot['P<11-365'].sel(lat=(lat > latb)),
      24,42,8,14,40,
      u1TitleNoNEG,u2TitleNoNEG,CBTitle,FigTitle,
      uFD21.sel(lat=(lat > latb)),
      uFD22.sel(lat=(lat > latb)),
      0.99,
      PathFig,Fignm,FigForm)
#        None,None,None)

print(" ")
print("##################")
Ttime=TimeRun.time()-btime
print("Running time "+str(np.floor(Ttime/60))+" min and "+str(np.floor(Ttime % 60))+" sec") 
print("##################")

