# -*- coding: utf-8 -*-
# ArcticExt.Fig4.py
#
# Calculate composite difference of SAT, zonal mass flux (uM) and Z500 (Z).
# The composites are based on 3-month periods of warm and cold Arctic events
# based on the standard deviation of the Z500 gradient at 60 N.
#
# Input data are from:
#
# Rune Grand Graversen: rune.graversen@uit.no
####################

import xarray as xr
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cftime
import sys
import numpy as np
np.round_ = np.round
import xrft
import os

#########################
# Setting tool script dir
# directory to tools script (tools.py and tools_plot.py)
toolPath=<tools_script_dir>
#toolPath='/cluster/home/runegg/python/WeathPers25/'
try:
    sys.path.index(toolPath) 
except ValueError:
    sys.path.append(toolPath)
from tools_plot import Plot2_2

MakeVar=False   # True: calculate composite difference of Pvar and save
                # False: Use saved files of uM, SAT, and Z
Pvar = "uM"     # Set to: "uM", "SAT" or "Z"

# PathE is input data directory; PathFig is output directory
PathE=<input_dir>
PathFig=<output_dir>
#PathE='/cluster/projects/nn9348k/Rune/WeathPers25/work/'
#PathFig='/cluster/projects/nn9348k/Rune/WeathPers25/Fig/'

latb=90         # Northern latitude boundary
late=20         # Southern latitude boundary
#########################

Yearstart=1979
Nyears=45

dates=xr.open_dataset(PathE+'ExtrArc/ArcticExtremes.nc')
 
datp=dates["Zp"]
datn=dates["Zn"]
Ndate=datp.size

if (Pvar=="uM"):
  PathP=PathE+'uMmm/NC/'
elif (Pvar=="SAT"):
  PathP=PathE+'SAT/NC/'
elif (Pvar=="Z"):
  PathP=PathE+'Z/NC/'
else:
  print("Pvar must be 'uM', 'SAT' or 'Z'")
  sys.exit()

Ys = np.arange(Yearstart,Yearstart+Nyears,1)

lat=xr.open_dataset(PathP+Pvar+'.'+str(Yearstart)+'.nc').lat
dlat=np.abs(lat[0].data-lat[1].data)
ilatb=np.where(np.abs(lat-latb)<dlat/2)[0][0]
ilate=np.where(np.abs(lat-late)<dlat/2)[0][0]

fileVar=PathE+'ExtrArc/FigData/'+Pvar+'Ext.Z.nc'
fileVarp=PathE+'ExtrArc/FigData/'+Pvar+'Ext.Zp.nc'
fileVarn=PathE+'ExtrArc/FigData/'+Pvar+'Ext.Zn.nc'

if MakeVar:
  fileP=[]
  filePcl=[]
  for y in Ys:
    fileP.append(PathP+Pvar+'.'+str(y)+'.nc')
    filePcl.append(PathP+Pvar+'cl.'+str(y)+'.nc')

  dsP=xr.open_mfdataset(fileP,concat_dim='time',combine='nested').\
           isel(lat=slice(ilatb,ilate+1)) 
  dsPcl=xr.open_mfdataset(filePcl,concat_dim='time',combine='nested').\
           isel(lat=slice(ilatb,ilate+1)) 

  dsPan = (dsP-dsPcl).compute()
  if (Pvar=='uM'):
    Pan=dsPan['uM']
  elif (Pvar=='SAT'):
    Pan=dsPan['T2M']
  elif (Pvar=='Z'):
    Pan=dsPan['Z']
  
  time=Pan.time

  # Conposites over warm and cold Arctic 3-month periods
  firstp=0
  firstn=0
  for idate in np.arange(0,Ndate):
    dp=datp[idate]
    dn=datn[idate]
    if not (np.isnat(dp)):
      if (dp.dt.year > 1979) & (dp.dt.year < 2023):
        iExt=np.where(time==dp)[0][0]
        PLx=Pan[iExt:iExt+3,:,:]
        PLx['time']=np.arange(0,3)
        if (firstp == 0):
          PL=PLx
        else:
          PL=PL+PLx
        firstp=firstp+1
    if not (np.isnat(dn)):
      if (dn.dt.year > 1979) & (dn.dt.year < 2023):
        iExt=np.where(time==dn)[0][0]
        PEx=Pan[iExt:iExt+3,:,:]  
        PEx['time']=np.arange(0,3)
        if (firstn == 0):
          PE=PEx
        else:
          PE=PE+PEx
        firstn=firstn+1

  # Composite difference       
  PL=PL/firstp
  PE=PE/firstn
  PDiff = PL-PE
  PDiff=PDiff.rename('Ext').mean(dim='time')
  Pp=PL.rename('Extp').mean(dim='time')
  Pn=PE.rename('Extn').mean(dim='time')
  os.system("rm -vf "+fileVar)
  PDiff.to_netcdf(fileVar)
  os.system("rm -vf "+fileVarp)
  Pp.to_netcdf(fileVarp)
  os.system("rm -vf "+fileVarn)
  Pn.to_netcdf(fileVarn)
else:

  fileVarZ=PathE+'ExtrArc/FigData/ZExt.Z.nc'
  ZDiff=xr.open_dataset(fileVarZ)['Ext'][0,:,:]/1.E2
  fileVarSAT=PathE+'ExtrArc/FigData/SATExt.Z.nc'
  SATDiff=xr.open_dataset(fileVarSAT)['Ext']
  fileVaruM=PathE+'ExtrArc/FigData/uMExt.Z.nc'
  uMDiff=xr.open_dataset(fileVaruM)['Ext']/1.E4

  lat=ZDiff.lat
  latb=30

  FigForm='pdf'
  FigTitle='Composite difference (warm minus cold events)'
  uTitle='SAT and Z500'
  vTitle='uM and Z500'
  CBTitleU='K'
  CBTitleV='10$^4$ kg m$^{-1}$'

  FigFormx='eps'
  Fignm='Fig4.'+FigFormx
  Plot2_2(SATDiff.sel(lat=(lat > latb)),
          uMDiff.sel(lat=(lat > latb)),
          ZDiff.sel(lat=(lat > latb)),
          ZDiff.sel(lat=(lat > latb)),
          5,10,12,1,2,4,100,40,
          uTitle,vTitle,CBTitleU,CBTitleV,FigTitle,
          PathFig,Fignm,FigFormx)
  #          None,None,None)

  # Write out Fig 4 data for Figshare, Nov 2025
  dsF1=SATDiff.sel(lat=(lat > latb)).rename('SATDiff')
  dsF2=uMDiff.sel(lat=(lat > latb)).rename('uMDiff')
  dsF3=ZDiff.sel(lat=(lat > latb)).rename('Z500Diff')
  dsFig4=xr.merge([dsF1,dsF2])
  dsFig4=xr.merge([dsFig4,dsF3])
  dsFig4.attrs["Units"]='SATDiff: K; uMDiff: 10^4 kg m-1 s-1; Z500Diff: m'
  dsFig4.attrs["Description"]='Composite difference of SAT, zonal mass flux uM, and Z500 between 3-months warm and cold Arctic events. Z500 is the difference in geopotential height between the Arctic and the mid-latitudes.' 
  FilenmFigData=PathFig+'Fig4data.nc'
  os.system("rm -vf "+FilenmFigData)
  dsFig4.to_netcdf(FilenmFigData)

 
